import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

export type League = "NBA" | "NFL" | "MLB" | "NHL" | "Soccer";

interface LeagueSelectorProps {
  selected: League;
  onSelect: (league: League) => void;
}

const leagues: { id: League; name: string; emoji: string }[] = [
  { id: "NBA", name: "NBA", emoji: "🏀" },
  { id: "NFL", name: "NFL", emoji: "🏈" },
  { id: "MLB", name: "MLB", emoji: "⚾" },
  { id: "NHL", name: "NHL", emoji: "🏒" },
  { id: "Soccer", name: "Soccer", emoji: "⚽" },
];

const LeagueSelector = ({ selected, onSelect }: LeagueSelectorProps) => {
  return (
    <div className="flex flex-wrap gap-3 justify-center">
      {leagues.map((league) => (
        <Button
          key={league.id}
          onClick={() => onSelect(league.id)}
          variant={selected === league.id ? "default" : "outline"}
          size="lg"
          className={cn(
            "text-lg font-bold transition-all duration-200",
            selected === league.id 
              ? "shadow-glow scale-105" 
              : "hover:scale-105"
          )}
        >
          <span className="text-2xl mr-2">{league.emoji}</span>
          {league.name}
        </Button>
      ))}
    </div>
  );
};

export default LeagueSelector;
