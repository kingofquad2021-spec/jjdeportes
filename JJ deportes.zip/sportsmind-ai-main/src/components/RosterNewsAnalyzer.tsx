import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Newspaper, Loader2, CheckCircle, AlertCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface PlayerUpdate {
  player: string;
  status: string;
  updated: boolean;
  reason?: string;
}

export const RosterNewsAnalyzer = () => {
  const [newsText, setNewsText] = useState("");
  const [selectedLeague, setSelectedLeague] = useState("");
  const [selectedTeam, setSelectedTeam] = useState("");
  const [teams, setTeams] = useState<{ name: string; abbreviation: string }[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState("");
  const [playerUpdates, setPlayerUpdates] = useState<PlayerUpdate[]>([]);

  useEffect(() => {
    if (selectedLeague) {
      fetchTeams();
    }
  }, [selectedLeague]);

  const fetchTeams = async () => {
    const { data, error } = await supabase
      .from('team_standings')
      .select('team_name, abbreviation')
      .eq('league', selectedLeague)
      .order('team_name');

    if (error) {
      console.error('Error fetching teams:', error);
      return;
    }

    const uniqueTeams = Array.from(
      new Map(data.map(item => [item.team_name, item])).values()
    );
    setTeams(uniqueTeams.map(t => ({ name: t.team_name, abbreviation: t.abbreviation })));
  };

  const handleAnalyze = async () => {
    if (!newsText.trim()) {
      toast.error("Por favor ingresa el texto de la noticia");
      return;
    }

    if (!selectedLeague || !selectedTeam) {
      toast.error("Por favor selecciona una liga y un equipo");
      return;
    }

    setIsAnalyzing(true);
    setAnalysis("");
    setPlayerUpdates([]);

    try {
      const { data, error } = await supabase.functions.invoke('analyze-roster-news', {
        body: { 
          newsText: newsText.trim(),
          team: selectedTeam,
          league: selectedLeague
        }
      });

      if (error) throw error;

      if (data.error) {
        toast.error(data.error);
        return;
      }

      setAnalysis(data.summary);
      setPlayerUpdates(data.players || []);
      
      const updatedCount = data.players?.filter((p: PlayerUpdate) => p.updated).length || 0;
      if (updatedCount > 0) {
        toast.success(`Análisis completado - ${updatedCount} jugador(es) actualizado(s) en el roster`);
      } else {
        toast.warning("Análisis completado - No se encontraron jugadores en el roster para actualizar");
      }
    } catch (error) {
      console.error('Error analyzing news:', error);
      toast.error("Error al analizar la noticia");
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <Card className="border-primary/20 bg-card/50 backdrop-blur">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Newspaper className="w-6 h-6 text-primary" />
            <CardTitle>Analizador de Noticias de Roster</CardTitle>
          </div>
          <CardDescription>
            Pega una noticia sobre cambios en el roster y la IA la analizará automáticamente
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Selecciona la liga</label>
            <Select value={selectedLeague} onValueChange={setSelectedLeague}>
              <SelectTrigger>
                <SelectValue placeholder="Elige una liga" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="NBA">NBA</SelectItem>
                <SelectItem value="NFL">NFL</SelectItem>
                <SelectItem value="MLB">MLB</SelectItem>
                <SelectItem value="NHL">NHL</SelectItem>
                <SelectItem value="SOCCER">SOCCER</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Selecciona el equipo</label>
            <Select value={selectedTeam} onValueChange={setSelectedTeam} disabled={!selectedLeague}>
              <SelectTrigger>
                <SelectValue placeholder={selectedLeague ? "Elige un equipo" : "Primero selecciona una liga"} />
              </SelectTrigger>
              <SelectContent>
                {teams.map((team) => (
                  <SelectItem key={team.abbreviation} value={team.name}>
                    {team.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Texto de la noticia</label>
            <Textarea
              placeholder="Pega aquí el artículo o noticia sobre cambios en el roster..."
              value={newsText}
              onChange={(e) => setNewsText(e.target.value)}
              className="min-h-[200px] resize-y"
            />
          </div>

          <Button 
            onClick={handleAnalyze} 
            disabled={isAnalyzing || !newsText.trim() || !selectedLeague || !selectedTeam}
            className="w-full"
          >
            {isAnalyzing ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Analizando y actualizando roster...
              </>
            ) : (
              <>
                <CheckCircle className="w-4 h-4 mr-2" />
                Analizar y Actualizar Roster
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {analysis && (
        <Card className="border-primary/20 bg-card/50 backdrop-blur animate-in fade-in-50 duration-500">
          <CardHeader>
            <CardTitle className="text-primary">Análisis y Actualización del Roster</CardTitle>
            <CardDescription>Cambios detectados y aplicados automáticamente</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="prose prose-sm max-w-none dark:prose-invert">
              <div className="whitespace-pre-wrap text-foreground/90 mb-4">{analysis}</div>
            </div>

            {playerUpdates.length > 0 && (
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Jugadores actualizados:</h4>
                <div className="space-y-2">
                  {playerUpdates.map((update, idx) => (
                    <div key={idx} className="flex items-center justify-between p-3 rounded-lg border bg-card/30">
                      <div className="flex items-center gap-2">
                        {update.updated ? (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-yellow-500" />
                        )}
                        <span className="font-medium">{update.player}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={update.status === 'active' ? 'default' : 'destructive'}>
                          {update.status}
                        </Badge>
                        {!update.updated && update.reason && (
                          <span className="text-xs text-muted-foreground">{update.reason}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
};
