import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { supabase } from "@/integrations/supabase/client";
import { Trophy, TrendingUp, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import type { GameWithPrediction } from "@/pages/ParlayAnalyzer";

interface PlayerStats {
  points?: string;
  assists?: string;
  rebounds?: string;
  goals?: string;
  shots?: string;
  passingYards?: string;
  rushingYards?: string;
  touchdowns?: string;
}

interface PlayerInfo {
  name: string;
  games: number;
  stats: PlayerStats;
}

interface Matchup {
  gameId: string;
  homeTeam: string;
  awayTeam: string;
  league: string;
  homePlayer: PlayerInfo;
  awayPlayer: PlayerInfo;
  analysis: string;
}

interface PlayerMatchupComparisonProps {
  games: GameWithPrediction[];
}

const PlayerMatchupComparison = ({ games }: PlayerMatchupComparisonProps) => {
  const [matchups, setMatchups] = useState<Matchup[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (games.length > 0) {
      fetchMatchups();
    } else {
      setMatchups([]);
    }
  }, [games]);

  const fetchMatchups = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('analyze-player-matchups', {
        body: { games }
      });

      if (error) throw error;

      setMatchups(data?.matchups || []);
    } catch (error) {
      console.error('Error fetching matchups:', error);
      toast.error('Error al analizar los enfrentamientos de jugadores');
    } finally {
      setLoading(false);
    }
  };

  const renderStatsComparison = (matchup: Matchup) => {
    const homeStats = matchup.homePlayer.stats;
    const awayStats = matchup.awayPlayer.stats;

    if (matchup.league === 'NBA' || matchup.league === 'MLB') {
      return (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Estadística</TableHead>
              <TableHead className="text-right">{matchup.homePlayer.name}</TableHead>
              <TableHead className="text-right">{matchup.awayPlayer.name}</TableHead>
              <TableHead className="text-center">Ventaja</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium">Puntos</TableCell>
              <TableCell className="text-right">{homeStats.points}</TableCell>
              <TableCell className="text-right">{awayStats.points}</TableCell>
              <TableCell className="text-center">
                {parseFloat(homeStats.points!) > parseFloat(awayStats.points!) ? 
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">🏠</Badge> : 
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500">✈️</Badge>
                }
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Asistencias</TableCell>
              <TableCell className="text-right">{homeStats.assists}</TableCell>
              <TableCell className="text-right">{awayStats.assists}</TableCell>
              <TableCell className="text-center">
                {parseFloat(homeStats.assists!) > parseFloat(awayStats.assists!) ? 
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">🏠</Badge> : 
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500">✈️</Badge>
                }
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Rebotes</TableCell>
              <TableCell className="text-right">{homeStats.rebounds}</TableCell>
              <TableCell className="text-right">{awayStats.rebounds}</TableCell>
              <TableCell className="text-center">
                {parseFloat(homeStats.rebounds!) > parseFloat(awayStats.rebounds!) ? 
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">🏠</Badge> : 
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500">✈️</Badge>
                }
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      );
    } else if (matchup.league === 'NFL') {
      return (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Estadística</TableHead>
              <TableHead className="text-right">{matchup.homePlayer.name}</TableHead>
              <TableHead className="text-right">{matchup.awayPlayer.name}</TableHead>
              <TableHead className="text-center">Ventaja</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium">Yardas Pase</TableCell>
              <TableCell className="text-right">{homeStats.passingYards}</TableCell>
              <TableCell className="text-right">{awayStats.passingYards}</TableCell>
              <TableCell className="text-center">
                {parseFloat(homeStats.passingYards!) > parseFloat(awayStats.passingYards!) ? 
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">🏠</Badge> : 
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500">✈️</Badge>
                }
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Yardas Carrera</TableCell>
              <TableCell className="text-right">{homeStats.rushingYards}</TableCell>
              <TableCell className="text-right">{awayStats.rushingYards}</TableCell>
              <TableCell className="text-center">
                {parseFloat(homeStats.rushingYards!) > parseFloat(awayStats.rushingYards!) ? 
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">🏠</Badge> : 
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500">✈️</Badge>
                }
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Touchdowns</TableCell>
              <TableCell className="text-right">{homeStats.touchdowns}</TableCell>
              <TableCell className="text-right">{awayStats.touchdowns}</TableCell>
              <TableCell className="text-center">
                {parseFloat(homeStats.touchdowns!) > parseFloat(awayStats.touchdowns!) ? 
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">🏠</Badge> : 
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500">✈️</Badge>
                }
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      );
    } else { // NHL, Soccer
      return (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Estadística</TableHead>
              <TableHead className="text-right">{matchup.homePlayer.name}</TableHead>
              <TableHead className="text-right">{matchup.awayPlayer.name}</TableHead>
              <TableHead className="text-center">Ventaja</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <TableRow>
              <TableCell className="font-medium">Goles</TableCell>
              <TableCell className="text-right">{homeStats.goals}</TableCell>
              <TableCell className="text-right">{awayStats.goals}</TableCell>
              <TableCell className="text-center">
                {parseFloat(homeStats.goals!) > parseFloat(awayStats.goals!) ? 
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">🏠</Badge> : 
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500">✈️</Badge>
                }
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Asistencias</TableCell>
              <TableCell className="text-right">{homeStats.assists}</TableCell>
              <TableCell className="text-right">{awayStats.assists}</TableCell>
              <TableCell className="text-center">
                {parseFloat(homeStats.assists!) > parseFloat(awayStats.assists!) ? 
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">🏠</Badge> : 
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500">✈️</Badge>
                }
              </TableCell>
            </TableRow>
            <TableRow>
              <TableCell className="font-medium">Tiros</TableCell>
              <TableCell className="text-right">{homeStats.shots}</TableCell>
              <TableCell className="text-right">{awayStats.shots}</TableCell>
              <TableCell className="text-center">
                {parseFloat(homeStats.shots!) > parseFloat(awayStats.shots!) ? 
                  <Badge variant="outline" className="bg-green-500/10 text-green-500">🏠</Badge> : 
                  <Badge variant="outline" className="bg-blue-500/10 text-blue-500">✈️</Badge>
                }
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      );
    }
  };

  if (games.length === 0) {
    return null;
  }

  return (
    <Card className="glass-card p-6 shadow-card mt-6">
      <div className="flex items-center gap-2 mb-6">
        <Trophy className="w-5 h-5 text-accent" />
        <h3 className="text-xl font-bold">Enfrentamientos de Jugadores Clave</h3>
      </div>

      {loading ? (
        <div className="space-y-6">
          {games.map((_, idx) => (
            <div key={idx} className="space-y-4">
              <Skeleton className="h-6 w-3/4" />
              <Skeleton className="h-32 w-full" />
              <Skeleton className="h-20 w-full" />
            </div>
          ))}
        </div>
      ) : matchups.length === 0 ? (
        <div className="text-center py-8">
          <AlertCircle className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">
            No hay datos de jugadores disponibles para los juegos seleccionados
          </p>
        </div>
      ) : (
        <div className="space-y-8">
          {matchups.map((matchup, idx) => (
            <div key={matchup.gameId}>
              {idx > 0 && <Separator className="my-8" />}
              
              <div className="mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="w-4 h-4 text-accent" />
                  <h4 className="font-bold text-lg">
                    {matchup.homePlayer.name} vs {matchup.awayPlayer.name}
                  </h4>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Badge variant="outline">{matchup.league}</Badge>
                  <span>{matchup.homeTeam} vs {matchup.awayTeam}</span>
                </div>
              </div>

              <div className="mb-4 bg-muted/30 rounded-lg p-4">
                <div className="text-sm font-semibold mb-2 flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Comparación de Estadísticas
                </div>
                {renderStatsComparison(matchup)}
              </div>

              <div className="p-4 bg-primary/5 rounded-lg border border-primary/10">
                <div className="text-sm font-semibold mb-2">💬 Análisis</div>
                <p className="text-sm text-muted-foreground leading-relaxed whitespace-pre-line">
                  {matchup.analysis}
                </p>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
};

export default PlayerMatchupComparison;