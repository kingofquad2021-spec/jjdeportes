import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Save, Plus, RefreshCw, Zap } from "lucide-react";
import { Label } from "@/components/ui/label";

interface TeamFormData {
  league: string;
  conference: string;
  team_name: string;
  abbreviation: string;
  rank: number;
  wins: number;
  losses: number;
  home_record: string;
  away_record: string;
  division_record: string;
  conference_record: string;
  ppg: number;
  opp_ppg: number;
  streak: string;
  last_10: string;
}

const CONFERENCES = [
  { value: "Eastern", label: "Eastern Conference" },
  { value: "Western", label: "Western Conference" },
];

export const StandingsManager = () => {
  const [formData, setFormData] = useState<TeamFormData>({
    league: "NBA",
    conference: "Eastern",
    team_name: "",
    abbreviation: "",
    rank: 1,
    wins: 0,
    losses: 0,
    home_record: "0-0",
    away_record: "0-0",
    division_record: "0-0",
    conference_record: "0-0",
    ppg: 0,
    opp_ppg: 0,
    streak: "W0",
    last_10: "0-0",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isAutoUpdating, setIsAutoUpdating] = useState(false);

  const handleInputChange = (field: keyof TeamFormData, value: string | number) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const calculateStats = () => {
    const { wins, losses, ppg, opp_ppg } = formData;
    const totalGames = wins + losses;
    const pct = totalGames > 0 ? wins / totalGames : 0;
    const diff = ppg - opp_ppg;
    
    return { pct, diff };
  };

  const handleSubmit = async () => {
    if (!formData.team_name || !formData.abbreviation) {
      toast.error("Por favor completa el nombre del equipo y la abreviación");
      return;
    }

    setIsSubmitting(true);
    const { pct, diff } = calculateStats();

    try {
      const { error } = await supabase
        .from('team_standings')
        .upsert({
          league: formData.league,
          conference: formData.conference,
          team_name: formData.team_name,
          abbreviation: formData.abbreviation,
          rank: formData.rank,
          wins: formData.wins,
          losses: formData.losses,
          pct: pct,
          home_record: formData.home_record,
          away_record: formData.away_record,
          division_record: formData.division_record,
          conference_record: formData.conference_record,
          ppg: formData.ppg,
          opp_ppg: formData.opp_ppg,
          diff: diff,
          streak: formData.streak,
          last_10: formData.last_10,
        }, {
          onConflict: 'league,conference,team_name'
        });

      if (error) throw error;

      toast.success("Equipo actualizado correctamente");
      
      // Reset form
      setFormData({
        league: "NBA",
        conference: "Eastern",
        team_name: "",
        abbreviation: "",
        rank: 1,
        wins: 0,
        losses: 0,
        home_record: "0-0",
        away_record: "0-0",
        division_record: "0-0",
        conference_record: "0-0",
        ppg: 0,
        opp_ppg: 0,
        streak: "W0",
        last_10: "0-0",
      });
    } catch (error) {
      console.error('Error updating standings:', error);
      toast.error("Error al actualizar las standings");
    } finally {
      setIsSubmitting(false);
    }
  };

  const loadSampleData = async () => {
    setIsSubmitting(true);
    try {
      // Sample NBA data
      const sampleTeams = [
        { league: "NBA", conference: "Eastern", team_name: "Milwaukee Bucks", abbreviation: "MIL", rank: 1, wins: 2, losses: 0, home_record: "1-0", away_record: "1-0", division_record: "0-0", conference_record: "2-0", ppg: 127.5, opp_ppg: 118.0, streak: "W2", last_10: "2-0" },
        { league: "NBA", conference: "Eastern", team_name: "New York Knicks", abbreviation: "NY", rank: 2, wins: 2, losses: 0, home_record: "2-0", away_record: "0-0", division_record: "1-0", conference_record: "2-0", ppg: 112.0, opp_ppg: 103.0, streak: "W2", last_10: "2-0" },
        { league: "NBA", conference: "Eastern", team_name: "Boston Celtics", abbreviation: "BOS", rank: 13, wins: 0, losses: 2, home_record: "0-1", away_record: "0-1", division_record: "0-2", conference_record: "0-2", ppg: 105.5, opp_ppg: 111.0, streak: "L2", last_10: "0-2" },
        { league: "NBA", conference: "Western", team_name: "Oklahoma City Thunder", abbreviation: "OKC", rank: 1, wins: 3, losses: 0, home_record: "1-0", away_record: "2-0", division_record: "0-0", conference_record: "1-0", ppg: 127.7, opp_ppg: 119.7, streak: "W3", last_10: "3-0" },
        { league: "NBA", conference: "Western", team_name: "San Antonio Spurs", abbreviation: "SA", rank: 2, wins: 2, losses: 0, home_record: "0-0", away_record: "2-0", division_record: "2-0", conference_record: "2-0", ppg: 122.5, opp_ppg: 104.0, streak: "W2", last_10: "2-0" },
      ];

      for (const team of sampleTeams) {
        const totalGames = team.wins + team.losses;
        const pct = totalGames > 0 ? team.wins / totalGames : 0;
        const diff = team.ppg - team.opp_ppg;

        await supabase.from('team_standings').upsert({
          ...team,
          pct,
          diff,
        }, {
          onConflict: 'league,conference,team_name'
        });
      }

      toast.success("Datos de ejemplo cargados correctamente");
    } catch (error) {
      console.error('Error loading sample data:', error);
      toast.error("Error al cargar datos de ejemplo");
    } finally {
      setIsSubmitting(false);
    }
  };

  const autoUpdateStandings = async (league: string) => {
    setIsAutoUpdating(true);
    try {
      toast.info(`Actualizando standings de ${league} desde ESPN...`);
      
      const functionName = `update-${league.toLowerCase()}-standings`;
      const { data, error } = await supabase.functions.invoke(functionName);

      if (error) throw error;

      if (data.success) {
        toast.success(`¡Standings de ${league} actualizadas! ${data.updated} equipos actualizados`);
      } else {
        toast.error("Error al actualizar: " + data.error);
      }
    } catch (error) {
      console.error(`Error auto-updating ${league} standings:`, error);
      toast.error(`Error al actualizar standings de ${league}`);
    } finally {
      setIsAutoUpdating(false);
    }
  };

  const autoUpdateRosters = async (league: string) => {
    setIsAutoUpdating(true);
    try {
      toast.info(`Actualizando rosters de ${league} desde ESPN...`);
      
      const functionName = `update-${league.toLowerCase()}-rosters`;
      const { data, error } = await supabase.functions.invoke(functionName);

      if (error) throw error;

      if (data.success) {
        toast.success(data.message);
      } else {
        toast.error("Error al actualizar: " + data.error);
      }
    } catch (error) {
      console.error(`Error auto-updating ${league} rosters:`, error);
      toast.error(`Error al actualizar rosters de ${league}`);
    } finally {
      setIsAutoUpdating(false);
    }
  };

  const autoUpdateNews = async (league: string) => {
    setIsAutoUpdating(true);
    try {
      toast.info(`Actualizando noticias de ${league} desde ESPN...`);
      
      const functionName = `update-${league.toLowerCase()}-news`;
      const { data, error } = await supabase.functions.invoke(functionName);

      if (error) throw error;

      if (data.success) {
        toast.success(`¡Noticias de ${league} actualizadas! ${data.newsCount || 0} artículos procesados`);
      } else {
        toast.error("Error al actualizar: " + data.error);
      }
    } catch (error) {
      console.error(`Error auto-updating ${league} news:`, error);
      toast.error(`Error al actualizar noticias de ${league}`);
    } finally {
      setIsAutoUpdating(false);
    }
  };

  const updatePlayerStats = async () => {
    setIsAutoUpdating(true);
    try {
      toast.info('Actualizando estadísticas de jugadores de NBA (esto puede tardar varios minutos)...');
      
      const { data, error } = await supabase.functions.invoke('update-nba-player-stats');

      if (error) throw error;

      if (data.success) {
        toast.success(`¡Estadísticas actualizadas! ${data.count || 0} jugadores procesados`);
      } else {
        toast.error("Error al actualizar: " + data.error);
      }
    } catch (error) {
      console.error('Error updating player stats:', error);
      toast.error('Error al actualizar estadísticas de jugadores');
    } finally {
      setIsAutoUpdating(false);
    }
  };

  return (
    <Card className="border-primary/20 bg-card/50 backdrop-blur">
      <CardHeader>
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <CardTitle>Actualizar Standings</CardTitle>
            <CardDescription>
              Agrega o actualiza la información de equipos en las standings
            </CardDescription>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              variant="default"
              size="sm"
              onClick={() => autoUpdateStandings('NBA')}
              disabled={isAutoUpdating}
              className="bg-gradient-to-r from-primary to-accent"
            >
              {isAutoUpdating ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Actualizando...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  🏀 NBA
                </>
              )}
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={() => autoUpdateStandings('NFL')}
              disabled={isAutoUpdating}
              className="bg-gradient-to-r from-primary to-accent"
            >
              🏈 NFL
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={() => autoUpdateStandings('MLB')}
              disabled={isAutoUpdating}
              className="bg-gradient-to-r from-primary to-accent"
            >
              ⚾ MLB
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={() => autoUpdateStandings('NHL')}
              disabled={isAutoUpdating}
              className="bg-gradient-to-r from-primary to-accent"
            >
              🏒 NHL
            </Button>
            <Button
              variant="default"
              size="sm"
              onClick={() => autoUpdateStandings('Soccer')}
              disabled={isAutoUpdating}
              className="bg-gradient-to-r from-primary to-accent"
            >
              ⚽ Soccer
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={loadSampleData}
              disabled={isSubmitting}
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Datos de Ejemplo
            </Button>
          </div>
        </div>
        <div className="mt-4 space-y-4">
          <div className="p-3 bg-primary/10 rounded-lg border border-primary/20">
            <p className="text-sm text-muted-foreground">
              💡 <strong>Actualización automática activa:</strong> Las standings se actualizan automáticamente cada 15 minutos desde la API de ESPN. También puedes forzar una actualización manual con el botón de arriba.
            </p>
          </div>
          
          <div className="p-4 bg-accent/10 rounded-lg border border-accent/20">
            <h3 className="text-sm font-semibold mb-3 text-foreground">🎯 Actualizar Rosters</h3>
            <p className="text-xs text-muted-foreground mb-3">
              Actualiza los rosters de jugadores desde ESPN
            </p>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => autoUpdateRosters('NBA')}
                disabled={isAutoUpdating}
              >
                {isAutoUpdating ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Zap className="w-4 h-4 mr-2" />
                )}
                🏀 NBA
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => autoUpdateRosters('NFL')}
                disabled={isAutoUpdating}
              >
                🏈 NFL
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => autoUpdateRosters('MLB')}
                disabled={isAutoUpdating}
              >
                ⚾ MLB
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => autoUpdateRosters('NHL')}
                disabled={isAutoUpdating}
              >
                🏒 NHL
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => autoUpdateRosters('Soccer')}
                disabled={isAutoUpdating}
              >
                ⚽ Soccer
              </Button>
            </div>
          </div>

          <div className="p-4 bg-green-500/10 rounded-lg border border-green-500/20">
            <h3 className="text-sm font-semibold mb-3 text-foreground">📰 Actualizar Noticias desde ESPN</h3>
            <p className="text-xs text-muted-foreground mb-3">
              Obtén las últimas noticias de lesiones y suspensiones. Los rosters se actualizan automáticamente con IA.
            </p>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => autoUpdateNews('NBA')}
                disabled={isAutoUpdating}
                className="bg-green-600/10 hover:bg-green-600/20 border-green-600/30"
              >
                {isAutoUpdating ? (
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                ) : (
                  <Zap className="w-4 h-4 mr-2" />
                )}
                🏀 NBA
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => autoUpdateNews('NFL')}
                disabled={isAutoUpdating}
                className="bg-green-600/10 hover:bg-green-600/20 border-green-600/30"
              >
                🏈 NFL
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => autoUpdateNews('MLB')}
                disabled={isAutoUpdating}
                className="bg-green-600/10 hover:bg-green-600/20 border-green-600/30"
              >
                ⚾ MLB
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => autoUpdateNews('NHL')}
                disabled={isAutoUpdating}
                className="bg-green-600/10 hover:bg-green-600/20 border-green-600/30"
              >
                🏒 NHL
              </Button>
            </div>
          </div>

          <div className="p-4 bg-blue-500/10 rounded-lg border border-blue-500/20">
            <h3 className="text-sm font-semibold mb-3 text-foreground">📊 Actualizar Estadísticas de Jugadores</h3>
            <p className="text-xs text-muted-foreground mb-3">
              Obtén las estadísticas recientes de jugadores de NBA. <strong>Necesario para comparaciones de jugadores en parlays.</strong>
            </p>
            <Button
              variant="secondary"
              size="sm"
              onClick={updatePlayerStats}
              disabled={isAutoUpdating}
              className="bg-blue-600/10 hover:bg-blue-600/20 border-blue-600/30"
            >
              {isAutoUpdating ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Actualizando...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  🏀 Stats NBA
                </>
              )}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="conference">Conferencia</Label>
            <Select
              value={formData.conference}
              onValueChange={(value) => handleInputChange('conference', value)}
            >
              <SelectTrigger id="conference">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CONFERENCES.map((conf) => (
                  <SelectItem key={conf.value} value={conf.value}>
                    {conf.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="rank">Posición</Label>
            <Input
              id="rank"
              type="number"
              min="1"
              value={formData.rank}
              onChange={(e) => handleInputChange('rank', parseInt(e.target.value) || 1)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="team_name">Nombre del Equipo</Label>
            <Input
              id="team_name"
              placeholder="Ej: Boston Celtics"
              value={formData.team_name}
              onChange={(e) => handleInputChange('team_name', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="abbreviation">Abreviación</Label>
            <Input
              id="abbreviation"
              placeholder="Ej: BOS"
              value={formData.abbreviation}
              onChange={(e) => handleInputChange('abbreviation', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="wins">Victorias</Label>
            <Input
              id="wins"
              type="number"
              min="0"
              value={formData.wins}
              onChange={(e) => handleInputChange('wins', parseInt(e.target.value) || 0)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="losses">Derrotas</Label>
            <Input
              id="losses"
              type="number"
              min="0"
              value={formData.losses}
              onChange={(e) => handleInputChange('losses', parseInt(e.target.value) || 0)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="home_record">Record en Casa</Label>
            <Input
              id="home_record"
              placeholder="Ej: 10-5"
              value={formData.home_record}
              onChange={(e) => handleInputChange('home_record', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="away_record">Record de Visita</Label>
            <Input
              id="away_record"
              placeholder="Ej: 8-7"
              value={formData.away_record}
              onChange={(e) => handleInputChange('away_record', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="ppg">Puntos por Juego</Label>
            <Input
              id="ppg"
              type="number"
              step="0.1"
              value={formData.ppg}
              onChange={(e) => handleInputChange('ppg', parseFloat(e.target.value) || 0)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="opp_ppg">Puntos en Contra por Juego</Label>
            <Input
              id="opp_ppg"
              type="number"
              step="0.1"
              value={formData.opp_ppg}
              onChange={(e) => handleInputChange('opp_ppg', parseFloat(e.target.value) || 0)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="streak">Racha</Label>
            <Input
              id="streak"
              placeholder="Ej: W3 o L2"
              value={formData.streak}
              onChange={(e) => handleInputChange('streak', e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="last_10">Últimos 10</Label>
            <Input
              id="last_10"
              placeholder="Ej: 7-3"
              value={formData.last_10}
              onChange={(e) => handleInputChange('last_10', e.target.value)}
            />
          </div>
        </div>

        <Button 
          onClick={handleSubmit} 
          disabled={isSubmitting}
          className="w-full"
        >
          {isSubmitting ? (
            <>
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
              Guardando...
            </>
          ) : (
            <>
              <Save className="w-4 h-4 mr-2" />
              Guardar Equipo
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
};
