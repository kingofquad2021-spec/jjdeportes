import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { X, Sparkles, AlertTriangle, CheckCircle2, TrendingUp } from "lucide-react";
import type { GameWithPrediction } from "@/pages/ParlayAnalyzer";
import PlayerMatchupComparison from "./PlayerMatchupComparison";

interface ParlayBuilderProps {
  selectedGames: GameWithPrediction[];
  onClear: () => void;
}

const ParlayBuilder = ({ selectedGames, onClear }: ParlayBuilderProps) => {
  // Calculate combined probability (multiply individual probabilities)
  const calculateParlayProbability = () => {
    if (selectedGames.length === 0) return 0;
    
    const individualProbs = selectedGames.map(game => {
      const winProb = game.predicted_winner === game.home_team 
        ? (game.home_win_probability || 50) / 100
        : (game.away_win_probability || 50) / 100;
      return winProb;
    });

    const combinedProb = individualProbs.reduce((acc, prob) => acc * prob, 1);
    return combinedProb * 100;
  };

  const parlayProbability = calculateParlayProbability();
  
  // Calculate potential odds (simplified)
  const calculateOdds = () => {
    if (parlayProbability === 0) return 0;
    return ((100 / parlayProbability) - 1) * 100;
  };

  const potentialOdds = calculateOdds();

  // Determine overall risk level
  const getOverallRisk = (): "low" | "medium" | "high" => {
    if (selectedGames.length === 0) return "medium";
    
    const hasHighRisk = selectedGames.some(g => g.risk_level === "high");
    const hasMediumRisk = selectedGames.some(g => g.risk_level === "medium");
    
    if (hasHighRisk || selectedGames.length >= 4) return "high";
    if (hasMediumRisk || selectedGames.length >= 3) return "medium";
    return "low";
  };

  const overallRisk = getOverallRisk();

  const getRiskIcon = () => {
    switch (overallRisk) {
      case "low": return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case "medium": return <AlertTriangle className="w-5 h-5 text-yellow-500" />;
      case "high": return <AlertTriangle className="w-5 h-5 text-red-500" />;
    }
  };

  const getRiskColor = () => {
    switch (overallRisk) {
      case "low": return "text-green-500";
      case "medium": return "text-yellow-500";
      case "high": return "text-red-500";
    }
  };

  const getRiskExplanation = () => {
    const lowRiskCount = selectedGames.filter(g => g.risk_level === "low").length;
    const mediumRiskCount = selectedGames.filter(g => g.risk_level === "medium").length;
    const highRiskCount = selectedGames.filter(g => g.risk_level === "high").length;
    const avgConfidence = selectedGames.reduce((sum, g) => sum + (g.confidence || 0), 0) / selectedGames.length;

    if (overallRisk === "low") {
      return `Este parlay tiene riesgo BAJO porque ${lowRiskCount === selectedGames.length 
        ? `todos los ${selectedGames.length} picks son de bajo riesgo` 
        : `la mayoría de los picks (${lowRiskCount}/${selectedGames.length}) son de bajo riesgo`} 
        con una confianza promedio de ${avgConfidence.toFixed(0)}%. Los equipos seleccionados tienen ventajas claras basadas en su rendimiento reciente y estadísticas.`;
    }

    if (overallRisk === "medium") {
      let reasons = [];
      if (selectedGames.length === 3) reasons.push("tienes 3 picks");
      if (mediumRiskCount > 0) reasons.push(`${mediumRiskCount} pick${mediumRiskCount > 1 ? 's son' : ' es'} de riesgo medio`);
      if (avgConfidence < 65) reasons.push(`la confianza promedio es ${avgConfidence.toFixed(0)}%`);
      
      return `Este parlay tiene riesgo MEDIO porque ${reasons.join(', ')}. ${
        selectedGames.length === 3 
          ? "Con 3 picks, la probabilidad combinada disminuye considerablemente." 
          : "Algunos juegos tienen márgenes de victoria más ajustados."
      } Aún es una apuesta razonable con análisis cuidadoso.`;
    }

    // High risk
    let reasons = [];
    if (selectedGames.length >= 4) reasons.push(`tienes ${selectedGames.length} picks (más picks = menor probabilidad)`);
    if (highRiskCount > 0) reasons.push(`${highRiskCount} pick${highRiskCount > 1 ? 's son' : ' es'} de alto riesgo`);
    if (avgConfidence < 60) reasons.push(`confianza promedio baja (${avgConfidence.toFixed(0)}%)`);
    
    return `Este parlay tiene riesgo ALTO porque ${reasons.join(', ')}. ${
      parlayProbability < 20 
        ? `Con solo ${parlayProbability.toFixed(1)}% de probabilidad, es muy difícil acertar todos los picks.` 
        : ""
    } Considera reducir el número de picks o elegir juegos con mayor confianza para mejorar tus chances.`;
  };

  return (
    <Card className="glass-card p-6 shadow-card">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-accent" />
          Mi Parlay
        </h3>
        {selectedGames.length > 0 && (
          <Button
            variant="ghost"
            size="sm"
            onClick={onClear}
            className="text-muted-foreground hover:text-destructive"
          >
            Limpiar
          </Button>
        )}
      </div>

      {selectedGames.length === 0 ? (
        <div className="text-center py-12">
          <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="w-8 h-8 text-muted-foreground" />
          </div>
          <p className="text-muted-foreground mb-2">No hay juegos seleccionados</p>
          <p className="text-sm text-muted-foreground">
            Selecciona juegos para crear tu parlay
          </p>
        </div>
      ) : (
        <>
          <div className="space-y-3 mb-6">
            {selectedGames.map((game, index) => (
              <div
                key={game.id}
                className="p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
              >
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex-1">
                    <div className="font-semibold text-sm mb-1">
                      {game.predicted_winner}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      vs {game.predicted_winner === game.home_team ? game.away_team : game.home_team}
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {game.confidence?.toFixed(0)}%
                  </Badge>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={
                    game.risk_level === "low" ? "bg-green-500/10 text-green-500" :
                    game.risk_level === "medium" ? "bg-yellow-500/10 text-yellow-500" :
                    "bg-red-500/10 text-red-500"
                  }>
                    {game.risk_level === "low" ? "Bajo" :
                     game.risk_level === "medium" ? "Medio" : "Alto"}
                  </Badge>
                  <span className="text-xs text-muted-foreground">{game.league}</span>
                </div>
              </div>
            ))}
          </div>

          <Separator className="my-6" />

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Número de picks:</span>
              <span className="font-bold">{selectedGames.length}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Riesgo general:</span>
              <div className="flex items-center gap-2">
                {getRiskIcon()}
                <span className={`font-bold capitalize ${getRiskColor()}`}>
                  {overallRisk === "low" ? "Bajo" :
                   overallRisk === "medium" ? "Medio" : "Alto"}
                </span>
              </div>
            </div>

            <div className="p-4 rounded-lg bg-muted/30 border border-border/50">
              <div className="flex items-start gap-3">
                {getRiskIcon()}
                <div>
                  <h4 className={`font-semibold mb-2 ${getRiskColor()}`}>
                    ¿Por qué {overallRisk === "low" ? "bajo" : overallRisk === "medium" ? "medio" : "alto"} riesgo?
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {getRiskExplanation()}
                  </p>
                </div>
              </div>
            </div>

            <Separator />

            <div className="p-4 rounded-lg bg-primary/5 border border-primary/10">
              <div className="text-center mb-3">
                <div className="text-sm text-muted-foreground mb-1">
                  Probabilidad del Parlay
                </div>
                <div className="text-3xl font-bold text-primary">
                  {parlayProbability.toFixed(1)}%
                </div>
              </div>

              <div className="text-center">
                <div className="text-sm text-muted-foreground mb-1">
                  Ganancia Potencial
                </div>
                <div className="text-2xl font-bold text-accent">
                  +{potentialOdds.toFixed(0)}%
                </div>
              </div>
            </div>

            {overallRisk === "high" && (
              <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/20">
                <div className="flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-destructive mt-0.5" />
                  <p className="text-xs text-destructive">
                    Este parlay tiene alto riesgo. Considera reducir el número de picks o elegir juegos con mayor confianza.
                  </p>
                </div>
              </div>
            )}

            <div className="p-3 rounded-lg bg-accent/10 border border-accent/20">
              <p className="text-xs text-muted-foreground">
                💡 <strong>Tip:</strong> Los parlays con 2-3 picks de bajo riesgo tienen mejor probabilidad de éxito.
              </p>
            </div>
          </div>

          <PlayerMatchupComparison games={selectedGames} />
        </>
      )}
    </Card>
  );
};

export default ParlayBuilder;
