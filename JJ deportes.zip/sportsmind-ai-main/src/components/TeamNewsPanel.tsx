import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { RefreshCw, ExternalLink, AlertCircle, TrendingUp } from "lucide-react";
import { format } from "date-fns";
import { es } from "date-fns/locale";

interface NewsItem {
  id: string;
  league: string;
  team_name: string;
  team_abbreviation: string;
  headline: string;
  description: string | null;
  news_type: string | null;
  published_date: string;
  source_url: string | null;
}

interface TeamNewsPanelProps {
  league: string;
  teamName?: string;
}

export const TeamNewsPanel = ({ league, teamName }: TeamNewsPanelProps) => {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);

  const fetchNews = async () => {
    setIsLoading(true);
    try {
      let query = supabase
        .from('team_news')
        .select('*')
        .eq('league', league)
        .order('published_date', { ascending: false })
        .limit(50);

      if (teamName) {
        query = query.eq('team_name', teamName);
      }

      const { data, error } = await query;

      if (error) throw error;

      setNews(data || []);
    } catch (error) {
      console.error('Error fetching news:', error);
      toast.error('Error al cargar noticias');
    } finally {
      setIsLoading(false);
    }
  };

  const updateNews = async () => {
    setIsUpdating(true);
    try {
      const functionName = `update-${league.toLowerCase()}-news`;
      const { error } = await supabase.functions.invoke(functionName);

      if (error) throw error;

      toast.success('Noticias actualizadas correctamente');
      await fetchNews();
    } catch (error) {
      console.error('Error updating news:', error);
      toast.error('Error al actualizar noticias');
    } finally {
      setIsUpdating(false);
    }
  };

  useEffect(() => {
    fetchNews();
  }, [league, teamName]);

  const getNewsTypeIcon = (type: string | null) => {
    switch (type) {
      case 'injury':
        return <AlertCircle className="h-4 w-4" />;
      case 'return':
        return <TrendingUp className="h-4 w-4" />;
      default:
        return null;
    }
  };

  const getNewsTypeBadge = (type: string | null) => {
    switch (type) {
      case 'injury':
        return <Badge variant="destructive" className="gap-1">
          {getNewsTypeIcon(type)} Lesión
        </Badge>;
      case 'return':
        return <Badge variant="default" className="gap-1 bg-green-600">
          {getNewsTypeIcon(type)} Regreso
        </Badge>;
      default:
        return <Badge variant="secondary">General</Badge>;
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle>Noticias del Equipo</CardTitle>
            <CardDescription>
              Lesiones, regresos y actualizaciones recientes
            </CardDescription>
          </div>
          <Button
            onClick={updateNews}
            disabled={isUpdating}
            size="sm"
            variant="outline"
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isUpdating ? 'animate-spin' : ''}`} />
            Actualizar
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">
            Cargando noticias...
          </div>
        ) : news.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No hay noticias disponibles. Haz clic en "Actualizar" para obtener las últimas noticias.
          </div>
        ) : (
          <ScrollArea className="h-[600px] pr-4">
            <div className="space-y-4">
              {news.map((item) => (
                <Card key={item.id} className="border-l-4 border-l-primary">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Badge variant="outline">{item.team_abbreviation}</Badge>
                          {getNewsTypeBadge(item.news_type)}
                        </div>
                        <CardTitle className="text-base leading-tight">
                          {item.headline}
                        </CardTitle>
                      </div>
                      {item.source_url && (
                        <Button
                          variant="ghost"
                          size="sm"
                          asChild
                          className="shrink-0"
                        >
                          <a
                            href={item.source_url}
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <ExternalLink className="h-4 w-4" />
                          </a>
                        </Button>
                      )}
                    </div>
                  </CardHeader>
                  {item.description && (
                    <CardContent className="pt-0">
                      <p className="text-sm text-muted-foreground line-clamp-3">
                        {item.description}
                      </p>
                      <p className="text-xs text-muted-foreground mt-2">
                        {format(new Date(item.published_date), "d 'de' MMMM, yyyy 'a las' HH:mm", { locale: es })}
                      </p>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          </ScrollArea>
        )}
      </CardContent>
    </Card>
  );
};
