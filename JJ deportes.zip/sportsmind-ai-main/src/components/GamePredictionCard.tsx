import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, MapPin, Calendar } from "lucide-react";
import type { GameWithPrediction } from "@/pages/ParlayAnalyzer";

interface GamePredictionCardProps {
  game: GameWithPrediction;
  selected: boolean;
  onSelect: (gameId: string, selected: boolean) => void;
}

const GamePredictionCard = ({ game, selected, onSelect }: GamePredictionCardProps) => {
  const homeIsWinner = game.predicted_winner === game.home_team;
  const gameDate = new Date(game.game_date);
  
  const getRiskColor = (risk?: string) => {
    switch (risk) {
      case "low": return "bg-green-500/10 text-green-500 border-green-500/20";
      case "medium": return "bg-yellow-500/10 text-yellow-500 border-yellow-500/20";
      case "high": return "bg-red-500/10 text-red-500 border-red-500/20";
      default: return "bg-muted";
    }
  };

  return (
    <Card className={`glass-card p-6 transition-all hover:shadow-lg ${selected ? 'ring-2 ring-accent' : ''}`}>
      <div className="flex items-start gap-4">
        <Checkbox
          checked={selected}
          onCheckedChange={(checked) => onSelect(game.id, checked as boolean)}
          className="mt-1"
        />
        
        <div className="flex-1">
          <div className="flex items-center gap-2 mb-4">
            <Badge variant="outline" className="text-xs">
              {game.league}
            </Badge>
            <Badge className={getRiskColor(game.risk_level)}>
              {game.risk_level === "low" ? "Riesgo Bajo" : 
               game.risk_level === "medium" ? "Riesgo Medio" : "Riesgo Alto"}
            </Badge>
          </div>

          <div className="grid grid-cols-2 gap-6 mb-4">
            {/* Home Team */}
            <div className={`text-center p-4 rounded-lg transition-colors ${
              homeIsWinner ? 'bg-accent/10 border-2 border-accent' : 'bg-muted/50'
            }`}>
              <div className="font-bold text-lg mb-2">{game.home_team}</div>
              <div className="text-sm text-muted-foreground mb-2">Local</div>
              <div className="flex items-center justify-center gap-2">
                <span className="text-2xl font-bold text-primary">
                  {game.home_win_probability?.toFixed(0)}%
                </span>
                {homeIsWinner && <TrendingUp className="w-5 h-5 text-accent" />}
              </div>
            </div>

            {/* Away Team */}
            <div className={`text-center p-4 rounded-lg transition-colors ${
              !homeIsWinner ? 'bg-accent/10 border-2 border-accent' : 'bg-muted/50'
            }`}>
              <div className="font-bold text-lg mb-2">{game.away_team}</div>
              <div className="text-sm text-muted-foreground mb-2">Visitante</div>
              <div className="flex items-center justify-center gap-2">
                <span className="text-2xl font-bold text-primary">
                  {game.away_win_probability?.toFixed(0)}%
                </span>
                {!homeIsWinner && <TrendingUp className="w-5 h-5 text-accent" />}
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between text-sm text-muted-foreground border-t border-border/50 pt-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              <span>{gameDate.toLocaleDateString('es-ES', { 
                weekday: 'short', 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}</span>
            </div>
            {game.venue && (
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span className="truncate max-w-[200px]">{game.venue}</span>
              </div>
            )}
          </div>

          <div className="mt-4 p-3 rounded-lg bg-primary/5 border border-primary/10">
            <div className="flex items-center gap-2 text-sm">
              <TrendingUp className="w-4 h-4 text-accent" />
              <span className="font-semibold">Predicción:</span>
              <span className="text-primary font-bold">{game.predicted_winner}</span>
              <span className="text-muted-foreground">
                ({game.confidence?.toFixed(0)}% confianza)
              </span>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default GamePredictionCard;
