import { useState, useEffect } from "react";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, Users } from "lucide-react";

interface Player {
  id: string;
  player_name: string;
  position: string | null;
  jersey_number: string | null;
  height: string | null;
  weight: string | null;
  age: number | null;
  player_image: string | null;
}

interface Team {
  team_name: string;
  abbreviation: string;
  conference: string;
}

const LEAGUES = [
  { value: "NBA", label: "🏀 NBA", emoji: "🏀" },
  { value: "NFL", label: "🏈 NFL", emoji: "🏈" },
  { value: "MLB", label: "⚾ MLB", emoji: "⚾" },
  { value: "NHL", label: "🏒 NHL", emoji: "🏒" },
  { value: "Soccer", label: "⚽ Soccer", emoji: "⚽" },
];

export const TeamPlayersDropdown = () => {
  const [selectedLeague, setSelectedLeague] = useState<string>("");
  const [selectedTeamAbbr, setSelectedTeamAbbr] = useState<string>("");
  const [teams, setTeams] = useState<Team[]>([]);
  const [roster, setRoster] = useState<Player[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingRoster, setLoadingRoster] = useState(false);

  // Load teams when league changes
  useEffect(() => {
    if (!selectedLeague) {
      setTeams([]);
      setSelectedTeamAbbr("");
      setRoster([]);
      return;
    }

    const loadTeams = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('team_standings')
          .select('team_name, abbreviation, conference')
          .eq('league', selectedLeague)
          .order('team_name');

        if (error) throw error;

        // Remove duplicates by abbreviation
        const uniqueTeams = data.reduce((acc: Team[], team) => {
          if (!acc.find(t => t.abbreviation === team.abbreviation)) {
            acc.push(team);
          }
          return acc;
        }, []);

        setTeams(uniqueTeams);
        setSelectedTeamAbbr("");
        setRoster([]);
      } catch (error) {
        console.error('Error loading teams:', error);
        toast.error("Error al cargar equipos");
      } finally {
        setLoading(false);
      }
    };

    loadTeams();
  }, [selectedLeague]);

  // Load roster when team changes
  useEffect(() => {
    if (!selectedLeague || !selectedTeamAbbr) {
      setRoster([]);
      return;
    }

    const loadRoster = async () => {
      setLoadingRoster(true);
      try {
        const { data, error } = await supabase
          .from('rosters')
          .select('*')
          .eq('league', selectedLeague)
          .eq('team_abbreviation', selectedTeamAbbr)
          .order('jersey_number');

        if (error) throw error;

        setRoster(data || []);
        
        if (data.length === 0) {
          toast.info("No hay jugadores disponibles para este equipo");
        }
      } catch (error) {
        console.error('Error loading roster:', error);
        toast.error("Error al cargar roster");
      } finally {
        setLoadingRoster(false);
      }
    };

    loadRoster();
  }, [selectedLeague, selectedTeamAbbr]);

  const selectedTeam = teams.find(t => t.abbreviation === selectedTeamAbbr);
  const selectedLeagueData = LEAGUES.find(l => l.value === selectedLeague);

  // Group teams by conference
  const teamsByConference = teams.reduce((acc, team) => {
    if (!acc[team.conference]) {
      acc[team.conference] = [];
    }
    acc[team.conference].push(team);
    return acc;
  }, {} as Record<string, Team[]>);

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* League Selector */}
      <div className="space-y-2">
        <label className="text-sm font-medium text-foreground">
          Selecciona una Liga
        </label>
        <Select value={selectedLeague} onValueChange={setSelectedLeague}>
          <SelectTrigger className="w-full bg-card/50 backdrop-blur-sm border-primary/20">
            <SelectValue placeholder="Elige una liga..." />
          </SelectTrigger>
          <SelectContent className="bg-popover backdrop-blur-md border-primary/20 z-50">
            {LEAGUES.map((league) => (
              <SelectItem 
                key={league.value} 
                value={league.value}
                className="cursor-pointer hover:bg-accent/50"
              >
                {league.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Team Selector */}
      {selectedLeague && (
        <div className="space-y-2 animate-in fade-in slide-in-from-top-4 duration-500">
          <label className="text-sm font-medium text-foreground">
            Selecciona un equipo {selectedLeagueData?.emoji}
          </label>
          {loading ? (
            <div className="flex items-center justify-center p-4 bg-card/50 rounded-lg border border-primary/20">
              <Loader2 className="w-6 h-6 animate-spin text-primary" />
              <span className="ml-2 text-muted-foreground">Cargando equipos...</span>
            </div>
          ) : (
            <Select value={selectedTeamAbbr} onValueChange={setSelectedTeamAbbr}>
              <SelectTrigger className="w-full bg-card/50 backdrop-blur-sm border-primary/20">
                <SelectValue placeholder="Elige un equipo..." />
              </SelectTrigger>
              <SelectContent className="bg-popover backdrop-blur-md border-primary/20 z-50">
                {Object.entries(teamsByConference).map(([conference, conferenceTeams]) => (
                  <SelectGroup key={conference}>
                    <SelectLabel className="text-primary font-semibold">
                      {conference}
                    </SelectLabel>
                    {conferenceTeams.map((team) => (
                      <SelectItem 
                        key={team.abbreviation} 
                        value={team.abbreviation}
                        className="cursor-pointer hover:bg-accent/50"
                      >
                        {team.team_name} ({team.abbreviation})
                      </SelectItem>
                    ))}
                  </SelectGroup>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>
      )}

      {/* Roster Display */}
      {selectedTeam && (
        <Card className="p-6 bg-card/30 backdrop-blur-lg border-primary/20 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="space-y-4">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 rounded-full bg-primary/10 text-primary">
                  <Users className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                    {selectedTeam.team_name}
                  </h3>
                  <p className="text-sm text-muted-foreground">{selectedLeague}</p>
                </div>
              </div>
              <div className="flex gap-2">
                <Badge variant="outline" className="text-sm">
                  {selectedTeam.conference}
                </Badge>
                <Badge variant="secondary" className="text-sm">
                  {selectedTeam.abbreviation}
                </Badge>
              </div>
            </div>

            <div className="h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent" />
            
            {loadingRoster ? (
              <div className="flex items-center justify-center p-8">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
                <span className="ml-2 text-muted-foreground">Cargando roster...</span>
              </div>
            ) : roster.length > 0 ? (
              <div className="grid gap-3">
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide">
                    Roster Completo
                  </h4>
                  <Badge variant="default" className="text-xs">
                    {roster.length} jugadores
                  </Badge>
                </div>
                
                <div className="grid gap-2">
                  {roster.map((player) => (
                    <div
                      key={player.id}
                      className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-border/50 hover:border-primary/50 transition-all duration-300 hover:scale-[1.01]"
                    >
                      <div className="flex items-center gap-3 flex-1">
                        {player.player_image ? (
                          <img 
                            src={player.player_image} 
                            alt={player.player_name}
                            className="w-12 h-12 rounded-full object-cover border-2 border-primary/20"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                              e.currentTarget.nextElementSibling?.classList.remove('hidden');
                            }}
                          />
                        ) : null}
                        <div className={`flex items-center justify-center min-w-[2.5rem] h-10 rounded-full bg-primary/10 text-primary font-bold text-sm ${player.player_image ? 'hidden' : ''}`}>
                          {player.jersey_number ? `#${player.jersey_number}` : "—"}
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-foreground">{player.player_name}</p>
                          <div className="flex flex-wrap gap-2 mt-1">
                            {player.position && (
                              <Badge variant="outline" className="text-xs">
                                {player.position}
                              </Badge>
                            )}
                            {player.height && (
                              <span className="text-xs text-muted-foreground">
                                {player.height}
                              </span>
                            )}
                            {player.weight && (
                              <span className="text-xs text-muted-foreground">
                                {player.weight} lbs
                              </span>
                            )}
                            {player.age && (
                              <span className="text-xs text-muted-foreground">
                                {player.age} años
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center p-8 text-center">
                <Users className="w-12 h-12 text-muted-foreground/30 mb-2" />
                <p className="text-muted-foreground">No hay jugadores disponibles</p>
                <p className="text-xs text-muted-foreground/70 mt-1">
                  Actualiza el roster desde el panel de gestión
                </p>
              </div>
            )}
          </div>
        </Card>
      )}
    </div>
  );
};
