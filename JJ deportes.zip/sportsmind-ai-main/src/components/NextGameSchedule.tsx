import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Calendar, MapPin, Clock } from "lucide-react";
import { format } from "date-fns";

type League = "NBA" | "NFL" | "MLB" | "NHL" | "Soccer";

interface NextGameScheduleProps {
  league: League;
}

interface Game {
  id: string;
  league: string;
  game_id: string;
  home_team: string;
  home_team_abbreviation: string;
  away_team: string;
  away_team_abbreviation: string;
  game_date: string;
  venue: string | null;
  status: string;
  home_score: number | null;
  away_score: number | null;
}

export const NextGameSchedule = ({ league }: NextGameScheduleProps) => {
  const { data: games, isLoading } = useQuery({
    queryKey: ["game-schedule", league],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("game_schedule")
        .select("*")
        .eq("league", league)
        .gte("game_date", new Date().toISOString())
        .order("game_date", { ascending: true })
        .limit(5);

      if (error) throw error;
      return data as Game[];
    },
  });

  if (isLoading) {
    return (
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            Upcoming Games
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!games || games.length === 0) {
    return (
      <Card className="glass-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5 text-primary" />
            Upcoming Games
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground text-center py-8">
            No upcoming games scheduled
          </p>
        </CardContent>
      </Card>
    );
  }

  const nextGame = games[0];

  return (
    <div className="space-y-6">
      {/* Next Game - Featured */}
      <Card className="glass-card overflow-hidden border-primary/20">
        <div className="gradient-primary p-1">
          <div className="bg-card rounded-t-lg">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-2xl">Next Game</CardTitle>
                <span className="px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                  {nextGame.status}
                </span>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Teams */}
                <div className="flex items-center justify-between gap-4">
                  <div className="flex-1 text-center">
                    <div className="text-sm text-muted-foreground mb-2">Away</div>
                    <div className="text-xl font-bold">{nextGame.away_team_abbreviation}</div>
                    <div className="text-sm text-muted-foreground mt-1">{nextGame.away_team}</div>
                  </div>
                  
                  <div className="text-3xl font-bold text-muted-foreground">VS</div>
                  
                  <div className="flex-1 text-center">
                    <div className="text-sm text-muted-foreground mb-2">Home</div>
                    <div className="text-xl font-bold">{nextGame.home_team_abbreviation}</div>
                    <div className="text-sm text-muted-foreground mt-1">{nextGame.home_team}</div>
                  </div>
                </div>

                {/* Game Details */}
                <div className="flex flex-col gap-2 pt-4 border-t border-border">
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-primary" />
                    <span className="text-muted-foreground">
                      {format(new Date(nextGame.game_date), "EEEE, MMMM d, yyyy")}
                    </span>
                    <span className="font-medium">
                      {format(new Date(nextGame.game_date), "h:mm a")}
                    </span>
                  </div>
                  {nextGame.venue && (
                    <div className="flex items-center gap-2 text-sm">
                      <MapPin className="h-4 w-4 text-primary" />
                      <span className="text-muted-foreground">{nextGame.venue}</span>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </div>
        </div>
      </Card>

      {/* Upcoming Games */}
      {games.length > 1 && (
        <Card className="glass-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Upcoming Schedule
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {games.slice(1).map((game) => (
                <div
                  key={game.id}
                  className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary/70 transition-colors"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="text-center min-w-[60px]">
                      <div className="text-xs text-muted-foreground">
                        {format(new Date(game.game_date), "MMM d")}
                      </div>
                      <div className="text-sm font-medium">
                        {format(new Date(game.game_date), "h:mm a")}
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="font-medium">{game.away_team_abbreviation}</span>
                      <span className="text-muted-foreground text-sm">@</span>
                      <span className="font-medium">{game.home_team_abbreviation}</span>
                    </div>
                  </div>
                  <span className="px-2 py-1 rounded text-xs font-medium bg-primary/10 text-primary">
                    {game.status}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};