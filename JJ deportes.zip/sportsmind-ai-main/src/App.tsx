import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Standings from "./pages/Standings";
import Predictions from "./pages/Predictions";
import ParlayAnalyzer from "./pages/ParlayAnalyzer";
import PlayerProps from "./pages/PlayerProps";
import TeamFeatures from "./pages/TeamFeatures";
import PlayerFutures from "./pages/PlayerFutures";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/standings" element={<Standings />} />
            <Route path="/predictions" element={<Predictions />} />
            <Route path="/parlay-analyzer" element={<ParlayAnalyzer />} />
            <Route path="/player-props" element={<PlayerProps />} />
            <Route path="/team-features" element={<TeamFeatures />} />
            <Route path="/player-futures" element={<PlayerFutures />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;
