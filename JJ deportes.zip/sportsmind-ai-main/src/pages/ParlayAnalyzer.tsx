import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import Navbar from "@/components/Navbar";
import LeagueSelector, { League } from "@/components/LeagueSelector";
import GamePredictionCard from "@/components/GamePredictionCard";
import ParlayBuilder from "@/components/ParlayBuilder";
import { SportsChatbot } from "@/components/SportsChatbot";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Loader2, TrendingUp } from "lucide-react";

export interface GameWithPrediction {
  id: string;
  game_id: string;
  home_team: string;
  away_team: string;
  game_date: string;
  venue: string | null;
  league: string;
  home_win_probability?: number;
  away_win_probability?: number;
  predicted_winner?: string;
  confidence?: number;
  risk_level?: "low" | "medium" | "high";
}

const ParlayAnalyzer = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedLeague, setSelectedLeague] = useState<League>(
    (searchParams.get("league") as League) || "NBA"
  );
  const [games, setGames] = useState<GameWithPrediction[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGames, setSelectedGames] = useState<Set<string>>(new Set());

  useEffect(() => {
    setSearchParams({ league: selectedLeague });
    fetchGamesWithPredictions();
  }, [selectedLeague]);

  const fetchGamesWithPredictions = async () => {
    setLoading(true);
    try {
      // Get today's date and next 7 days
      const today = new Date();
      const nextWeek = new Date();
      nextWeek.setDate(today.getDate() + 7);

      // Fetch games
      const { data: gamesData, error: gamesError } = await supabase
        .from("game_schedule")
        .select("*")
        .eq("league", selectedLeague)
        .gte("game_date", today.toISOString())
        .lte("game_date", nextWeek.toISOString())
        .order("game_date", { ascending: true })
        .limit(20);

      if (gamesError) throw gamesError;

      // Fetch standings for probability calculation
      const { data: standingsData, error: standingsError } = await supabase
        .from("team_standings")
        .select("*")
        .eq("league", selectedLeague);

      if (standingsError) throw standingsError;

      // Calculate predictions for each game
      const gamesWithPredictions = gamesData?.map((game) => {
        const homeStanding = standingsData?.find(
          (s) => s.team_name === game.home_team || s.abbreviation === game.home_team_abbreviation
        );
        const awayStanding = standingsData?.find(
          (s) => s.team_name === game.away_team || s.abbreviation === game.away_team_abbreviation
        );

        const homePct = homeStanding ? parseFloat(homeStanding.pct.toString()) : 0.5;
        const awayPct = awayStanding ? parseFloat(awayStanding.pct.toString()) : 0.5;

        // Calculate home advantage (typically 5-7% boost)
        const homeAdvantage = 0.06;
        
        // Adjust for home advantage
        let homeWinProb = homePct + homeAdvantage;
        let awayWinProb = awayPct;

        // Normalize probabilities
        const total = homeWinProb + awayWinProb;
        homeWinProb = (homeWinProb / total) * 100;
        awayWinProb = (awayWinProb / total) * 100;

        const predictedWinner = homeWinProb > awayWinProb ? game.home_team : game.away_team;
        const confidence = Math.max(homeWinProb, awayWinProb);

        // Determine risk level based on confidence
        let riskLevel: "low" | "medium" | "high";
        if (confidence >= 65) riskLevel = "low";
        else if (confidence >= 55) riskLevel = "medium";
        else riskLevel = "high";

        return {
          ...game,
          home_win_probability: homeWinProb,
          away_win_probability: awayWinProb,
          predicted_winner: predictedWinner,
          confidence,
          risk_level: riskLevel,
        };
      }) || [];

      setGames(gamesWithPredictions);
    } catch (error) {
      console.error("Error fetching games:", error);
      toast.error("Error al cargar los juegos");
    } finally {
      setLoading(false);
    }
  };

  const handleGameSelect = (gameId: string, selected: boolean) => {
    const newSelected = new Set(selectedGames);
    if (selected) {
      newSelected.add(gameId);
    } else {
      newSelected.delete(gameId);
    }
    setSelectedGames(newSelected);
  };

  const selectedGamesList = games.filter((g) => selectedGames.has(g.id));

  // Filter games by date
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const todayGames = games.filter((g) => {
    const gameDate = new Date(g.game_date);
    gameDate.setHours(0, 0, 0, 0);
    return gameDate.getTime() === today.getTime();
  });

  const tomorrowGames = games.filter((g) => {
    const gameDate = new Date(g.game_date);
    gameDate.setHours(0, 0, 0, 0);
    return gameDate.getTime() === tomorrow.getTime();
  });

  const upcomingGames = games.filter((g) => {
    const gameDate = new Date(g.game_date);
    gameDate.setHours(0, 0, 0, 0);
    return gameDate.getTime() > tomorrow.getTime();
  });

  return (
    <div className="min-h-screen gradient-hero">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h1 className="text-4xl md:text-5xl font-bold mb-4 flex items-center justify-center gap-3">
              <TrendingUp className="w-10 h-10 text-accent" />
              Análisis de Parlays
            </h1>
            <p className="text-muted-foreground text-lg">
              Predicciones inteligentes basadas en estadísticas y rendimiento actual
            </p>
          </div>

          <div className="mb-8">
            <LeagueSelector selected={selectedLeague} onSelect={setSelectedLeague} />
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-8 h-8 animate-spin text-accent" />
            </div>
          ) : (
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                <SportsChatbot league={selectedLeague} />
                
                <Tabs defaultValue="today" className="w-full">
                  <TabsList className="grid w-full grid-cols-3 mb-6">
                    <TabsTrigger value="today">
                      Hoy ({todayGames.length})
                    </TabsTrigger>
                    <TabsTrigger value="tomorrow">
                      Mañana ({tomorrowGames.length})
                    </TabsTrigger>
                    <TabsTrigger value="upcoming">
                      Próximos ({upcomingGames.length})
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="today" className="space-y-4">
                    {todayGames.length === 0 ? (
                      <Card className="glass-card p-8 text-center">
                        <p className="text-muted-foreground">No hay juegos programados para hoy</p>
                      </Card>
                    ) : (
                      todayGames.map((game) => (
                        <GamePredictionCard
                          key={game.id}
                          game={game}
                          selected={selectedGames.has(game.id)}
                          onSelect={handleGameSelect}
                        />
                      ))
                    )}
                  </TabsContent>

                  <TabsContent value="tomorrow" className="space-y-4">
                    {tomorrowGames.length === 0 ? (
                      <Card className="glass-card p-8 text-center">
                        <p className="text-muted-foreground">No hay juegos programados para mañana</p>
                      </Card>
                    ) : (
                      tomorrowGames.map((game) => (
                        <GamePredictionCard
                          key={game.id}
                          game={game}
                          selected={selectedGames.has(game.id)}
                          onSelect={handleGameSelect}
                        />
                      ))
                    )}
                  </TabsContent>

                  <TabsContent value="upcoming" className="space-y-4">
                    {upcomingGames.length === 0 ? (
                      <Card className="glass-card p-8 text-center">
                        <p className="text-muted-foreground">No hay juegos próximos</p>
                      </Card>
                    ) : (
                      upcomingGames.map((game) => (
                        <GamePredictionCard
                          key={game.id}
                          game={game}
                          selected={selectedGames.has(game.id)}
                          onSelect={handleGameSelect}
                        />
                      ))
                    )}
                  </TabsContent>
                </Tabs>
              </div>

              <div className="lg:col-span-1">
                <div className="sticky top-24">
                  <ParlayBuilder
                    selectedGames={selectedGamesList}
                    onClear={() => setSelectedGames(new Set())}
                  />
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

export default ParlayAnalyzer;
