import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import Navbar from "@/components/Navbar";
import LeagueSelector, { League } from "@/components/LeagueSelector";
import { StandingsManager } from "@/components/StandingsManager";
import { TeamNewsPanel } from "@/components/TeamNewsPanel";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, TrendingUp, TrendingDown, Users, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";

interface TeamStanding {
  rank: number;
  team: string;
  wins: number;
  losses: number;
  pct: number;
  gb: string;
  home: string;
  away: string;
  div: string;
  conf: string;
  ppg: number;
  oppPpg: number;
  diff: string;
  streak: string;
  l10: string;
}

interface ConferenceStandings {
  conference: string;
  teams: TeamStanding[];
}

interface Player {
  id: string;
  player_name: string;
  position: string | null;
  jersey_number: string | null;
  height: string | null;
  weight: string | null;
  age: number | null;
  player_image: string | null;
}

const Standings = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedLeague, setSelectedLeague] = useState<League>(
    (searchParams.get("league") as League) || "NBA"
  );
  const [standings, setStandings] = useState<ConferenceStandings[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedTeam, setSelectedTeam] = useState<string | null>(null);
  const [roster, setRoster] = useState<Player[]>([]);
  const [loadingRoster, setLoadingRoster] = useState(false);

  useEffect(() => {
    setSearchParams({ league: selectedLeague });
    fetchStandings();
  }, [selectedLeague]);

  useEffect(() => {
    // Subscribe to realtime updates
    const channel = supabase
      .channel('standings-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'team_standings',
          filter: `league=eq.${selectedLeague}`
        },
        () => {
          console.log('Standings updated, refreshing...');
          fetchStandings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [selectedLeague]);

  const fetchStandings = async () => {
    setLoading(true);
    
    try {
      const { data, error } = await supabase
        .from('team_standings')
        .select('*')
        .eq('league', selectedLeague)
        .order('conference')
        .order('wins', { ascending: false });

      if (error) throw error;

      if (!data || data.length === 0) {
        setStandings([]);
        toast.info(`No hay datos de standings para ${selectedLeague}. Usa el gestor para agregar equipos.`);
        setLoading(false);
        return;
      }

      // Group by conference dynamically
      const conferenceMap = new Map<string, TeamStanding[]>();
      
      data.forEach(team => {
        const conferenceName = team.conference;
        const conferenceTeams = data.filter(t => t.conference === conferenceName);
        
        const teamData: TeamStanding = {
          rank: team.rank,
          team: team.team_name,
          wins: team.wins,
          losses: team.losses,
          pct: team.pct,
          gb: calculateGB(conferenceTeams, team),
          home: team.home_record || '-',
          away: team.away_record || '-',
          div: team.division_record || '-',
          conf: team.conference_record || '-',
          ppg: team.ppg || 0,
          oppPpg: team.opp_ppg || 0,
          diff: formatDiff(team.diff || 0),
          streak: team.streak || '-',
          l10: team.last_10 || '-',
        };

        if (!conferenceMap.has(conferenceName)) {
          conferenceMap.set(conferenceName, []);
        }
        conferenceMap.get(conferenceName)!.push(teamData);
      });

      const conferences: ConferenceStandings[] = Array.from(conferenceMap.entries()).map(
        ([conferenceName, teams]) => ({
          conference: conferenceName,
          teams: teams.sort((a, b) => b.wins - a.wins),
        })
      );
      
      setStandings(conferences);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching standings:', error);
      toast.error("Error al cargar las standings");
      setLoading(false);
    }
  };

  const calculateGB = (conferenceTeams: any[], currentTeam: any): string => {
    if (!conferenceTeams || conferenceTeams.length === 0) return "-";
    
    const leader = conferenceTeams.reduce((prev, current) => 
      (current.rank < prev.rank) ? current : prev
    );
    
    if (currentTeam.rank === leader.rank) return "-";
    
    const gb = ((leader.wins - currentTeam.wins) + (currentTeam.losses - leader.losses)) / 2;
    return gb > 0 ? gb.toFixed(1) : "-";
  };

  const formatDiff = (diff: number): string => {
    if (diff > 0) return `+${diff.toFixed(1)}`;
    if (diff < 0) return diff.toFixed(1);
    return "0.0";
  };

  const getStreakIcon = (streak: string) => {
    if (streak.startsWith("W")) {
      return <TrendingUp className="w-4 h-4 text-accent" />;
    }
    return <TrendingDown className="w-4 h-4 text-destructive" />;
  };

  const handleTeamClick = async (teamName: string) => {
    setSelectedTeam(teamName);
    setLoadingRoster(true);
    
    try {
      const { data, error } = await supabase
        .from('rosters')
        .select('*')
        .eq('league', selectedLeague)
        .eq('team_name', teamName)
        .order('jersey_number');

      if (error) throw error;

      setRoster(data || []);
      
      if (data.length === 0) {
        toast.info("No hay jugadores disponibles para este equipo");
      }
    } catch (error) {
      console.error('Error loading roster:', error);
      toast.error("Error al cargar roster");
    } finally {
      setLoadingRoster(false);
    }
  };

  return (
    <div className="min-h-screen gradient-hero">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-4xl md:text-5xl font-bold text-center mb-8">
              League Standings
            </h1>
            
            <div className="mb-8">
              <LeagueSelector selected={selectedLeague} onSelect={setSelectedLeague} />
            </div>

            <Tabs defaultValue="standings" className="w-full">
              <TabsList className="grid w-full max-w-2xl mx-auto grid-cols-3 mb-8">
                <TabsTrigger value="standings">Ver Standings</TabsTrigger>
                <TabsTrigger value="news">Noticias</TabsTrigger>
                <TabsTrigger value="manage">Gestionar</TabsTrigger>
              </TabsList>

              <TabsContent value="standings">
                {loading ? (
                  <Card className="glass-card p-6 shadow-card">
                    <div className="text-center py-8 text-muted-foreground">
                      Loading standings...
                    </div>
                  </Card>
                ) : standings.length === 0 ? (
                  <Card className="glass-card p-6 shadow-card">
                    <div className="text-center py-8 text-muted-foreground">
                      No hay standings disponibles. Ve a la pestaña "Gestionar" para agregar equipos.
                    </div>
                  </Card>
                ) : (
                  <div className="space-y-8">
                    {standings.map((conferenceData) => (
                      <Card key={conferenceData.conference} className="glass-card p-6 shadow-card">
                        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
                          {conferenceData.conference}
                        </h2>
                        <div className="overflow-x-auto">
                          <table className="w-full text-sm">
                            <thead>
                              <tr className="border-b border-border/50">
                                <th className="text-left py-3 px-2 font-bold">#</th>
                                <th className="text-left py-3 px-2 font-bold min-w-[180px]">Team</th>
                                <th className="text-center py-3 px-2 font-bold">W</th>
                                <th className="text-center py-3 px-2 font-bold">L</th>
                                <th className="text-center py-3 px-2 font-bold">PCT</th>
                                <th className="text-center py-3 px-2 font-bold">GB</th>
                                <th className="text-center py-3 px-2 font-bold">HOME</th>
                                <th className="text-center py-3 px-2 font-bold">AWAY</th>
                                <th className="text-center py-3 px-2 font-bold">PPG</th>
                                <th className="text-center py-3 px-2 font-bold">DIFF</th>
                                <th className="text-center py-3 px-2 font-bold">STRK</th>
                                <th className="text-center py-3 px-2 font-bold">L10</th>
                              </tr>
                            </thead>
                            <tbody>
                              {conferenceData.teams.map((team) => (
                                <tr 
                                  key={`${conferenceData.conference}-${team.rank}`}
                                  className="border-b border-border/30 hover:bg-muted/50 transition-colors"
                                >
                                  <td className="py-3 px-2">
                                    <div className="flex items-center gap-1">
                                      {team.rank === 1 && (
                                        <Trophy className="w-3 h-3 text-accent" />
                                      )}
                                      <span className="font-medium">{team.rank}</span>
                                    </div>
                                  </td>
                                   <td 
                                     className="py-3 px-2 font-semibold cursor-pointer hover:text-primary transition-colors"
                                     onClick={() => handleTeamClick(team.team)}
                                   >
                                     {team.team}
                                   </td>
                                  <td className="py-3 px-2 text-center text-accent font-bold">{team.wins}</td>
                                  <td className="py-3 px-2 text-center text-muted-foreground">{team.losses}</td>
                                  <td className="py-3 px-2 text-center">
                                    <Badge variant="secondary" className="text-xs">
                                      {team.pct.toFixed(3)}
                                    </Badge>
                                  </td>
                                  <td className="py-3 px-2 text-center text-muted-foreground">{team.gb}</td>
                                  <td className="py-3 px-2 text-center text-xs">{team.home}</td>
                                  <td className="py-3 px-2 text-center text-xs">{team.away}</td>
                                  <td className="py-3 px-2 text-center font-medium">{team.ppg.toFixed(1)}</td>
                                  <td className={`py-3 px-2 text-center font-medium ${
                                    team.diff.startsWith('+') ? 'text-accent' : 
                                    team.diff.startsWith('-') ? 'text-destructive' : 
                                    'text-muted-foreground'
                                  }`}>
                                    {team.diff}
                                  </td>
                                  <td className="py-3 px-2">
                                    <div className="flex items-center justify-center gap-1">
                                      {getStreakIcon(team.streak)}
                                      <span className="font-medium text-xs">{team.streak}</span>
                                    </div>
                                  </td>
                                  <td className="py-3 px-2 text-center text-xs">{team.l10}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>

              <TabsContent value="news">
                <TeamNewsPanel league={selectedLeague} />
              </TabsContent>

              <TabsContent value="manage">
                <StandingsManager />
              </TabsContent>
            </Tabs>

          </div>
        </div>
      </main>

      <Dialog open={!!selectedTeam} onOpenChange={(open) => !open && setSelectedTeam(null)}>
        <DialogContent className="max-w-6xl max-h-[85vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              {selectedTeam}
            </DialogTitle>
          </DialogHeader>
          
          <Tabs defaultValue="roster" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="roster">Roster</TabsTrigger>
              <TabsTrigger value="news">Noticias</TabsTrigger>
            </TabsList>

            <TabsContent value="roster" className="mt-4">
              {loadingRoster ? (
                <div className="flex items-center justify-center p-8">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                  <span className="ml-2 text-muted-foreground">Cargando roster...</span>
                </div>
              ) : roster.length > 0 ? (
                <ScrollArea className="h-[500px]">
                  <div className="grid gap-2">
                    {roster.map((player) => (
                      <div
                        key={player.id}
                        className="flex items-center justify-between p-4 rounded-lg bg-background/50 border border-border/50 hover:border-primary/50 transition-all duration-300"
                      >
                        <div className="flex items-center gap-3 flex-1">
                          {player.player_image ? (
                            <img 
                              src={player.player_image} 
                              alt={player.player_name}
                              className="w-12 h-12 rounded-full object-cover border-2 border-primary/20"
                              onError={(e) => {
                                e.currentTarget.style.display = 'none';
                                e.currentTarget.nextElementSibling?.classList.remove('hidden');
                              }}
                            />
                          ) : null}
                          <div className={`flex items-center justify-center min-w-[2.5rem] h-10 rounded-full bg-primary/10 text-primary font-bold text-sm ${player.player_image ? 'hidden' : ''}`}>
                            {player.jersey_number ? `#${player.jersey_number}` : "—"}
                          </div>
                          <div className="flex-1">
                            <p className="font-semibold text-foreground">{player.player_name}</p>
                            <div className="flex flex-wrap gap-2 mt-1">
                              {player.position && (
                                <Badge variant="outline" className="text-xs">
                                  {player.position}
                                </Badge>
                              )}
                              {player.height && (
                                <span className="text-xs text-muted-foreground">
                                  {player.height}
                                </span>
                              )}
                              {player.weight && (
                                <span className="text-xs text-muted-foreground">
                                  {player.weight} lbs
                                </span>
                              )}
                              {player.age && (
                                <span className="text-xs text-muted-foreground">
                                  {player.age} años
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              ) : (
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <Users className="w-12 h-12 text-muted-foreground/30 mb-2" />
                  <p className="text-muted-foreground">No hay jugadores disponibles</p>
                  <p className="text-xs text-muted-foreground/70 mt-1">
                    Los datos del roster aún no han sido actualizados
                  </p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="news" className="mt-4">
              <TeamNewsPanel league={selectedLeague} teamName={selectedTeam} />
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Standings;
