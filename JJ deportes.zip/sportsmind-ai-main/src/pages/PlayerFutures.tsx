import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import LeagueSelector, { type League } from "@/components/LeagueSelector";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Trophy, TrendingUp, TrendingDown, Minus } from "lucide-react";
import { toast } from "sonner";

interface PlayerFuture {
  player_name: string;
  team_name: string;
  team_abbreviation: string;
  category: string;
  projected_value: number;
  current_rank: number;
  games_analyzed: number;
  last_10_avg: number;
  season_avg: number;
  trend: string;
}

export default function PlayerFutures() {
  const [league, setLeague] = useState<League>("NBA");
  const [futures, setFutures] = useState<PlayerFuture[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("points_leader");

  useEffect(() => {
    loadPlayerFutures();
  }, [league]);

  const loadPlayerFutures = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('player_futures')
        .select('*')
        .eq('league', league)
        .order('current_rank', { ascending: true });

      if (error) throw error;
      setFutures(data || []);
    } catch (error: any) {
      console.error('Error loading player futures:', error);
      toast.error('Error al cargar proyecciones');
    } finally {
      setLoading(false);
    }
  };

  const categories = [
    { value: 'points_leader', label: 'Líder en Puntos' },
    { value: 'rebounds_leader', label: 'Líder en Rebotes' },
    { value: 'assists_leader', label: 'Líder en Asistencias' },
    { value: 'steals_leader', label: 'Líder en Robos' },
    { value: 'blocks_leader', label: 'Líder en Bloqueos' },
  ];

  const getCategoryFutures = (category: string) => {
    return futures
      .filter(f => f.category === category)
      .slice(0, 10);
  };

  const getTrendIcon = (trend: string) => {
    if (trend === 'up') return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (trend === 'down') return <TrendingDown className="h-4 w-4 text-red-500" />;
    return <Minus className="h-4 w-4 text-yellow-500" />;
  };

  const getTrendBadge = (trend: string) => {
    const variants = {
      up: 'default',
      down: 'destructive',
      stable: 'secondary'
    };
    const labels = {
      up: '↑ En alza',
      down: '↓ A la baja',
      stable: '→ Estable'
    };
    return (
      <Badge variant={variants[trend as keyof typeof variants] as any}>
        {labels[trend as keyof typeof labels]}
      </Badge>
    );
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container py-8 space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold flex items-center gap-2">
            <Trophy className="h-10 w-10" />
            Player Futures
          </h1>
          <p className="text-muted-foreground">
            Proyecciones y líderes en estadísticas para la temporada
          </p>
        </div>

        <LeagueSelector selected={league} onSelect={setLeague} />

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
            <p className="mt-4 text-muted-foreground">Cargando proyecciones...</p>
          </div>
        ) : (
          <Tabs value={selectedCategory} onValueChange={setSelectedCategory}>
            <TabsList className="grid grid-cols-5 w-full">
              {categories.map(cat => (
                <TabsTrigger key={cat.value} value={cat.value}>
                  {cat.label}
                </TabsTrigger>
              ))}
            </TabsList>

            {categories.map(cat => (
              <TabsContent key={cat.value} value={cat.value} className="space-y-4">
                {getCategoryFutures(cat.value).map((future) => (
                  <Card key={`${future.player_name}-${future.category}`}>
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="space-y-1">
                          <CardTitle className="flex items-center gap-2">
                            {future.current_rank <= 3 && (
                              <Trophy className={`h-6 w-6 ${
                                future.current_rank === 1 ? 'text-yellow-500' :
                                future.current_rank === 2 ? 'text-gray-400' :
                                'text-amber-600'
                              }`} />
                            )}
                            <span className="text-2xl font-bold text-muted-foreground">#{future.current_rank}</span>
                            {future.player_name}
                            <Badge variant="outline">{future.team_abbreviation}</Badge>
                          </CardTitle>
                          <CardDescription>
                            {future.team_name} • {future.games_analyzed} partidos analizados
                          </CardDescription>
                        </div>
                        <div className="flex items-center gap-2">
                          {getTrendIcon(future.trend)}
                          {getTrendBadge(future.trend)}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-4 gap-4">
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Proyección Total</p>
                          <p className="text-3xl font-bold">{future.projected_value.toFixed(0)}</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Promedio Temporada</p>
                          <p className="text-2xl font-bold">{future.season_avg}</p>
                          <p className="text-xs text-muted-foreground">por partido</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Últimos 10</p>
                          <p className="text-2xl font-bold">{future.last_10_avg}</p>
                          <p className="text-xs text-muted-foreground">por partido</p>
                        </div>
                        <div className="space-y-1">
                          <p className="text-sm text-muted-foreground">Diferencia</p>
                          <p className={`text-2xl font-bold ${
                            future.last_10_avg > future.season_avg ? 'text-green-500' : 'text-red-500'
                          }`}>
                            {future.last_10_avg > future.season_avg ? '+' : ''}
                            {(future.last_10_avg - future.season_avg).toFixed(1)}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {getCategoryFutures(cat.value).length === 0 && (
                  <Card>
                    <CardContent className="py-12 text-center">
                      <p className="text-muted-foreground">No hay proyecciones disponibles</p>
                    </CardContent>
                  </Card>
                )}
              </TabsContent>
            ))}
          </Tabs>
        )}
      </div>
    </div>
  );
}