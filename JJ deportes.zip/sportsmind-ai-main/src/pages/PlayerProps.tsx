import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import LeagueSelector, { type League } from "@/components/LeagueSelector";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Minus, Search } from "lucide-react";
import { toast } from "sonner";

interface PlayerStat {
  player_name: string;
  team_abbreviation: string;
  points: number;
  rebounds: number;
  assists: number;
  steals: number;
  blocks: number;
  game_date: string;
}

export default function PlayerProps() {
  const [league, setLeague] = useState<League>("NBA");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedStat, setSelectedStat] = useState("points");
  const [playerStats, setPlayerStats] = useState<Map<string, PlayerStat[]>>(new Map());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadPlayerStats();
  }, [league]);

  const loadPlayerStats = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('player_stats')
        .select('*')
        .eq('league', league)
        .order('game_date', { ascending: false });

      if (error) throw error;

      // Group by player
      const grouped = new Map<string, PlayerStat[]>();
      data?.forEach(stat => {
        const key = stat.player_name;
        if (!grouped.has(key)) {
          grouped.set(key, []);
        }
        grouped.get(key)!.push(stat);
      });

      setPlayerStats(grouped);
    } catch (error: any) {
      console.error('Error loading player stats:', error);
      toast.error('Error al cargar estadísticas');
    } finally {
      setLoading(false);
    }
  };

  const calculatePlayerAverage = (stats: PlayerStat[], statType: string): string => {
    if (stats.length === 0) return '0.0';
    const total = stats.reduce((sum, stat) => sum + (stat[statType as keyof PlayerStat] as number || 0), 0);
    return (total / stats.length).toFixed(1);
  };

  const calculateLast10Average = (stats: PlayerStat[], statType: string): string => {
    const last10 = stats.slice(0, 10);
    if (last10.length === 0) return '0.0';
    const total = last10.reduce((sum, stat) => sum + (stat[statType as keyof PlayerStat] as number || 0), 0);
    return (total / last10.length).toFixed(1);
  };

  const getTrend = (stats: PlayerStat[], statType: string): string => {
    const seasonAvg = parseFloat(calculatePlayerAverage(stats, statType));
    const last10Avg = parseFloat(calculateLast10Average(stats, statType));
    const diff = last10Avg - seasonAvg;
    
    if (diff > seasonAvg * 0.1) return 'up';
    if (diff < -seasonAvg * 0.1) return 'down';
    return 'stable';
  };

  const filteredPlayers = Array.from(playerStats.entries())
    .filter(([playerName]) => 
      playerName.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      const avgA = parseFloat(calculatePlayerAverage(a[1], selectedStat));
      const avgB = parseFloat(calculatePlayerAverage(b[1], selectedStat));
      return avgB - avgA;
    })
    .slice(0, 50);

  const statLabels: Record<string, string> = {
    points: 'Puntos',
    rebounds: 'Rebotes',
    assists: 'Asistencias',
    steals: 'Robos',
    blocks: 'Bloqueos'
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container py-8 space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold">Player Props</h1>
          <p className="text-muted-foreground">
            Analiza el rendimiento individual de los jugadores y sus estadísticas
          </p>
        </div>

        <LeagueSelector selected={league} onSelect={setLeague} />

        <div className="grid md:grid-cols-2 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar jugador..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <Select value={selectedStat} onValueChange={setSelectedStat}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {Object.entries(statLabels).map(([key, label]) => (
                <SelectItem key={key} value={key}>{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
            <p className="mt-4 text-muted-foreground">Cargando estadísticas...</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {filteredPlayers.map(([playerName, stats], index) => {
              const seasonAvg = calculatePlayerAverage(stats, selectedStat);
              const last10Avg = calculateLast10Average(stats, selectedStat);
              const trend = getTrend(stats, selectedStat);
              const teamAbbr = stats[0]?.team_abbreviation;

              return (
                <Card key={playerName}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="flex items-center gap-2">
                          <span className="text-2xl font-bold text-muted-foreground">#{index + 1}</span>
                          {playerName}
                          <Badge variant="outline">{teamAbbr}</Badge>
                        </CardTitle>
                        <CardDescription>
                          {stats.length} partidos analizados
                        </CardDescription>
                      </div>
                      <div className="text-right">
                        {trend === 'up' && <TrendingUp className="h-6 w-6 text-green-500" />}
                        {trend === 'down' && <TrendingDown className="h-6 w-6 text-red-500" />}
                        {trend === 'stable' && <Minus className="h-6 w-6 text-yellow-500" />}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Promedio Temporada</p>
                        <p className="text-3xl font-bold">{seasonAvg}</p>
                        <p className="text-xs text-muted-foreground">{statLabels[selectedStat]} por partido</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Últimos 10 Partidos</p>
                        <p className="text-3xl font-bold">{last10Avg}</p>
                        <p className="text-xs text-muted-foreground">{statLabels[selectedStat]} por partido</p>
                      </div>
                      <div className="space-y-1">
                        <p className="text-sm text-muted-foreground">Tendencia</p>
                        <Badge variant={trend === 'up' ? 'default' : trend === 'down' ? 'destructive' : 'secondary'}>
                          {trend === 'up' && '↑ En alza'}
                          {trend === 'down' && '↓ A la baja'}
                          {trend === 'stable' && '→ Estable'}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            {filteredPlayers.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">
                    {searchTerm ? 'No se encontraron jugadores' : 'No hay estadísticas disponibles'}
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}