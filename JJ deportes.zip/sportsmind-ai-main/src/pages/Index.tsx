import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "@/components/Navbar";
import LeagueSelector, { League } from "@/components/LeagueSelector";
import { TeamPlayersDropdown } from "@/components/TeamPlayersDropdown";
import { RosterNewsAnalyzer } from "@/components/RosterNewsAnalyzer";
import { NextGameSchedule } from "@/components/NextGameSchedule";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, TrendingUp, BarChart } from "lucide-react";

const Index = () => {
  const [selectedLeague, setSelectedLeague] = useState<League>("NBA");
  const navigate = useNavigate();

  const handleExplore = () => {
    navigate(`/standings?league=${selectedLeague}`);
  };

  return (
    <div className="min-h-screen gradient-hero">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          {/* Hero Section */}
          <div className="text-center max-w-4xl mx-auto mb-16 animate-slide-up">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
              <Sparkles className="w-4 h-4 text-primary" />
              <span className="text-sm font-medium text-primary">AI-Powered Sports Intelligence</span>
            </div>
            
            <h1 className="text-6xl md:text-7xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-primary via-secondary to-accent">
              Predict. Analyze. Win.
            </h1>
            
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Advanced multi-sport analytics platform powered by AI. Get intelligent predictions, 
              real-time standings, and deep insights across NBA, NFL, MLB, NHL, and Soccer.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button 
                size="lg" 
                className="text-lg px-8 shadow-glow"
                onClick={handleExplore}
              >
                Start Analyzing
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="text-lg px-8"
                onClick={() => navigate("/predictions")}
              >
                Try Predictions
                <TrendingUp className="ml-2 w-5 h-5" />
              </Button>
            </div>
          </div>

          {/* League Selector */}
          <div className="mb-16">
            <h2 className="text-2xl font-bold text-center mb-6">Select Your Sport</h2>
            <LeagueSelector selected={selectedLeague} onSelect={setSelectedLeague} />
          </div>

          {/* Next Game Schedule Section */}
          <div className="mb-16">
            <div className="text-center mb-8 animate-fade-in">
              <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
                Próximos Partidos
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Ve los próximos partidos programados y el calendario completo
              </p>
            </div>
            <div className="max-w-3xl mx-auto">
              <NextGameSchedule league={selectedLeague} />
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            <div className="glass-card p-6 rounded-xl shadow-card hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
              <div className="w-12 h-12 rounded-lg gradient-primary flex items-center justify-center mb-4">
                <TrendingUp className="w-6 h-6 text-primary-foreground" />
              </div>
              <h3 className="text-xl font-bold mb-2">Smart Predictions</h3>
              <p className="text-muted-foreground">
                AI-powered match outcome predictions with confidence scores and detailed explanations
              </p>
            </div>

            <div className="glass-card p-6 rounded-xl shadow-card hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
              <div className="w-12 h-12 rounded-lg gradient-accent flex items-center justify-center mb-4">
                <BarChart className="w-6 h-6 text-accent-foreground" />
              </div>
              <h3 className="text-xl font-bold mb-2">Live Standings</h3>
              <p className="text-muted-foreground">
                Real-time team rankings, win-loss records, and performance metrics across all leagues
              </p>
            </div>

            <div className="glass-card p-6 rounded-xl shadow-card hover:shadow-glow transition-all duration-300 hover:-translate-y-1">
              <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center mb-4">
                <Sparkles className="w-6 h-6 text-secondary-foreground" />
              </div>
              <h3 className="text-xl font-bold mb-2">Deep Analytics</h3>
              <p className="text-muted-foreground">
                Compare teams, analyze player stats, and track historical matchups with AI insights
              </p>
            </div>
          </div>

          {/* NBA Teams & Players Section */}
          <div className="mt-20">
            <div className="text-center mb-12 animate-fade-in">
              <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
                Equipos y Jugadores NBA
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Explora todos los equipos de la NBA y sus rosters principales
              </p>
            </div>
            <TeamPlayersDropdown />
          </div>

          {/* Roster News Analyzer Section */}
          <div className="mt-20">
            <div className="text-center mb-12 animate-fade-in">
              <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-secondary bg-clip-text text-transparent">
                Actualiza Rosters con IA
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Pega noticias sobre fichajes, traspasos o cambios y la IA los analizará automáticamente
              </p>
            </div>
            <RosterNewsAnalyzer />
          </div>
        </div>
      </main>
    </div>
  );
};

export default Index;
