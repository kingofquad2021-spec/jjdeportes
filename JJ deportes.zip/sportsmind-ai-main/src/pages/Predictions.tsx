import { useState, useEffect } from "react";
import Navbar from "@/components/Navbar";
import LeagueSelector, { League } from "@/components/LeagueSelector";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Sparkles, TrendingUp, AlertCircle, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";

interface PredictionResult {
  winner: string;
  confidence: number;
  explanation: string;
  factors: {
    homeAdvantage: number;
    recentForm: number;
    injuries: number;
    headToHead: number;
  };
}

interface Team {
  team_name: string;
  abbreviation: string;
  conference: string;
}

const Predictions = () => {
  const [selectedLeague, setSelectedLeague] = useState<League>("NBA");
  const [homeTeam, setHomeTeam] = useState("");
  const [awayTeam, setAwayTeam] = useState("");
  const [teams, setTeams] = useState<Team[]>([]);
  const [loadingTeams, setLoadingTeams] = useState(false);
  const [loading, setLoading] = useState(false);
  const [prediction, setPrediction] = useState<PredictionResult | null>(null);

  // Load teams when league changes
  useEffect(() => {
    const loadTeams = async () => {
      setLoadingTeams(true);
      setHomeTeam("");
      setAwayTeam("");
      setPrediction(null);
      
      try {
        const { data, error } = await supabase
          .from("team_standings")
          .select("team_name, abbreviation, conference")
          .eq("league", selectedLeague)
          .order("team_name");

        if (error) throw error;

        // Remove duplicates by abbreviation
        const uniqueTeams = data.reduce((acc: Team[], team) => {
          if (!acc.find((t) => t.abbreviation === team.abbreviation)) {
            acc.push(team);
          }
          return acc;
        }, []);

        setTeams(uniqueTeams);
      } catch (error) {
        console.error("Error loading teams:", error);
        toast.error("Error al cargar equipos");
      } finally {
        setLoadingTeams(false);
      }
    };

    loadTeams();
  }, [selectedLeague]);

  const handlePredict = async () => {
    if (!homeTeam || !awayTeam) {
      toast.error("Please enter both teams");
      return;
    }

    setLoading(true);
    setPrediction(null);

    try {
      const { data, error } = await supabase.functions.invoke("predict-match", {
        body: {
          league: selectedLeague,
          homeTeam,
          awayTeam,
        },
      });

      if (error) throw error;

      setPrediction(data);
      toast.success("Prediction generated!");
    } catch (error) {
      console.error("Prediction error:", error);
      toast.error("Failed to generate prediction. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen gradient-hero">
      <Navbar />
      
      <main className="pt-24 pb-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-8">
              <h1 className="text-4xl md:text-5xl font-bold mb-4">
                AI Match Predictions
              </h1>
              <p className="text-muted-foreground text-lg">
                Get intelligent predictions powered by advanced analytics and AI
              </p>
            </div>

            <div className="mb-8">
              <LeagueSelector selected={selectedLeague} onSelect={setSelectedLeague} />
            </div>

            <Card className="glass-card p-8 shadow-card mb-8">
              {loadingTeams ? (
                <div className="flex items-center justify-center py-8">
                  <Loader2 className="w-8 h-8 animate-spin text-accent" />
                  <span className="ml-2 text-muted-foreground">Cargando equipos...</span>
                </div>
              ) : (
                <>
                  <div className="grid md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <Label htmlFor="homeTeam" className="text-base mb-2 block">
                        Equipo Local
                      </Label>
                      <Select value={homeTeam} onValueChange={setHomeTeam}>
                        <SelectTrigger className="text-lg">
                          <SelectValue placeholder="Selecciona equipo local" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover backdrop-blur-md border-primary/20 z-50">
                          {teams
                            .filter((team) => team.team_name !== awayTeam)
                            .map((team) => (
                              <SelectItem
                                key={team.abbreviation}
                                value={team.team_name}
                                className="cursor-pointer hover:bg-accent/50"
                              >
                                {team.team_name} ({team.abbreviation})
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="awayTeam" className="text-base mb-2 block">
                        Equipo Visitante
                      </Label>
                      <Select value={awayTeam} onValueChange={setAwayTeam}>
                        <SelectTrigger className="text-lg">
                          <SelectValue placeholder="Selecciona equipo visitante" />
                        </SelectTrigger>
                        <SelectContent className="bg-popover backdrop-blur-md border-primary/20 z-50">
                          {teams
                            .filter((team) => team.team_name !== homeTeam)
                            .map((team) => (
                              <SelectItem
                                key={team.abbreviation}
                                value={team.team_name}
                                className="cursor-pointer hover:bg-accent/50"
                              >
                                {team.team_name} ({team.abbreviation})
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </>
              )}

              <Button
                onClick={handlePredict}
                disabled={loading}
                size="lg"
                className="w-full text-lg shadow-glow"
              >
                {loading ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current mr-2" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="mr-2 w-5 h-5" />
                    Generate Prediction
                  </>
                )}
              </Button>
            </Card>

            {prediction && (
              <Card className="glass-card p-8 shadow-card animate-slide-up">
                <div className="text-center mb-6">
                  <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-accent/10 border border-accent/20 mb-4">
                    <TrendingUp className="w-4 h-4 text-accent" />
                    <span className="text-sm font-medium text-accent">Prediction Result</span>
                  </div>
                  
                  <h2 className="text-3xl font-bold mb-2">{prediction.winner}</h2>
                  <div className="text-5xl font-bold text-primary mb-2">
                    {prediction.confidence}%
                  </div>
                  <p className="text-muted-foreground">Confidence</p>
                </div>

                <div className="border-t border-border/50 pt-6 mb-6">
                  <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                    <AlertCircle className="w-5 h-5 text-accent" />
                    AI Analysis
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {prediction.explanation}
                  </p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <div className="text-2xl font-bold text-accent mb-1">
                      +{prediction.factors.homeAdvantage}
                    </div>
                    <div className="text-sm text-muted-foreground">Home Edge</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <div className="text-2xl font-bold text-primary mb-1">
                      +{prediction.factors.recentForm}
                    </div>
                    <div className="text-sm text-muted-foreground">Recent Form</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <div className="text-2xl font-bold text-destructive mb-1">
                      {prediction.factors.injuries}
                    </div>
                    <div className="text-sm text-muted-foreground">Injuries</div>
                  </div>
                  <div className="text-center p-4 rounded-lg bg-muted/50">
                    <div className="text-2xl font-bold text-secondary mb-1">
                      +{prediction.factors.headToHead}
                    </div>
                    <div className="text-sm text-muted-foreground">H2H Record</div>
                  </div>
                </div>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
};

export default Predictions;
