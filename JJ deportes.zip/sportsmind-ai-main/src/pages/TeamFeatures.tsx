import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import LeagueSelector, { type League } from "@/components/LeagueSelector";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Home, Plane, TrendingUp, TrendingDown } from "lucide-react";
import { toast } from "sonner";

interface TeamStat {
  team_name: string;
  team_abbreviation: string;
  games_played: number;
  avg_points: number;
  avg_points_allowed: number;
  offensive_rating: number;
  defensive_rating: number;
  home_wins: number;
  home_losses: number;
  away_wins: number;
  away_losses: number;
  avg_point_differential: number;
  current_streak: string;
  last_10_record: string;
}

export default function TeamFeatures() {
  const [league, setLeague] = useState<League>("NBA");
  const [teamStats, setTeamStats] = useState<TeamStat[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadTeamStats();
  }, [league]);

  const loadTeamStats = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('team_stats')
        .select('*')
        .eq('league', league)
        .order('avg_point_differential', { ascending: false });

      if (error) throw error;
      setTeamStats(data || []);
    } catch (error: any) {
      console.error('Error loading team stats:', error);
      toast.error('Error al cargar estadísticas');
    } finally {
      setLoading(false);
    }
  };

  const getStreakBadge = (streak: string) => {
    if (!streak) return null;
    const isWinning = streak.startsWith('W');
    return (
      <Badge variant={isWinning ? 'default' : 'destructive'}>
        {streak}
      </Badge>
    );
  };

  const calculateWinPercentage = (wins: number, losses: number) => {
    const total = wins + losses;
    return total > 0 ? ((wins / total) * 100).toFixed(1) : '0.0';
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <div className="container py-8 space-y-8">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold">Team Features</h1>
          <p className="text-muted-foreground">
            Análisis detallado del rendimiento de equipos
          </p>
        </div>

        <LeagueSelector selected={league} onSelect={setLeague} />

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-primary border-r-transparent"></div>
            <p className="mt-4 text-muted-foreground">Cargando estadísticas...</p>
          </div>
        ) : (
          <div className="grid gap-4">
            {teamStats.map((team, index) => {
              const homeWinPct = calculateWinPercentage(team.home_wins, team.home_losses);
              const awayWinPct = calculateWinPercentage(team.away_wins, team.away_losses);
              const totalWins = team.home_wins + team.away_wins;
              const totalLosses = team.home_losses + team.away_losses;

              return (
                <Card key={team.team_abbreviation}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-1">
                        <CardTitle className="flex items-center gap-2">
                          <span className="text-2xl font-bold text-muted-foreground">#{index + 1}</span>
                          {team.team_name}
                          <Badge variant="outline">{team.team_abbreviation}</Badge>
                        </CardTitle>
                        <CardDescription>
                          {totalWins}-{totalLosses} ({team.games_played} partidos)
                        </CardDescription>
                      </div>
                      <div className="flex gap-2">
                        {getStreakBadge(team.current_streak)}
                        <Badge variant="secondary">{team.last_10_record}</Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-3">
                        <h4 className="font-semibold flex items-center gap-2">
                          <TrendingUp className="h-4 w-4" />
                          Ofensiva
                        </h4>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Puntos por partido</span>
                            <span className="font-bold">{team.avg_points}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Rating ofensivo</span>
                            <span className="font-bold">{team.offensive_rating}</span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="font-semibold flex items-center gap-2">
                          <TrendingDown className="h-4 w-4" />
                          Defensiva
                        </h4>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Puntos permitidos</span>
                            <span className="font-bold">{team.avg_points_allowed}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Rating defensivo</span>
                            <span className="font-bold">{team.defensive_rating}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-semibold">Diferencial de Puntos</h4>
                      <div className="flex items-center gap-4">
                        <Progress 
                          value={Math.min(Math.max((team.avg_point_differential + 20) * 2.5, 0), 100)} 
                          className="flex-1"
                        />
                        <span className="font-bold min-w-[60px] text-right">
                          {team.avg_point_differential > 0 ? '+' : ''}{team.avg_point_differential}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Home className="h-4 w-4" />
                          <span>Local</span>
                        </div>
                        <div className="space-y-1">
                          <p className="text-2xl font-bold">{team.home_wins}-{team.home_losses}</p>
                          <p className="text-sm text-muted-foreground">{homeWinPct}% victorias</p>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Plane className="h-4 w-4" />
                          <span>Visitante</span>
                        </div>
                        <div className="space-y-1">
                          <p className="text-2xl font-bold">{team.away_wins}-{team.away_losses}</p>
                          <p className="text-sm text-muted-foreground">{awayWinPct}% victorias</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}

            {teamStats.length === 0 && (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground">No hay estadísticas disponibles</p>
                </CardContent>
              </Card>
            )}
          </div>
        )}
      </div>
    </div>
  );
}