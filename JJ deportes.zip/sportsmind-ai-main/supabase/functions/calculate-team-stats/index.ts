import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { league } = await req.json();
    const targetLeague = league || 'NBA';

    console.log(`Calculating team stats for ${targetLeague}...`);

    // Get team standings
    const { data: standings, error: standingsError } = await supabase
      .from('team_standings')
      .select('*')
      .eq('league', targetLeague);

    if (standingsError) throw standingsError;

    // Get recent games
    const { data: games, error: gamesError } = await supabase
      .from('game_schedule')
      .select('*')
      .eq('league', targetLeague)
      .eq('status', 'completed')
      .order('game_date', { ascending: false })
      .limit(500);

    if (gamesError) throw gamesError;

    const teamStatsMap = new Map();

    // Process each team
    for (const team of standings || []) {
      const teamGames = games?.filter(g => 
        g.home_team_abbreviation === team.abbreviation || 
        g.away_team_abbreviation === team.abbreviation
      ) || [];

      if (teamGames.length === 0) continue;

      let totalPoints = 0;
      let totalPointsAllowed = 0;
      let homeWins = 0;
      let homeLosses = 0;
      let awayWins = 0;
      let awayLosses = 0;

      for (const game of teamGames) {
        const isHome = game.home_team_abbreviation === team.abbreviation;
        const teamScore = isHome ? game.home_score : game.away_score;
        const oppScore = isHome ? game.away_score : game.home_score;

        if (teamScore !== null && oppScore !== null) {
          totalPoints += teamScore;
          totalPointsAllowed += oppScore;

          if (teamScore > oppScore) {
            if (isHome) homeWins++;
            else awayWins++;
          } else {
            if (isHome) homeLosses++;
            else awayLosses++;
          }
        }
      }

      const gamesPlayed = teamGames.length;
      const avgPoints = totalPoints / gamesPlayed;
      const avgPointsAllowed = totalPointsAllowed / gamesPlayed;
      const avgPointDifferential = avgPoints - avgPointsAllowed;

      // Calculate offensive and defensive rating (simplified)
      const offensiveRating = (avgPoints / 100) * 100;
      const defensiveRating = (avgPointsAllowed / 100) * 100;

      // Get last 10 games record
      const last10Games = teamGames.slice(0, 10);
      const last10Wins = last10Games.filter(g => {
        const isHome = g.home_team_abbreviation === team.abbreviation;
        const teamScore = isHome ? g.home_score : g.away_score;
        const oppScore = isHome ? g.away_score : g.home_score;
        return teamScore > oppScore;
      }).length;
      const last10Record = `${last10Wins}-${10 - last10Wins}`;

      // Calculate current streak
      let currentStreak = '';
      let streakCount = 0;
      let streakType = '';

      for (const game of teamGames) {
        const isHome = game.home_team_abbreviation === team.abbreviation;
        const teamScore = isHome ? game.home_score : game.away_score;
        const oppScore = isHome ? game.away_score : game.home_score;
        const won = teamScore > oppScore;

        if (streakType === '') {
          streakType = won ? 'W' : 'L';
          streakCount = 1;
        } else if ((streakType === 'W' && won) || (streakType === 'L' && !won)) {
          streakCount++;
        } else {
          break;
        }
      }
      currentStreak = `${streakType}${streakCount}`;

      teamStatsMap.set(team.abbreviation, {
        team_name: team.team_name,
        team_abbreviation: team.abbreviation,
        league: targetLeague,
        season: '2024-25',
        games_played: gamesPlayed,
        avg_points: Math.round(avgPoints * 10) / 10,
        avg_points_allowed: Math.round(avgPointsAllowed * 10) / 10,
        offensive_rating: Math.round(offensiveRating * 10) / 10,
        defensive_rating: Math.round(defensiveRating * 10) / 10,
        home_wins: homeWins,
        home_losses: homeLosses,
        away_wins: awayWins,
        away_losses: awayLosses,
        avg_point_differential: Math.round(avgPointDifferential * 10) / 10,
        current_streak: currentStreak,
        last_10_record: last10Record,
      });
    }

    // Upsert team stats
    const teamStatsArray = Array.from(teamStatsMap.values());
    
    if (teamStatsArray.length > 0) {
      const { error: upsertError } = await supabase
        .from('team_stats')
        .upsert(teamStatsArray, { 
          onConflict: 'team_abbreviation,league,season' 
        });

      if (upsertError) throw upsertError;
    }

    return new Response(
      JSON.stringify({ 
        message: `Team stats calculated successfully for ${targetLeague}`,
        count: teamStatsArray.length 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in calculate-team-stats:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});