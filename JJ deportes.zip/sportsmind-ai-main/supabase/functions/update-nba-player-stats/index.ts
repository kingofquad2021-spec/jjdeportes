import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface PlayerStat {
  player_name: string;
  team_name: string;
  team_abbreviation: string;
  league: string;
  game_date: string;
  opponent: string;
  points: number;
  rebounds: number;
  assists: number;
  steals: number;
  blocks: number;
  minutes_played: number;
  fg_percentage: number | null;
  three_point_percentage: number | null;
  turnovers: number;
}

const NBA_TEAMS = [
  { id: 1, name: 'Atlanta Hawks', abbreviation: 'ATL' },
  { id: 2, name: 'Boston Celtics', abbreviation: 'BOS' },
  { id: 3, name: 'Brooklyn Nets', abbreviation: 'BKN' },
  { id: 4, name: 'Charlotte Hornets', abbreviation: 'CHA' },
  { id: 5, name: 'Chicago Bulls', abbreviation: 'CHI' },
  { id: 6, name: 'Cleveland Cavaliers', abbreviation: 'CLE' },
  { id: 7, name: 'Dallas Mavericks', abbreviation: 'DAL' },
  { id: 8, name: 'Denver Nuggets', abbreviation: 'DEN' },
  { id: 9, name: 'Detroit Pistons', abbreviation: 'DET' },
  { id: 10, name: 'Golden State Warriors', abbreviation: 'GSW' },
  { id: 11, name: 'Houston Rockets', abbreviation: 'HOU' },
  { id: 12, name: 'Indiana Pacers', abbreviation: 'IND' },
  { id: 13, name: 'LA Clippers', abbreviation: 'LAC' },
  { id: 14, name: 'Los Angeles Lakers', abbreviation: 'LAL' },
  { id: 15, name: 'Memphis Grizzlies', abbreviation: 'MEM' },
  { id: 16, name: 'Miami Heat', abbreviation: 'MIA' },
  { id: 17, name: 'Milwaukee Bucks', abbreviation: 'MIL' },
  { id: 18, name: 'Minnesota Timberwolves', abbreviation: 'MIN' },
  { id: 19, name: 'New Orleans Pelicans', abbreviation: 'NOP' },
  { id: 20, name: 'New York Knicks', abbreviation: 'NYK' },
  { id: 21, name: 'Oklahoma City Thunder', abbreviation: 'OKC' },
  { id: 22, name: 'Orlando Magic', abbreviation: 'ORL' },
  { id: 23, name: 'Philadelphia 76ers', abbreviation: 'PHI' },
  { id: 24, name: 'Phoenix Suns', abbreviation: 'PHX' },
  { id: 25, name: 'Portland Trail Blazers', abbreviation: 'POR' },
  { id: 26, name: 'Sacramento Kings', abbreviation: 'SAC' },
  { id: 27, name: 'San Antonio Spurs', abbreviation: 'SAS' },
  { id: 28, name: 'Toronto Raptors', abbreviation: 'TOR' },
  { id: 29, name: 'Utah Jazz', abbreviation: 'UTA' },
  { id: 30, name: 'Washington Wizards', abbreviation: 'WAS' },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const allPlayerStats: PlayerStat[] = [];

    // Fetch recent games for each team
    for (const team of NBA_TEAMS) {
      try {
        console.log(`Fetching player stats for ${team.name}...`);
        
        // Get team schedule to find recent completed games
        const scheduleResponse = await fetch(
          `https://site.api.espn.com/apis/site/v2/sports/basketball/nba/teams/${team.id}/schedule`
        );
        
        if (!scheduleResponse.ok) continue;
        
        const scheduleData = await scheduleResponse.json();
        const recentGames = scheduleData.events
          ?.filter((event: any) => event.competitions?.[0]?.status?.type?.completed)
          ?.slice(0, 5) || []; // Last 5 completed games

        for (const game of recentGames) {
          try {
            const gameId = game.id;
            const gameDate = game.date;
            const competition = game.competitions?.[0];
            
            // Determine opponent
            const homeTeam = competition.competitors.find((c: any) => c.homeAway === 'home');
            const awayTeam = competition.competitors.find((c: any) => c.homeAway === 'away');
            const isHome = homeTeam?.id === team.id.toString();
            const opponent = isHome ? awayTeam?.team?.abbreviation : homeTeam?.team?.abbreviation;

            // Fetch box score for this game
            const boxScoreResponse = await fetch(
              `https://site.api.espn.com/apis/site/v2/sports/basketball/nba/summary?event=${gameId}`
            );

            if (!boxScoreResponse.ok) continue;

            const boxScoreData = await boxScoreResponse.json();
            const teamStats = boxScoreData.boxscore?.players?.find((p: any) => 
              p.team.id === team.id.toString()
            );

            if (!teamStats?.statistics?.[0]?.athletes) continue;

            // Process each player's stats
            for (const athlete of teamStats.statistics[0].athletes) {
              const stats = athlete.stats;
              
              const playerStat: PlayerStat = {
                player_name: athlete.athlete.displayName,
                team_name: team.name,
                team_abbreviation: team.abbreviation,
                league: 'NBA',
                game_date: gameDate,
                opponent: opponent || 'Unknown',
                points: parseInt(stats[12] || '0'),
                rebounds: parseInt(stats[10] || '0'),
                assists: parseInt(stats[11] || '0'),
                steals: parseInt(stats[14] || '0'),
                blocks: parseInt(stats[13] || '0'),
                minutes_played: parseInt(stats[0]?.split(':')[0] || '0'),
                fg_percentage: parseFloat(stats[2]) || null,
                three_point_percentage: parseFloat(stats[5]) || null,
                turnovers: parseInt(stats[15] || '0'),
              };

              allPlayerStats.push(playerStat);
            }
          } catch (gameError) {
            console.error(`Error processing game ${game.id}:`, gameError);
          }
        }
      } catch (teamError) {
        console.error(`Error processing team ${team.name}:`, teamError);
      }
    }

    console.log(`Collected ${allPlayerStats.length} player stat records`);

    if (allPlayerStats.length > 0) {
      console.log(`Processing ${allPlayerStats.length} player stats...`);
      
      // Delete old NBA player stats (keep last 30 days)
      const thirtyDaysAgo = new Date();
      thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
      
      const { error: deleteError } = await supabase
        .from('player_stats')
        .delete()
        .eq('league', 'NBA')
        .lt('game_date', thirtyDaysAgo.toISOString());

      if (deleteError) {
        console.error('Error deleting old player stats:', deleteError);
      }

      // Insert new player stats in batches to avoid timeout
      const BATCH_SIZE = 100;
      let insertedCount = 0;
      
      for (let i = 0; i < allPlayerStats.length; i += BATCH_SIZE) {
        const batch = allPlayerStats.slice(i, i + BATCH_SIZE);
        console.log(`Inserting batch ${Math.floor(i / BATCH_SIZE) + 1}/${Math.ceil(allPlayerStats.length / BATCH_SIZE)}...`);
        
        const { error: insertError } = await supabase
          .from('player_stats')
          .insert(batch);

        if (insertError) {
          console.error(`Error inserting batch at index ${i}:`, insertError);
          // Continue with next batch instead of failing completely
        } else {
          insertedCount += batch.length;
        }
      }
      
      console.log(`Successfully inserted ${insertedCount} player stats`);
    }

    return new Response(
      JSON.stringify({ 
        success: true,
        message: 'NBA player stats updated successfully',
        count: allPlayerStats.length 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in update-nba-player-stats:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
