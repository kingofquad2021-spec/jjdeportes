import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface NewsArticle {
  headline: string;
  description?: string;
  published: string;
  type?: string;
  link?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting NBA news update...');

    const NBA_TEAMS = [
      { id: 1, name: 'Atlanta Hawks', abbreviation: 'ATL' },
      { id: 2, name: 'Boston Celtics', abbreviation: 'BOS' },
      { id: 17, name: 'Brooklyn Nets', abbreviation: 'BKN' },
      { id: 30, name: 'Charlotte Hornets', abbreviation: 'CHA' },
      { id: 4, name: 'Chicago Bulls', abbreviation: 'CHI' },
      { id: 5, name: 'Cleveland Cavaliers', abbreviation: 'CLE' },
      { id: 6, name: 'Dallas Mavericks', abbreviation: 'DAL' },
      { id: 7, name: 'Denver Nuggets', abbreviation: 'DEN' },
      { id: 8, name: 'Detroit Pistons', abbreviation: 'DET' },
      { id: 9, name: 'Golden State Warriors', abbreviation: 'GS' },
      { id: 10, name: 'Houston Rockets', abbreviation: 'HOU' },
      { id: 11, name: 'Indiana Pacers', abbreviation: 'IND' },
      { id: 12, name: 'LA Clippers', abbreviation: 'LAC' },
      { id: 13, name: 'Los Angeles Lakers', abbreviation: 'LAL' },
      { id: 29, name: 'Memphis Grizzlies', abbreviation: 'MEM' },
      { id: 14, name: 'Miami Heat', abbreviation: 'MIA' },
      { id: 15, name: 'Milwaukee Bucks', abbreviation: 'MIL' },
      { id: 16, name: 'Minnesota Timberwolves', abbreviation: 'MIN' },
      { id: 3, name: 'New Orleans Pelicans', abbreviation: 'NO' },
      { id: 18, name: 'New York Knicks', abbreviation: 'NY' },
      { id: 25, name: 'Oklahoma City Thunder', abbreviation: 'OKC' },
      { id: 19, name: 'Orlando Magic', abbreviation: 'ORL' },
      { id: 20, name: 'Philadelphia 76ers', abbreviation: 'PHI' },
      { id: 21, name: 'Phoenix Suns', abbreviation: 'PHX' },
      { id: 22, name: 'Portland Trail Blazers', abbreviation: 'POR' },
      { id: 23, name: 'Sacramento Kings', abbreviation: 'SAC' },
      { id: 24, name: 'San Antonio Spurs', abbreviation: 'SA' },
      { id: 28, name: 'Toronto Raptors', abbreviation: 'TOR' },
      { id: 26, name: 'Utah Jazz', abbreviation: 'UTAH' },
      { id: 27, name: 'Washington Wizards', abbreviation: 'WSH' }
    ];

    const allNews: any[] = [];

    for (const team of NBA_TEAMS) {
      console.log(`Fetching news for ${team.name}...`);
      
      try {
        const response = await fetch(`https://site.api.espn.com/apis/site/v2/sports/basketball/nba/teams/${team.id}/news`);
        
        if (!response.ok) {
          console.error(`Failed to fetch news for ${team.name}: ${response.status}`);
          continue;
        }

        const data = await response.json();
        
        console.log(`ESPN API response for ${team.name}:`, JSON.stringify(data).substring(0, 500));
        
        if (data.articles && Array.isArray(data.articles)) {
          console.log(`Found ${data.articles.length} articles for ${team.name}`);
          for (const article of data.articles.slice(0, 10)) { // Limitar a 10 noticias por equipo
            const newsType = article.headline?.toLowerCase().includes('injury') || article.description?.toLowerCase().includes('injury') || article.description?.toLowerCase().includes('hurt')
              ? 'injury'
              : article.headline?.toLowerCase().includes('return') || article.description?.toLowerCase().includes('return') || article.description?.toLowerCase().includes('back')
              ? 'return'
              : 'general';

            allNews.push({
              league: 'NBA',
              team_name: team.name,
              team_abbreviation: team.abbreviation,
              headline: article.headline || '',
              description: article.description || null,
              news_type: newsType,
              published_date: article.published ? new Date(article.published).toISOString() : new Date().toISOString(),
              source_url: article.links?.web?.href || null
            });
          }
        } else {
          console.log(`No articles found for ${team.name}. Data structure:`, Object.keys(data));
        }
      } catch (error) {
        console.error(`Error fetching news for ${team.name}:`, error);
      }
    }

    // Borrar noticias viejas de NBA (más de 7 días)
    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const { error: deleteError } = await supabase
      .from('team_news')
      .delete()
      .eq('league', 'NBA')
      .lt('published_date', sevenDaysAgo.toISOString());

    if (deleteError) {
      console.error('Error deleting old news:', deleteError);
    }

    // Insertar nuevas noticias
    if (allNews.length > 0) {
      const { error: insertError } = await supabase
        .from('team_news')
        .upsert(allNews, { onConflict: 'headline,team_name' });

      if (insertError) {
        console.error('Error inserting news:', insertError);
        throw insertError;
      }

      console.log(`Successfully inserted ${allNews.length} news articles`);

      // Analizar y actualizar roster automáticamente para noticias de lesiones/regresos
      const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
      if (LOVABLE_API_KEY) {
        const injuryOrReturnNews = allNews.filter(n => n.news_type === 'injury' || n.news_type === 'return');
        console.log(`Analyzing ${injuryOrReturnNews.length} injury/return news articles...`);

        for (const news of injuryOrReturnNews) {
          try {
            const newsText = `${news.headline}. ${news.description || ''}`;
            const systemPrompt = `Eres un experto analizador de noticias deportivas. Extrae información estructurada sobre actualizaciones de roster de jugadores.`;
            const prompt = `Analiza esta noticia del equipo ${news.team_name} en la liga NBA:\n\n${newsText}\n\nExtrae todos los jugadores mencionados con su estado actual, descripción de lesión si aplica, y semanas estimadas fuera.`;

            const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${LOVABLE_API_KEY}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                model: 'google/gemini-2.5-flash',
                messages: [
                  { role: 'system', content: systemPrompt },
                  { role: 'user', content: prompt }
                ],
                tools: [{
                  type: 'function',
                  function: {
                    name: 'extract_roster_updates',
                    description: 'Extrae información estructurada sobre actualizaciones de jugadores',
                    parameters: {
                      type: 'object',
                      properties: {
                        summary: { type: 'string', description: 'Resumen breve de las actualizaciones' },
                        players: {
                          type: 'array',
                          items: {
                            type: 'object',
                            properties: {
                              player_name: { type: 'string' },
                              status: { type: 'string', enum: ['active', 'injured', 'out', 'questionable', 'doubtful'] },
                              injury_description: { type: 'string' },
                              weeks_out: { type: 'number' }
                            },
                            required: ['player_name', 'status']
                          }
                        }
                      },
                      required: ['summary', 'players']
                    }
                  }
                }],
                tool_choice: { type: 'function', function: { name: 'extract_roster_updates' } }
              })
            });

            if (aiResponse.ok) {
              const aiData = await aiResponse.json();
              const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
              if (toolCall) {
                const rosterUpdates = JSON.parse(toolCall.function.arguments);
                for (const playerUpdate of rosterUpdates.players) {
                  const expectedReturnDate = playerUpdate.weeks_out > 0 
                    ? new Date(Date.now() + playerUpdate.weeks_out * 7 * 24 * 60 * 60 * 1000).toISOString()
                    : null;

                  const { error: updateError } = await supabase
                    .from('rosters')
                    .update({
                      injury_status: playerUpdate.status,
                      injury_description: playerUpdate.injury_description || null,
                      expected_return_date: expectedReturnDate,
                      last_news_update: new Date().toISOString()
                    })
                    .eq('league', 'NBA')
                    .eq('team_name', news.team_name)
                    .ilike('player_name', `%${playerUpdate.player_name}%`);

                  if (!updateError) {
                    console.log(`Updated roster for ${playerUpdate.player_name}`);
                  }
                }
              }
            }
          } catch (error) {
            console.error(`Error analyzing news for ${news.team_name}:`, error);
          }
        }
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Updated ${allNews.length} NBA news articles`,
        newsCount: allNews.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in update-nba-news:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
