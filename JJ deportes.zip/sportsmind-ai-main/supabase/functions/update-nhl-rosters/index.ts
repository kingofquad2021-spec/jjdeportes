import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.76.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Player {
  league: string;
  team_abbreviation: string;
  team_name: string;
  player_name: string;
  position: string | null;
  jersey_number: string | null;
  height: string | null;
  weight: string | null;
  age: number | null;
  player_image: string | null;
}

const NHL_TEAMS = [
  { id: '24', name: 'Anaheim Ducks', abbreviation: 'ANA' },
  { id: '1', name: 'Boston Bruins', abbreviation: 'BOS' },
  { id: '2', name: 'Buffalo Sabres', abbreviation: 'BUF' },
  { id: '20', name: 'Calgary Flames', abbreviation: 'CGY' },
  { id: '12', name: 'Carolina Hurricanes', abbreviation: 'CAR' },
  { id: '16', name: 'Chicago Blackhawks', abbreviation: 'CHI' },
  { id: '21', name: 'Colorado Avalanche', abbreviation: 'COL' },
  { id: '29', name: 'Columbus Blue Jackets', abbreviation: 'CBJ' },
  { id: '25', name: 'Dallas Stars', abbreviation: 'DAL' },
  { id: '17', name: 'Detroit Red Wings', abbreviation: 'DET' },
  { id: '22', name: 'Edmonton Oilers', abbreviation: 'EDM' },
  { id: '13', name: 'Florida Panthers', abbreviation: 'FLA' },
  { id: '26', name: 'Los Angeles Kings', abbreviation: 'LA' },
  { id: '30', name: 'Minnesota Wild', abbreviation: 'MIN' },
  { id: '8', name: 'Montreal Canadiens', abbreviation: 'MTL' },
  { id: '18', name: 'Nashville Predators', abbreviation: 'NSH' },
  { id: '31', name: 'New Jersey Devils', abbreviation: 'NJ' },
  { id: '32', name: 'New York Islanders', abbreviation: 'NYI' },
  { id: '3', name: 'New York Rangers', abbreviation: 'NYR' },
  { id: '9', name: 'Ottawa Senators', abbreviation: 'OTT' },
  { id: '4', name: 'Philadelphia Flyers', abbreviation: 'PHI' },
  { id: '5', name: 'Pittsburgh Penguins', abbreviation: 'PIT' },
  { id: '28', name: 'San Jose Sharks', abbreviation: 'SJ' },
  { id: '27', name: 'Seattle Kraken', abbreviation: 'SEA' },
  { id: '19', name: 'St. Louis Blues', abbreviation: 'STL' },
  { id: '14', name: 'Tampa Bay Lightning', abbreviation: 'TB' },
  { id: '10', name: 'Toronto Maple Leafs', abbreviation: 'TOR' },
  { id: '23', name: 'Vancouver Canucks', abbreviation: 'VAN' },
  { id: '15', name: 'Vegas Golden Knights', abbreviation: 'VGK' },
  { id: '6', name: 'Washington Capitals', abbreviation: 'WSH' },
  { id: '7', name: 'Winnipeg Jets', abbreviation: 'WPG' },
  { id: '33', name: 'Utah Hockey Club', abbreviation: 'UTA' },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting NHL rosters update...');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const allPlayers: Player[] = [];

    for (const team of NHL_TEAMS) {
      try {
        const rosterUrl = `https://site.api.espn.com/apis/site/v2/sports/hockey/nhl/teams/${team.id}/roster?season=2026`;
        console.log(`Fetching roster for ${team.name} (2025-2026 season)...`);
        
        const response = await fetch(rosterUrl);
        if (!response.ok) {
          console.error(`Failed to fetch roster for ${team.name}`);
          continue;
        }

        const data = await response.json();
        
        if (data.athletes) {
          // Athletes are grouped by position
          for (const positionGroup of data.athletes) {
            if (positionGroup.items) {
              for (const athlete of positionGroup.items) {
                allPlayers.push({
                  league: 'NHL',
                  team_abbreviation: team.abbreviation,
                  team_name: team.name,
                  player_name: athlete.fullName || athlete.displayName || 'Unknown',
                  position: positionGroup.position || null,
                  jersey_number: athlete.jersey || null,
                  height: athlete.displayHeight || null,
                  weight: athlete.displayWeight || null,
                  age: athlete.age || null,
                  player_image: athlete.headshot?.href || null,
                });
              }
            }
          }
        }
      } catch (error) {
        console.error(`Error fetching roster for ${team.name}:`, error);
      }
    }

    console.log(`Parsed ${allPlayers.length} players from NHL rosters`);

    // Delete existing NHL rosters
    const { error: deleteError } = await supabase
      .from('rosters')
      .delete()
      .eq('league', 'NHL');

    if (deleteError) {
      throw deleteError;
    }

    // Insert new rosters
    const { error: insertError } = await supabase
      .from('rosters')
      .insert(allPlayers);

    if (insertError) {
      throw insertError;
    }

    console.log(`Successfully updated ${allPlayers.length} NHL players`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Successfully updated ${allPlayers.length} NHL players` 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error updating NHL rosters:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
