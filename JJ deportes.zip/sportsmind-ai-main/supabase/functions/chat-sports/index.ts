import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { question, league } = await req.json();

    if (!question) {
      throw new Error('Question is required');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY not configured');
    }

    // Get relevant data from database
    const [standingsData, newsData, scheduleData] = await Promise.all([
      supabase
        .from('team_standings')
        .select('*')
        .eq('league', league || 'NBA')
        .order('rank', { ascending: true })
        .limit(20),
      supabase
        .from('team_news')
        .select('*')
        .eq('league', league || 'NBA')
        .order('published_date', { ascending: false })
        .limit(20),
      supabase
        .from('game_schedule')
        .select('*')
        .eq('league', league || 'NBA')
        .order('game_date', { ascending: false })
        .limit(20)
    ]);

    const systemPrompt = `Eres un asistente experto en deportes que tiene acceso a datos en tiempo real sobre ${league || 'NBA'}.

Datos disponibles:
- Standings (Posiciones): ${JSON.stringify(standingsData.data)}
- Noticias: ${JSON.stringify(newsData.data)}
- Calendario de juegos: ${JSON.stringify(scheduleData.data)}

Instrucciones:
1. Responde SOLO basándote en los datos proporcionados arriba
2. Si no tienes información suficiente, dilo claramente
3. Sé conciso pero informativo
4. Responde en español
5. Para matchups, analiza las estadísticas de ambos equipos (wins, losses, pct, ppg, opp_ppg, streak, last_10)
6. Para noticias de lesiones, menciona quién está lesionado y por qué según los datos de noticias
7. Si preguntan sobre un equipo específico, enfócate en ese equipo`;

    const userPrompt = `Pregunta del usuario: ${question}`;

    const response = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        temperature: 0.7,
        max_tokens: 1000,
      }),
    });

    if (response.status === 429) {
      return new Response(
        JSON.stringify({ 
          error: 'Rate limit exceeded. Please try again in a moment.' 
        }),
        { 
          status: 429, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    if (response.status === 402) {
      return new Response(
        JSON.stringify({ 
          error: 'Payment required. Please add credits to continue using AI features.' 
        }),
        { 
          status: 402, 
          headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
        }
      );
    }

    if (!response.ok) {
      const errorText = await response.text();
      console.error('AI API error:', response.status, errorText);
      throw new Error('Failed to get AI response');
    }

    const data = await response.json();
    const answer = data.choices[0].message.content;

    return new Response(
      JSON.stringify({ answer }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );

  } catch (error) {
    console.error('Error in chat-sports function:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});