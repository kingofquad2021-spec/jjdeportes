import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.76.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Player {
  league: string;
  team_abbreviation: string;
  team_name: string;
  player_name: string;
  position: string | null;
  jersey_number: string | null;
  height: string | null;
  weight: string | null;
  age: number | null;
  player_image: string | null;
}

const NBA_TEAMS = [
  { id: '1', name: 'Atlanta Hawks', abbreviation: 'ATL' },
  { id: '2', name: 'Boston Celtics', abbreviation: 'BOS' },
  { id: '3', name: 'New Orleans Pelicans', abbreviation: 'NO' },
  { id: '4', name: 'Chicago Bulls', abbreviation: 'CHI' },
  { id: '5', name: 'Cleveland Cavaliers', abbreviation: 'CLE' },
  { id: '6', name: 'Dallas Mavericks', abbreviation: 'DAL' },
  { id: '7', name: 'Denver Nuggets', abbreviation: 'DEN' },
  { id: '8', name: 'Detroit Pistons', abbreviation: 'DET' },
  { id: '9', name: 'Golden State Warriors', abbreviation: 'GS' },
  { id: '10', name: 'Houston Rockets', abbreviation: 'HOU' },
  { id: '11', name: 'Indiana Pacers', abbreviation: 'IND' },
  { id: '12', name: 'Los Angeles Clippers', abbreviation: 'LAC' },
  { id: '13', name: 'Los Angeles Lakers', abbreviation: 'LAL' },
  { id: '14', name: 'Miami Heat', abbreviation: 'MIA' },
  { id: '15', name: 'Milwaukee Bucks', abbreviation: 'MIL' },
  { id: '16', name: 'Minnesota Timberwolves', abbreviation: 'MIN' },
  { id: '17', name: 'Brooklyn Nets', abbreviation: 'BKN' },
  { id: '18', name: 'New York Knicks', abbreviation: 'NY' },
  { id: '19', name: 'Orlando Magic', abbreviation: 'ORL' },
  { id: '20', name: 'Philadelphia 76ers', abbreviation: 'PHI' },
  { id: '21', name: 'Phoenix Suns', abbreviation: 'PHX' },
  { id: '22', name: 'Portland Trail Blazers', abbreviation: 'POR' },
  { id: '23', name: 'Sacramento Kings', abbreviation: 'SAC' },
  { id: '24', name: 'San Antonio Spurs', abbreviation: 'SA' },
  { id: '25', name: 'Oklahoma City Thunder', abbreviation: 'OKC' },
  { id: '26', name: 'Utah Jazz', abbreviation: 'UTAH' },
  { id: '27', name: 'Washington Wizards', abbreviation: 'WSH' },
  { id: '28', name: 'Toronto Raptors', abbreviation: 'TOR' },
  { id: '29', name: 'Memphis Grizzlies', abbreviation: 'MEM' },
  { id: '30', name: 'Charlotte Hornets', abbreviation: 'CHA' },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting NBA rosters update...');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const allPlayers: Player[] = [];

    for (const team of NBA_TEAMS) {
      try {
        const rosterUrl = `https://site.api.espn.com/apis/site/v2/sports/basketball/nba/teams/${team.id}/roster?season=2026`;
        console.log(`Fetching roster for ${team.name} (2025-2026 season)...`);
        
        const response = await fetch(rosterUrl);
        if (!response.ok) {
          console.error(`Failed to fetch roster for ${team.name}`);
          continue;
        }

        const data = await response.json();
        
        if (data.athletes) {
          for (const athlete of data.athletes) {
            allPlayers.push({
              league: 'NBA',
              team_abbreviation: team.abbreviation,
              team_name: team.name,
              player_name: athlete.fullName || athlete.displayName || 'Unknown',
              position: athlete.position?.abbreviation || null,
              jersey_number: athlete.jersey || null,
              height: athlete.height || null,
              weight: athlete.weight || null,
              age: athlete.age || null,
              player_image: athlete.headshot?.href || null,
            });
          }
        }
      } catch (error) {
        console.error(`Error fetching roster for ${team.name}:`, error);
      }
    }

    console.log(`Parsed ${allPlayers.length} players from NBA rosters`);

    // Delete existing NBA rosters
    const { error: deleteError } = await supabase
      .from('rosters')
      .delete()
      .eq('league', 'NBA');

    if (deleteError) {
      throw deleteError;
    }

    // Insert new rosters
    const { error: insertError } = await supabase
      .from('rosters')
      .insert(allPlayers);

    if (insertError) {
      throw insertError;
    }

    console.log(`Successfully updated ${allPlayers.length} NBA players`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Successfully updated ${allPlayers.length} NBA players` 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error updating NBA rosters:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
