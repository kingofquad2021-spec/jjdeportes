import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { newsText, team, league } = await req.json();

    if (!newsText || !team || !league) {
      return new Response(
        JSON.stringify({ error: 'Se requiere newsText, team y league' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
    const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
    const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
    
    if (!LOVABLE_API_KEY) {
      throw new Error('LOVABLE_API_KEY no está configurada');
    }

    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

    // First, extract structured information using tool calling
    const systemPrompt = `Eres un analista deportivo experto. Analiza noticias sobre cambios en rosters de equipos deportivos y extrae información estructurada.`;

    const userPrompt = `Analiza esta noticia del equipo ${team} de ${league}:\n\n${newsText}\n\nExtrae toda la información relevante sobre jugadores afectados.`;

    const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${LOVABLE_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userPrompt }
        ],
        tools: [{
          type: "function",
          function: {
            name: "update_roster_status",
            description: "Actualiza el estado de uno o más jugadores en el roster",
            parameters: {
              type: "object",
              properties: {
                players: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      player_name: { type: "string", description: "Nombre completo del jugador" },
                      status: { 
                        type: "string", 
                        enum: ["active", "injured", "out", "questionable", "doubtful", "day-to-day"],
                        description: "Estado actual del jugador"
                      },
                      injury_description: { type: "string", description: "Descripción de la lesión o situación" },
                      weeks_out: { type: "number", description: "Número de semanas estimadas de baja (0 si no aplica)" }
                    },
                    required: ["player_name", "status"]
                  }
                },
                summary: { type: "string", description: "Resumen del impacto en el equipo en español" }
              },
              required: ["players", "summary"]
            }
          }
        }],
        tool_choice: { type: "function", function: { name: "update_roster_status" } }
      }),
    });

    if (!aiResponse.ok) {
      if (aiResponse.status === 429) {
        return new Response(
          JSON.stringify({ error: 'Límite de solicitudes excedido. Por favor, intenta más tarde.' }),
          { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      if (aiResponse.status === 402) {
        return new Response(
          JSON.stringify({ error: 'Fondos insuficientes. Por favor, recarga tu cuenta de Lovable AI.' }),
          { status: 402, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }
      const errorText = await aiResponse.text();
      console.error('Error de AI gateway:', aiResponse.status, errorText);
      throw new Error('Error al comunicarse con el servicio de IA');
    }

    const aiData = await aiResponse.json();
    const toolCall = aiData.choices[0].message.tool_calls?.[0];
    
    if (!toolCall) {
      return new Response(
        JSON.stringify({ error: 'No se pudo extraer información estructurada de la noticia' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const rosterUpdates = JSON.parse(toolCall.function.arguments);
    const updatedPlayers = [];

    // Save the news to team_news table
    const newsType = rosterUpdates.players.some((p: any) => 
      ['injured', 'out'].includes(p.status)
    ) ? 'injury' : rosterUpdates.players.some((p: any) => 
      p.status === 'active' && p.injury_description?.toLowerCase().includes('return')
    ) ? 'return' : 'general';

    const headline = `Actualización de Roster: ${rosterUpdates.players.map((p: any) => p.player_name).join(', ')}`;
    
    await supabase
      .from('team_news')
      .insert({
        league: league,
        team_name: team,
        headline: headline,
        description: rosterUpdates.summary,
        news_type: newsType,
        published_date: new Date().toISOString(),
        source_url: null
      });

    // Update each player in the roster
    for (const playerUpdate of rosterUpdates.players) {
      const expectedReturnDate = playerUpdate.weeks_out > 0 
        ? new Date(Date.now() + playerUpdate.weeks_out * 7 * 24 * 60 * 60 * 1000).toISOString()
        : null;

      const { data, error } = await supabase
        .from('rosters')
        .update({
          injury_status: playerUpdate.status,
          injury_description: playerUpdate.injury_description || null,
          expected_return_date: expectedReturnDate,
          last_news_update: new Date().toISOString()
        })
        .eq('league', league)
        .eq('team_name', team)
        .ilike('player_name', `%${playerUpdate.player_name}%`)
        .select();

      if (error) {
        console.error('Error updating roster:', error);
      } else if (data && data.length > 0) {
        updatedPlayers.push({
          player: playerUpdate.player_name,
          status: playerUpdate.status,
          updated: true
        });
      } else {
        updatedPlayers.push({
          player: playerUpdate.player_name,
          status: playerUpdate.status,
          updated: false,
          reason: 'Jugador no encontrado en el roster'
        });
      }
    }

    return new Response(
      JSON.stringify({ 
        summary: rosterUpdates.summary,
        players: updatedPlayers,
        team,
        league
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error en analyze-roster-news:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Error desconocido' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
