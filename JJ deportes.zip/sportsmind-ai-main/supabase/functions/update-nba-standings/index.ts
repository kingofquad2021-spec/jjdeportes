import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting NBA standings update...');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch NBA standings from ESPN API (free, no key required)
    const response = await fetch('https://site.api.espn.com/apis/v2/sports/basketball/nba/standings');
    
    if (!response.ok) {
      throw new Error(`ESPN API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('Fetched standings data from ESPN');

    // Define standing type
    interface Standing {
      league: string;
      conference: string;
      team_name: string;
      abbreviation: string;
      rank: number;
      wins: number;
      losses: number;
      pct: number;
      gb: string | null;
      home_record: string;
      away_record: string;
      division_record: string;
      conference_record: string;
      ppg: number;
      opp_ppg: number;
      diff: number;
      streak: string;
      last_10: string;
    }

    // Parse standings data
    const standings: Standing[] = [];
    
    if (data.children) {
      for (const conference of data.children) {
        const conferenceName = conference.name.includes('Eastern') ? 'Eastern' : 'Western';
        
        if (conference.standings?.entries) {
          for (const entry of conference.standings.entries) {
            const team = entry.team;
            const stats = entry.stats;
            
            // Helpers to read ESPN stats
            const getStatValue = (name: string) => {
              const stat = stats.find((s: any) => s.name === name);
              return stat ? parseFloat(stat.value) : 0;
            };

            const getStatDisplay = (name: string, defaultValue = '') => {
              const stat = stats.find((s: any) => s.name === name);
              return (stat?.displayValue ?? stat?.value ?? defaultValue) as string;
            };

            const getPairRecord = (winsName: string, lossesName: string): string | null => {
              const w = getStatValue(winsName);
              const l = getStatValue(lossesName);
              if (w + l > 0) return `${Math.round(w)}-${Math.round(l)}`;
              return null;
            };

            const resolveRecord = (prefNames: string[], pairs: Array<[string, string]>) => {
              // 1) Prefer known display fields
              for (const n of prefNames) {
                const dv = getStatDisplay(n, '');
                if (typeof dv === 'string' && dv.includes('-')) return dv;
              }
              // 2) Use explicit win/loss names
              for (const [w, l] of pairs) {
                const rec = getPairRecord(w, l);
                if (rec && rec !== '0-0') return rec;
              }
              // 3) Try any stat that matches the keyword and looks like a record
              const any = stats.find((s: any) => prefNames.some(n => s.name?.toLowerCase().includes(n.toLowerCase())) && typeof s.displayValue === 'string' && s.displayValue.includes('-'));
              if (any) return any.displayValue;
              return '0-0';
            };

            const wins = getStatValue('wins');
            const losses = getStatValue('losses');
            const winPercent = getStatValue('winPercent');
            const gamesBehind = getStatValue('gamesBehind');
            const pointsFor = getStatValue('pointsFor');
            const pointsAgainst = getStatValue('pointsAgainst');

            // HOME and AWAY (ROAD) records with robust fallbacks
            const homeRecord = resolveRecord(['home', 'homeRecord'], [['homeWins', 'homeLosses']]);
            const awayRecord = resolveRecord(['road', 'roadRecord', 'away', 'awayRecord'], [
              ['roadWins', 'roadLosses'],
              ['awayWins', 'awayLosses'],
            ]);

            const gamesPlayed = wins + losses;

            // Calculate point differential
            const diff = pointsFor - pointsAgainst;

            // Last 10
            const lastTen = (() => {
              const w = getStatValue('lastTenWins');
              const l = getStatValue('lastTenLosses');
              if (w + l > 0) return `${Math.round(w)}-${Math.round(l)}`;
              const dv = getStatDisplay('lastTen', '');
              return dv && typeof dv === 'string' && dv.includes('-') ? dv : '-';
            })();

            standings.push({
              league: 'NBA',
              conference: conferenceName,
              team_name: team.displayName,
              abbreviation: team.abbreviation,
              rank: standings.filter(s => s.conference === conferenceName).length + 1,
              wins: Math.round(wins),
              losses: Math.round(losses),
              pct: winPercent,
              gb: gamesBehind === 0 ? null : gamesBehind.toString(),
              home_record: homeRecord,
              away_record: awayRecord,
              division_record: getStatDisplay('divisionRecord') || getStatDisplay('division'),
              conference_record: getStatDisplay('conferenceRecord', '-') || getStatDisplay('conference', '-'),
              ppg: gamesPlayed > 0 ? pointsFor / gamesPlayed : 0,
              opp_ppg: gamesPlayed > 0 ? pointsAgainst / gamesPlayed : 0,
              diff: gamesPlayed > 0 ? diff / gamesPlayed : 0,
              streak: getStatDisplay('streak', '-') ,
              last_10: lastTen,
            });
          }
        }
      }
    }

    console.log(`Parsed ${standings.length} teams`);

    // Update database
    if (standings.length > 0) {
      // Delete existing standings for NBA
      const { error: deleteError } = await supabase
        .from('team_standings')
        .delete()
        .eq('league', 'NBA');

      if (deleteError) {
        console.error('Error deleting old standings:', deleteError);
      }

      // Insert new standings
      const { error: insertError } = await supabase
        .from('team_standings')
        .insert(standings);

      if (insertError) {
        console.error('Error inserting standings:', insertError);
        throw insertError;
      }

      console.log(`Successfully updated ${standings.length} teams`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        updated: standings.length,
        message: 'NBA standings updated successfully' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error updating NBA standings:', error);
    return new Response(
      JSON.stringify({ 
        success: false,
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    );
  }
});
