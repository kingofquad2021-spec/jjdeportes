import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting NFL news update...');

    const NFL_TEAMS = [
      { id: 1, name: 'Atlanta Falcons', abbreviation: 'ATL' },
      { id: 2, name: 'Buffalo Bills', abbreviation: 'BUF' },
      { id: 3, name: 'Chicago Bears', abbreviation: 'CHI' },
      { id: 4, name: 'Cincinnati Bengals', abbreviation: 'CIN' },
      { id: 5, name: 'Cleveland Browns', abbreviation: 'CLE' },
      { id: 6, name: 'Dallas Cowboys', abbreviation: 'DAL' },
      { id: 7, name: 'Denver Broncos', abbreviation: 'DEN' },
      { id: 8, name: 'Detroit Lions', abbreviation: 'DET' },
      { id: 9, name: 'Green Bay Packers', abbreviation: 'GB' },
      { id: 10, name: 'Tennessee Titans', abbreviation: 'TEN' },
      { id: 11, name: 'Indianapolis Colts', abbreviation: 'IND' },
      { id: 12, name: 'Kansas City Chiefs', abbreviation: 'KC' },
      { id: 13, name: 'Las Vegas Raiders', abbreviation: 'LV' },
      { id: 14, name: 'Los Angeles Rams', abbreviation: 'LAR' },
      { id: 15, name: 'Miami Dolphins', abbreviation: 'MIA' },
      { id: 16, name: 'Minnesota Vikings', abbreviation: 'MIN' },
      { id: 17, name: 'New England Patriots', abbreviation: 'NE' },
      { id: 18, name: 'New Orleans Saints', abbreviation: 'NO' },
      { id: 19, name: 'New York Giants', abbreviation: 'NYG' },
      { id: 20, name: 'New York Jets', abbreviation: 'NYJ' },
      { id: 21, name: 'Philadelphia Eagles', abbreviation: 'PHI' },
      { id: 22, name: 'Arizona Cardinals', abbreviation: 'ARI' },
      { id: 23, name: 'Pittsburgh Steelers', abbreviation: 'PIT' },
      { id: 24, name: 'Los Angeles Chargers', abbreviation: 'LAC' },
      { id: 25, name: 'San Francisco 49ers', abbreviation: 'SF' },
      { id: 26, name: 'Seattle Seahawks', abbreviation: 'SEA' },
      { id: 27, name: 'Tampa Bay Buccaneers', abbreviation: 'TB' },
      { id: 28, name: 'Washington Commanders', abbreviation: 'WSH' },
      { id: 29, name: 'Carolina Panthers', abbreviation: 'CAR' },
      { id: 30, name: 'Jacksonville Jaguars', abbreviation: 'JAX' },
      { id: 33, name: 'Baltimore Ravens', abbreviation: 'BAL' },
      { id: 34, name: 'Houston Texans', abbreviation: 'HOU' }
    ];

    const allNews: any[] = [];

    for (const team of NFL_TEAMS) {
      console.log(`Fetching news for ${team.name}...`);
      
      try {
        const response = await fetch(`https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${team.id}/news`);
        
        if (!response.ok) {
          console.error(`Failed to fetch news for ${team.name}: ${response.status}`);
          continue;
        }

        const data = await response.json();
        
        console.log(`ESPN API response for ${team.name}:`, JSON.stringify(data).substring(0, 500));
        
        if (data.articles && Array.isArray(data.articles)) {
          console.log(`Found ${data.articles.length} articles for ${team.name}`);
          for (const article of data.articles.slice(0, 10)) {
            const newsType = article.headline?.toLowerCase().includes('injury') || article.description?.toLowerCase().includes('injury') || article.description?.toLowerCase().includes('hurt')
              ? 'injury'
              : article.headline?.toLowerCase().includes('return') || article.description?.toLowerCase().includes('return') || article.description?.toLowerCase().includes('back')
              ? 'return'
              : 'general';

            allNews.push({
              league: 'NFL',
              team_name: team.name,
              team_abbreviation: team.abbreviation,
              headline: article.headline || '',
              description: article.description || null,
              news_type: newsType,
              published_date: article.published ? new Date(article.published).toISOString() : new Date().toISOString(),
              source_url: article.links?.web?.href || null
            });
          }
        } else {
          console.log(`No articles found for ${team.name}. Data structure:`, Object.keys(data));
        }
      } catch (error) {
        console.error(`Error fetching news for ${team.name}:`, error);
      }
    }

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const { error: deleteError } = await supabase
      .from('team_news')
      .delete()
      .eq('league', 'NFL')
      .lt('published_date', sevenDaysAgo.toISOString());

    if (deleteError) {
      console.error('Error deleting old news:', deleteError);
    }

    if (allNews.length > 0) {
      const { error: insertError } = await supabase
        .from('team_news')
        .upsert(allNews, { onConflict: 'headline,team_name' });

      if (insertError) {
        console.error('Error inserting news:', insertError);
        throw insertError;
      }

      console.log(`Successfully inserted ${allNews.length} news articles`);

      // Analizar y actualizar roster automáticamente para noticias de lesiones/regresos
      const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
      if (LOVABLE_API_KEY) {
        const injuryOrReturnNews = allNews.filter(n => n.news_type === 'injury' || n.news_type === 'return');
        console.log(`Analyzing ${injuryOrReturnNews.length} injury/return news articles...`);

        for (const news of injuryOrReturnNews) {
          try {
            const newsText = `${news.headline}. ${news.description || ''}`;
            const systemPrompt = `Eres un experto analizador de noticias deportivas. Extrae información estructurada sobre actualizaciones de roster de jugadores.`;
            const prompt = `Analiza esta noticia del equipo ${news.team_name} en la liga NFL:\n\n${newsText}\n\nExtrae todos los jugadores mencionados con su estado actual, descripción de lesión si aplica, y semanas estimadas fuera.`;

            const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${LOVABLE_API_KEY}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                model: 'google/gemini-2.5-flash',
                messages: [
                  { role: 'system', content: systemPrompt },
                  { role: 'user', content: prompt }
                ],
                tools: [{
                  type: 'function',
                  function: {
                    name: 'extract_roster_updates',
                    description: 'Extrae información estructurada sobre actualizaciones de jugadores',
                    parameters: {
                      type: 'object',
                      properties: {
                        summary: { type: 'string', description: 'Resumen breve de las actualizaciones' },
                        players: {
                          type: 'array',
                          items: {
                            type: 'object',
                            properties: {
                              player_name: { type: 'string' },
                              status: { type: 'string', enum: ['active', 'injured', 'out', 'questionable', 'doubtful'] },
                              injury_description: { type: 'string' },
                              weeks_out: { type: 'number' }
                            },
                            required: ['player_name', 'status']
                          }
                        }
                      },
                      required: ['summary', 'players']
                    }
                  }
                }],
                tool_choice: { type: 'function', function: { name: 'extract_roster_updates' } }
              })
            });

            if (aiResponse.ok) {
              const aiData = await aiResponse.json();
              const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
              if (toolCall) {
                const rosterUpdates = JSON.parse(toolCall.function.arguments);
                for (const playerUpdate of rosterUpdates.players) {
                  const expectedReturnDate = playerUpdate.weeks_out > 0 
                    ? new Date(Date.now() + playerUpdate.weeks_out * 7 * 24 * 60 * 60 * 1000).toISOString()
                    : null;

                  const { error: updateError } = await supabase
                    .from('rosters')
                    .update({
                      injury_status: playerUpdate.status,
                      injury_description: playerUpdate.injury_description || null,
                      expected_return_date: expectedReturnDate,
                      last_news_update: new Date().toISOString()
                    })
                    .eq('league', 'NFL')
                    .eq('team_name', news.team_name)
                    .ilike('player_name', `%${playerUpdate.player_name}%`);

                  if (!updateError) {
                    console.log(`Updated roster for ${playerUpdate.player_name}`);
                  }
                }
              }
            }
          } catch (error) {
            console.error(`Error analyzing news for ${news.team_name}:`, error);
          }
        }
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Updated ${allNews.length} NFL news articles`,
        newsCount: allNews.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in update-nfl-news:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
