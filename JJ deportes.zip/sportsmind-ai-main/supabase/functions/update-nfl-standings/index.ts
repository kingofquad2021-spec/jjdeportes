import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.76.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Standing {
  rank: number;
  team_name: string;
  abbreviation: string;
  wins: number;
  losses: number;
  pct: number;
  ppg: number;
  opp_ppg: number;
  diff: number;
  conference: string;
  home_record: string;
  away_record: string;
  division_record: string;
  conference_record: string;
  last_10: string;
  streak: string;
  gb: string;
  league: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting NFL standings update...');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch NFL standings from ESPN API
    const response = await fetch('https://site.api.espn.com/apis/v2/sports/football/nfl/standings');
    const data = await response.json();
    
    console.log('Fetched standings data from ESPN');

    const standings: Standing[] = [];

    // Parse the standings data
    if (data.children) {
      for (const conference of data.children) {
        const conferenceName = conference.name;
        
        if (conference.standings?.entries) {
          for (const team of conference.standings.entries) {
            const stats = team.stats;
            
            const getStatValue = (name: string) => {
              return stats.find((s: any) => s.name === name)?.value || 0;
            };
            
            const getStatDisplay = (name: string, defaultValue = '') => {
              const stat = stats.find((s: any) => s.name === name);
              return (stat?.displayValue ?? stat?.value ?? defaultValue) as string;
            };

            const getPairRecord = (winsName: string, lossesName: string): string | null => {
              const w = getStatValue(winsName);
              const l = getStatValue(lossesName);
              if (w + l > 0) return `${Math.round(w)}-${Math.round(l)}`;
              return null;
            };

            const resolveRecord = (prefNames: string[], pairs: Array<[string, string]>) => {
              // 1) Prefer known display fields
              for (const n of prefNames) {
                const dv = getStatDisplay(n, '');
                if (typeof dv === 'string' && dv.includes('-')) return dv;
              }
              // 2) Use explicit win/loss names
              for (const [w, l] of pairs) {
                const rec = getPairRecord(w, l);
                if (rec && rec !== '0-0') return rec;
              }
              // 3) Try any stat that matches the keyword and looks like a record
              const any = stats.find((s: any) => prefNames.some(n => s.name?.toLowerCase().includes(n.toLowerCase())) && typeof s.displayValue === 'string' && s.displayValue.includes('-'));
              if (any) return any.displayValue;
              return '0-0';
            };

            const wins = getStatValue('wins');
            const losses = getStatValue('losses');
            const winPercent = getStatValue('winPercent');
            const pointsFor = getStatValue('pointsFor');
            const pointsAgainst = getStatValue('pointsAgainst');
            const gamesPlayed = getStatValue('gamesPlayed');
            
            // HOME and AWAY (ROAD) records with robust fallbacks
            const homeRecord = resolveRecord(['home', 'homeRecord'], [['homeWins', 'homeLosses']]);
            const awayRecord = resolveRecord(['road', 'roadRecord', 'away', 'awayRecord'], [
              ['roadWins', 'roadLosses'],
              ['awayWins', 'awayLosses'],
            ]);

            // Last 10
            const lastTen = (() => {
              const w = getStatValue('lastTenWins');
              const l = getStatValue('lastTenLosses');
              if (w + l > 0) return `${Math.round(w)}-${Math.round(l)}`;
              const dv = getStatDisplay('lastTen', '');
              return dv && typeof dv === 'string' && dv.includes('-') ? dv : '-';
            })();
            
            standings.push({
              rank: standings.filter(s => s.conference === conferenceName).length + 1,
              team_name: team.team.displayName,
              abbreviation: team.team.abbreviation,
              wins,
              losses,
              pct: winPercent,
              ppg: gamesPlayed > 0 ? pointsFor / gamesPlayed : 0,
              opp_ppg: gamesPlayed > 0 ? pointsAgainst / gamesPlayed : 0,
              diff: pointsFor - pointsAgainst,
              conference: conferenceName,
              home_record: homeRecord,
              away_record: awayRecord,
              division_record: getStatDisplay('divisionRecord') || getStatDisplay('division'),
              conference_record: getStatDisplay('conferenceRecord', '-') || getStatDisplay('conference', '-'),
              last_10: lastTen,
              streak: getStatDisplay('streak', '-'),
              gb: getStatDisplay('gamesBehind', '0'),
              league: 'NFL'
            });
          }
        }
      }
    }

    console.log(`Parsed ${standings.length} teams`);

    // Delete existing NFL standings
    const { error: deleteError } = await supabase
      .from('team_standings')
      .delete()
      .eq('league', 'NFL');

    if (deleteError) {
      console.error('Error deleting old standings:', deleteError);
      throw deleteError;
    }

    // Insert new standings
    const { error: insertError } = await supabase
      .from('team_standings')
      .insert(standings);

    if (insertError) {
      console.error('Error inserting standings:', insertError);
      throw insertError;
    }

    console.log(`Successfully updated ${standings.length} teams`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        updated: standings.length 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error in update-nfl-standings function:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
