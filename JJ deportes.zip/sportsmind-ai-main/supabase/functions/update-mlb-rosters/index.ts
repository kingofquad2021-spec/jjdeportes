import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.76.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Player {
  league: string;
  team_abbreviation: string;
  team_name: string;
  player_name: string;
  position: string | null;
  jersey_number: string | null;
  height: string | null;
  weight: string | null;
  age: number | null;
  player_image: string | null;
}

const MLB_TEAMS = [
  { id: '29', name: 'Arizona Diamondbacks', abbreviation: 'ARI' },
  { id: '15', name: 'Atlanta Braves', abbreviation: 'ATL' },
  { id: '1', name: 'Baltimore Orioles', abbreviation: 'BAL' },
  { id: '2', name: 'Boston Red Sox', abbreviation: 'BOS' },
  { id: '16', name: 'Chicago Cubs', abbreviation: 'CHC' },
  { id: '4', name: 'Chicago White Sox', abbreviation: 'CHW' },
  { id: '17', name: 'Cincinnati Reds', abbreviation: 'CIN' },
  { id: '5', name: 'Cleveland Guardians', abbreviation: 'CLE' },
  { id: '27', name: 'Colorado Rockies', abbreviation: 'COL' },
  { id: '6', name: 'Detroit Tigers', abbreviation: 'DET' },
  { id: '18', name: 'Houston Astros', abbreviation: 'HOU' },
  { id: '7', name: 'Kansas City Royals', abbreviation: 'KC' },
  { id: '3', name: 'Los Angeles Angels', abbreviation: 'LAA' },
  { id: '19', name: 'Los Angeles Dodgers', abbreviation: 'LAD' },
  { id: '28', name: 'Miami Marlins', abbreviation: 'MIA' },
  { id: '8', name: 'Milwaukee Brewers', abbreviation: 'MIL' },
  { id: '9', name: 'Minnesota Twins', abbreviation: 'MIN' },
  { id: '21', name: 'New York Mets', abbreviation: 'NYM' },
  { id: '10', name: 'New York Yankees', abbreviation: 'NYY' },
  { id: '11', name: 'Oakland Athletics', abbreviation: 'OAK' },
  { id: '22', name: 'Philadelphia Phillies', abbreviation: 'PHI' },
  { id: '23', name: 'Pittsburgh Pirates', abbreviation: 'PIT' },
  { id: '25', name: 'San Diego Padres', abbreviation: 'SD' },
  { id: '26', name: 'San Francisco Giants', abbreviation: 'SF' },
  { id: '12', name: 'Seattle Mariners', abbreviation: 'SEA' },
  { id: '24', name: 'St. Louis Cardinals', abbreviation: 'STL' },
  { id: '30', name: 'Tampa Bay Rays', abbreviation: 'TB' },
  { id: '13', name: 'Texas Rangers', abbreviation: 'TEX' },
  { id: '14', name: 'Toronto Blue Jays', abbreviation: 'TOR' },
  { id: '20', name: 'Washington Nationals', abbreviation: 'WSH' },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting MLB rosters update...');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const allPlayers: Player[] = [];

    for (const team of MLB_TEAMS) {
      try {
        const rosterUrl = `https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/teams/${team.id}/roster?season=2025`;
        console.log(`Fetching roster for ${team.name} (2025-2026 season)...`);
        
        const response = await fetch(rosterUrl);
        if (!response.ok) {
          console.error(`Failed to fetch roster for ${team.name}`);
          continue;
        }

        const data = await response.json();
        
        if (data.athletes) {
          // Athletes are grouped by position
          for (const positionGroup of data.athletes) {
            if (positionGroup.items) {
              for (const athlete of positionGroup.items) {
                allPlayers.push({
                  league: 'MLB',
                  team_abbreviation: team.abbreviation,
                  team_name: team.name,
                  player_name: athlete.fullName || athlete.displayName || 'Unknown',
                  position: positionGroup.position || null,
                  jersey_number: athlete.jersey || null,
                  height: athlete.displayHeight || null,
                  weight: athlete.displayWeight || null,
                  age: athlete.age || null,
                  player_image: athlete.headshot?.href || null,
                });
              }
            }
          }
        }
      } catch (error) {
        console.error(`Error fetching roster for ${team.name}:`, error);
      }
    }

    console.log(`Parsed ${allPlayers.length} players from MLB rosters`);

    // Delete existing MLB rosters
    const { error: deleteError } = await supabase
      .from('rosters')
      .delete()
      .eq('league', 'MLB');

    if (deleteError) {
      throw deleteError;
    }

    // Insert new rosters
    const { error: insertError } = await supabase
      .from('rosters')
      .insert(allPlayers);

    if (insertError) {
      throw insertError;
    }

    console.log(`Successfully updated ${allPlayers.length} MLB players`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Successfully updated ${allPlayers.length} MLB players` 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error updating MLB rosters:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
