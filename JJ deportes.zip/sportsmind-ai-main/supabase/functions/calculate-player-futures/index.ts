import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { league } = await req.json();
    const targetLeague = league || 'NBA';

    console.log(`Calculating player futures for ${targetLeague}...`);

    // Get all player stats
    const { data: playerStats, error: statsError } = await supabase
      .from('player_stats')
      .select('*')
      .eq('league', targetLeague)
      .order('game_date', { ascending: false });

    if (statsError) throw statsError;

    // Group stats by player
    const playerMap = new Map();

    for (const stat of playerStats || []) {
      const key = stat.player_name;
      if (!playerMap.has(key)) {
        playerMap.set(key, []);
      }
      playerMap.get(key).push(stat);
    }

    const futures = [];

    // Calculate futures for each category
    const categories = ['points', 'rebounds', 'assists', 'steals', 'blocks'];

    for (const [playerName, stats] of playerMap.entries()) {
      if (stats.length === 0) continue;

      const latestStat = stats[0];
      const last10Stats = stats.slice(0, 10);

      for (const category of categories) {
        const seasonTotal = stats.reduce((sum: number, s: any) => sum + (s[category] || 0), 0);
        const seasonAvg = seasonTotal / stats.length;
        
        const last10Total = last10Stats.reduce((sum: number, s: any) => sum + (s[category] || 0), 0);
        const last10Avg = last10Total / last10Stats.length;

        // Calculate trend
        let trend = 'stable';
        const difference = last10Avg - seasonAvg;
        if (difference > seasonAvg * 0.1) trend = 'up';
        else if (difference < -seasonAvg * 0.1) trend = 'down';

        // Projected value (simple linear projection)
        const gamesRemaining = 82 - stats.length;
        const projectedValue = seasonTotal + (last10Avg * gamesRemaining);

        futures.push({
          player_name: playerName,
          team_name: latestStat.team_name,
          team_abbreviation: latestStat.team_abbreviation,
          league: targetLeague,
          season: '2024-25',
          category: `${category}_leader`,
          projected_value: Math.round(projectedValue * 100) / 100,
          current_rank: 0, // Will be set after ranking
          games_analyzed: stats.length,
          last_10_avg: Math.round(last10Avg * 100) / 100,
          season_avg: Math.round(seasonAvg * 100) / 100,
          trend: trend,
        });
      }
    }

    // Rank players in each category
    for (const category of categories) {
      const categoryFutures = futures
        .filter(f => f.category === `${category}_leader`)
        .sort((a, b) => b.season_avg - a.season_avg);

      categoryFutures.forEach((future, index) => {
        future.current_rank = index + 1;
      });
    }

    // Upsert player futures
    if (futures.length > 0) {
      const { error: upsertError } = await supabase
        .from('player_futures')
        .upsert(futures, { 
          onConflict: 'player_name,league,season,category' 
        });

      if (upsertError) throw upsertError;
    }

    return new Response(
      JSON.stringify({ 
        message: `Player futures calculated successfully for ${targetLeague}`,
        count: futures.length 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error in calculate-player-futures:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});