import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.39.3";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Game {
  id: string;
  game_id: string;
  home_team: string;
  away_team: string;
  home_team_abbreviation: string;
  away_team_abbreviation: string;
  league: string;
  predicted_winner?: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { games } = await req.json() as { games: Game[] };

    if (!games || games.length === 0) {
      return new Response(
        JSON.stringify({ error: 'No games provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const lovableApiKey = Deno.env.get('LOVABLE_API_KEY');
    if (!lovableApiKey) {
      throw new Error('LOVABLE_API_KEY is not configured');
    }

    const matchups = [];

    for (const game of games) {
      try {
        console.log(`\n=== Processing game: ${game.home_team} vs ${game.away_team} ===`);
        console.log(`Looking for home team: ${game.home_team_abbreviation}, away team: ${game.away_team_abbreviation}, league: ${game.league}`);
        
        // First get the roster of players for each team
        const { data: homeRoster, error: homeRosterError } = await supabase
          .from('rosters')
          .select('player_name')
          .eq('team_abbreviation', game.home_team_abbreviation)
          .eq('league', game.league);

        const { data: awayRoster, error: awayRosterError } = await supabase
          .from('rosters')
          .select('player_name')
          .eq('team_abbreviation', game.away_team_abbreviation)
          .eq('league', game.league);

        console.log(`Home roster: ${homeRoster?.length || 0} players`);
        console.log(`Away roster: ${awayRoster?.length || 0} players`);

        if (homeRosterError || awayRosterError) {
          console.error('Error fetching rosters, skipping game');
          continue;
        }

        if (!homeRoster || homeRoster.length === 0 || !awayRoster || awayRoster.length === 0) {
          console.log('No roster data available for one or both teams, skipping game');
          continue;
        }

        // Create sets of player names for quick lookup
        const homeRosterNames = new Set(homeRoster.map(p => p.player_name));
        const awayRosterNames = new Set(awayRoster.map(p => p.player_name));
        
        // Get top players from each team based on recent performance
        const { data: homePlayers, error: homeError } = await supabase
          .from('player_stats')
          .select('*')
          .eq('team_abbreviation', game.home_team_abbreviation)
          .eq('league', game.league)
          .order('game_date', { ascending: false })
          .limit(200);

        const { data: awayPlayers, error: awayError } = await supabase
          .from('player_stats')
          .select('*')
          .eq('team_abbreviation', game.away_team_abbreviation)
          .eq('league', game.league)
          .order('game_date', { ascending: false })
          .limit(200);

        if (homeError || awayError) {
          console.error('Error fetching players, skipping game');
          continue;
        }

        // Filter players to only include those in the current roster
        const homePlayersFiltered = homePlayers?.filter(p => homeRosterNames.has(p.player_name)) || [];
        const awayPlayersFiltered = awayPlayers?.filter(p => awayRosterNames.has(p.player_name)) || [];

        console.log(`Home players in roster with stats: ${homePlayersFiltered.length}`);
        console.log(`Away players in roster with stats: ${awayPlayersFiltered.length}`);

        if (homePlayersFiltered.length === 0 || awayPlayersFiltered.length === 0) {
          console.log('No player stats available for current roster players, skipping game');
          continue;
        }

        // Calculate player averages
        const calculatePlayerAverages = (stats: any[]) => {
          const playerMap = new Map();
          
          stats.forEach(stat => {
            if (!playerMap.has(stat.player_name)) {
              playerMap.set(stat.player_name, {
                name: stat.player_name,
                games: 0,
                points: 0,
                assists: 0,
                rebounds: 0,
                goals: 0,
                shots: 0,
                passing_yards: 0,
                rushing_yards: 0,
                touchdowns: 0,
              });
            }
            
            const player = playerMap.get(stat.player_name);
            player.games++;
            player.points += stat.points || 0;
            player.assists += stat.assists || 0;
            player.rebounds += stat.rebounds || 0;
            player.goals += stat.goals || 0;
            player.shots += stat.shots || 0;
            player.passing_yards += stat.passing_yards || 0;
            player.rushing_yards += stat.rushing_yards || 0;
            player.touchdowns += stat.touchdowns || 0;
          });

          return Array.from(playerMap.values()).map(player => ({
            ...player,
            avgPoints: player.games > 0 ? (player.points / player.games).toFixed(1) : '0.0',
            avgAssists: player.games > 0 ? (player.assists / player.games).toFixed(1) : '0.0',
            avgRebounds: player.games > 0 ? (player.rebounds / player.games).toFixed(1) : '0.0',
            avgGoals: player.games > 0 ? (player.goals / player.games).toFixed(1) : '0.0',
            avgShots: player.games > 0 ? (player.shots / player.games).toFixed(1) : '0.0',
            avgPassingYards: player.games > 0 ? (player.passing_yards / player.games).toFixed(1) : '0.0',
            avgRushingYards: player.games > 0 ? (player.rushing_yards / player.games).toFixed(1) : '0.0',
            avgTouchdowns: player.games > 0 ? (player.touchdowns / player.games).toFixed(1) : '0.0',
          }));
        };

        const homePlayerAvgs = calculatePlayerAverages(homePlayersFiltered);
        const awayPlayerAvgs = calculatePlayerAverages(awayPlayersFiltered);

        // Get top player from each team based on league
        let homeTopPlayer, awayTopPlayer;
        
        if (game.league === 'NBA' || game.league === 'MLB') {
          homeTopPlayer = homePlayerAvgs.sort((a, b) => parseFloat(b.avgPoints) - parseFloat(a.avgPoints))[0];
          awayTopPlayer = awayPlayerAvgs.sort((a, b) => parseFloat(b.avgPoints) - parseFloat(a.avgPoints))[0];
        } else if (game.league === 'NFL') {
          homeTopPlayer = homePlayerAvgs.sort((a, b) => parseFloat(b.avgPassingYards) + parseFloat(b.avgRushingYards) - parseFloat(a.avgPassingYards) - parseFloat(a.avgRushingYards))[0];
          awayTopPlayer = awayPlayerAvgs.sort((a, b) => parseFloat(b.avgPassingYards) + parseFloat(b.avgRushingYards) - parseFloat(a.avgPassingYards) - parseFloat(a.avgRushingYards))[0];
        } else { // NHL, Soccer
          homeTopPlayer = homePlayerAvgs.sort((a, b) => parseFloat(b.avgGoals) - parseFloat(a.avgGoals))[0];
          awayTopPlayer = awayPlayerAvgs.sort((a, b) => parseFloat(b.avgGoals) - parseFloat(a.avgGoals))[0];
        }

        if (!homeTopPlayer || !awayTopPlayer) {
          continue;
        }

        // Generate AI analysis
        const prompt = `You are a sports analyst. Compare these two players for an upcoming ${game.league} matchup between ${game.home_team} and ${game.away_team}.

${game.home_team} Player: ${homeTopPlayer.name}
- Games: ${homeTopPlayer.games}
${game.league === 'NBA' || game.league === 'MLB' ? `- Points: ${homeTopPlayer.avgPoints}/game
- Assists: ${homeTopPlayer.avgAssists}/game
- Rebounds: ${homeTopPlayer.avgRebounds}/game` : ''}
${game.league === 'NFL' ? `- Passing Yards: ${homeTopPlayer.avgPassingYards}/game
- Rushing Yards: ${homeTopPlayer.avgRushingYards}/game
- Touchdowns: ${homeTopPlayer.avgTouchdowns}/game` : ''}
${game.league === 'NHL' || game.league === 'Soccer' ? `- Goals: ${homeTopPlayer.avgGoals}/game
- Assists: ${homeTopPlayer.avgAssists}/game
- Shots: ${homeTopPlayer.avgShots}/game` : ''}

${game.away_team} Player: ${awayTopPlayer.name}
- Games: ${awayTopPlayer.games}
${game.league === 'NBA' || game.league === 'MLB' ? `- Points: ${awayTopPlayer.avgPoints}/game
- Assists: ${awayTopPlayer.avgAssists}/game
- Rebounds: ${awayTopPlayer.avgRebounds}/game` : ''}
${game.league === 'NFL' ? `- Passing Yards: ${awayTopPlayer.avgPassingYards}/game
- Rushing Yards: ${awayTopPlayer.avgRushingYards}/game
- Touchdowns: ${awayTopPlayer.avgTouchdowns}/game` : ''}
${game.league === 'NHL' || game.league === 'Soccer' ? `- Goals: ${awayTopPlayer.avgGoals}/game
- Assists: ${awayTopPlayer.avgAssists}/game
- Shots: ${awayTopPlayer.avgShots}/game` : ''}

Provide a SHORT analysis (2-3 sentences max) comparing their recent performance and who has the edge. End with "Advantage: [Player Name]". Keep it concise and focused.`;

        const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${lovableApiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            model: 'google/gemini-2.5-flash',
            messages: [
              { role: 'system', content: 'You are a concise sports analyst. Keep responses under 3 sentences.' },
              { role: 'user', content: prompt }
            ],
          }),
        });

        if (!aiResponse.ok) {
          const errorText = await aiResponse.text();
          console.error('AI API error:', aiResponse.status, errorText);
          continue;
        }

        const aiData = await aiResponse.json();
        const analysis = aiData.choices[0]?.message?.content || 'Analysis not available';

        matchups.push({
          gameId: game.id,
          homeTeam: game.home_team,
          awayTeam: game.away_team,
          league: game.league,
          homePlayer: {
            name: homeTopPlayer.name,
            games: homeTopPlayer.games,
            stats: game.league === 'NBA' || game.league === 'MLB' ? {
              points: homeTopPlayer.avgPoints,
              assists: homeTopPlayer.avgAssists,
              rebounds: homeTopPlayer.avgRebounds,
            } : game.league === 'NFL' ? {
              passingYards: homeTopPlayer.avgPassingYards,
              rushingYards: homeTopPlayer.avgRushingYards,
              touchdowns: homeTopPlayer.avgTouchdowns,
            } : {
              goals: homeTopPlayer.avgGoals,
              assists: homeTopPlayer.avgAssists,
              shots: homeTopPlayer.avgShots,
            }
          },
          awayPlayer: {
            name: awayTopPlayer.name,
            games: awayTopPlayer.games,
            stats: game.league === 'NBA' || game.league === 'MLB' ? {
              points: awayTopPlayer.avgPoints,
              assists: awayTopPlayer.avgAssists,
              rebounds: awayTopPlayer.avgRebounds,
            } : game.league === 'NFL' ? {
              passingYards: awayTopPlayer.avgPassingYards,
              rushingYards: awayTopPlayer.avgRushingYards,
              touchdowns: awayTopPlayer.avgTouchdowns,
            } : {
              goals: awayTopPlayer.avgGoals,
              assists: awayTopPlayer.avgAssists,
              shots: awayTopPlayer.avgShots,
            }
          },
          analysis,
        });
      } catch (error) {
        console.error(`Error processing matchup for game ${game.id}:`, error);
        continue;
      }
    }

    return new Response(
      JSON.stringify({ matchups }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in analyze-player-matchups:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});