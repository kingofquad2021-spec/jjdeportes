import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting MLB news update...');

    const MLB_TEAMS = [
      { id: 109, name: 'Arizona Diamondbacks', abbreviation: 'ARI' },
      { id: 144, name: 'Atlanta Braves', abbreviation: 'ATL' },
      { id: 110, name: 'Baltimore Orioles', abbreviation: 'BAL' },
      { id: 111, name: 'Boston Red Sox', abbreviation: 'BOS' },
      { id: 112, name: 'Chicago Cubs', abbreviation: 'CHC' },
      { id: 145, name: 'Chicago White Sox', abbreviation: 'CWS' },
      { id: 113, name: 'Cincinnati Reds', abbreviation: 'CIN' },
      { id: 114, name: 'Cleveland Guardians', abbreviation: 'CLE' },
      { id: 115, name: 'Colorado Rockies', abbreviation: 'COL' },
      { id: 116, name: 'Detroit Tigers', abbreviation: 'DET' },
      { id: 117, name: 'Houston Astros', abbreviation: 'HOU' },
      { id: 118, name: 'Kansas City Royals', abbreviation: 'KC' },
      { id: 108, name: 'Los Angeles Angels', abbreviation: 'LAA' },
      { id: 119, name: 'Los Angeles Dodgers', abbreviation: 'LAD' },
      { id: 146, name: 'Miami Marlins', abbreviation: 'MIA' },
      { id: 158, name: 'Milwaukee Brewers', abbreviation: 'MIL' },
      { id: 142, name: 'Minnesota Twins', abbreviation: 'MIN' },
      { id: 121, name: 'New York Mets', abbreviation: 'NYM' },
      { id: 147, name: 'New York Yankees', abbreviation: 'NYY' },
      { id: 133, name: 'Oakland Athletics', abbreviation: 'OAK' },
      { id: 143, name: 'Philadelphia Phillies', abbreviation: 'PHI' },
      { id: 134, name: 'Pittsburgh Pirates', abbreviation: 'PIT' },
      { id: 135, name: 'San Diego Padres', abbreviation: 'SD' },
      { id: 137, name: 'San Francisco Giants', abbreviation: 'SF' },
      { id: 136, name: 'Seattle Mariners', abbreviation: 'SEA' },
      { id: 138, name: 'St. Louis Cardinals', abbreviation: 'STL' },
      { id: 139, name: 'Tampa Bay Rays', abbreviation: 'TB' },
      { id: 140, name: 'Texas Rangers', abbreviation: 'TEX' },
      { id: 141, name: 'Toronto Blue Jays', abbreviation: 'TOR' },
      { id: 120, name: 'Washington Nationals', abbreviation: 'WSH' }
    ];

    const allNews: any[] = [];

    for (const team of MLB_TEAMS) {
      console.log(`Fetching news for ${team.name}...`);
      
      try {
        const response = await fetch(`https://site.api.espn.com/apis/site/v2/sports/baseball/mlb/teams/${team.id}/news`);
        
        if (!response.ok) {
          console.error(`Failed to fetch news for ${team.name}: ${response.status}`);
          continue;
        }

        const data = await response.json();
        
        console.log(`ESPN API response for ${team.name}:`, JSON.stringify(data).substring(0, 500));
        
        if (data.articles && Array.isArray(data.articles)) {
          console.log(`Found ${data.articles.length} articles for ${team.name}`);
          for (const article of data.articles.slice(0, 10)) {
            const newsType = article.headline?.toLowerCase().includes('injury') || article.description?.toLowerCase().includes('injury') || article.description?.toLowerCase().includes('hurt')
              ? 'injury'
              : article.headline?.toLowerCase().includes('return') || article.description?.toLowerCase().includes('return') || article.description?.toLowerCase().includes('back')
              ? 'return'
              : 'general';

            allNews.push({
              league: 'MLB',
              team_name: team.name,
              team_abbreviation: team.abbreviation,
              headline: article.headline || '',
              description: article.description || null,
              news_type: newsType,
              published_date: article.published ? new Date(article.published).toISOString() : new Date().toISOString(),
              source_url: article.links?.web?.href || null
            });
          }
        } else {
          console.log(`No articles found for ${team.name}. Data structure:`, Object.keys(data));
        }
      } catch (error) {
        console.error(`Error fetching news for ${team.name}:`, error);
      }
    }

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const { error: deleteError } = await supabase
      .from('team_news')
      .delete()
      .eq('league', 'MLB')
      .lt('published_date', sevenDaysAgo.toISOString());

    if (deleteError) {
      console.error('Error deleting old news:', deleteError);
    }

    if (allNews.length > 0) {
      const { error: insertError } = await supabase
        .from('team_news')
        .upsert(allNews, { onConflict: 'headline,team_name' });

      if (insertError) {
        console.error('Error inserting news:', insertError);
        throw insertError;
      }

      console.log(`Successfully inserted ${allNews.length} news articles`);

      // Analizar y actualizar roster automáticamente para noticias de lesiones/regresos
      const LOVABLE_API_KEY = Deno.env.get('LOVABLE_API_KEY');
      if (LOVABLE_API_KEY) {
        const injuryOrReturnNews = allNews.filter(n => n.news_type === 'injury' || n.news_type === 'return');
        console.log(`Analyzing ${injuryOrReturnNews.length} injury/return news articles...`);

        for (const news of injuryOrReturnNews) {
          try {
            const newsText = `${news.headline}. ${news.description || ''}`;
            const systemPrompt = `Eres un experto analizador de noticias deportivas. Extrae información estructurada sobre actualizaciones de roster de jugadores.`;
            const prompt = `Analiza esta noticia del equipo ${news.team_name} en la liga MLB:\n\n${newsText}\n\nExtrae todos los jugadores mencionados con su estado actual, descripción de lesión si aplica, y semanas estimadas fuera.`;

            const aiResponse = await fetch('https://ai.gateway.lovable.dev/v1/chat/completions', {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${LOVABLE_API_KEY}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                model: 'google/gemini-2.5-flash',
                messages: [
                  { role: 'system', content: systemPrompt },
                  { role: 'user', content: prompt }
                ],
                tools: [{
                  type: 'function',
                  function: {
                    name: 'extract_roster_updates',
                    description: 'Extrae información estructurada sobre actualizaciones de jugadores',
                    parameters: {
                      type: 'object',
                      properties: {
                        summary: { type: 'string', description: 'Resumen breve de las actualizaciones' },
                        players: {
                          type: 'array',
                          items: {
                            type: 'object',
                            properties: {
                              player_name: { type: 'string' },
                              status: { type: 'string', enum: ['active', 'injured', 'out', 'questionable', 'doubtful'] },
                              injury_description: { type: 'string' },
                              weeks_out: { type: 'number' }
                            },
                            required: ['player_name', 'status']
                          }
                        }
                      },
                      required: ['summary', 'players']
                    }
                  }
                }],
                tool_choice: { type: 'function', function: { name: 'extract_roster_updates' } }
              })
            });

            if (aiResponse.ok) {
              const aiData = await aiResponse.json();
              const toolCall = aiData.choices?.[0]?.message?.tool_calls?.[0];
              if (toolCall) {
                const rosterUpdates = JSON.parse(toolCall.function.arguments);
                for (const playerUpdate of rosterUpdates.players) {
                  const expectedReturnDate = playerUpdate.weeks_out > 0 
                    ? new Date(Date.now() + playerUpdate.weeks_out * 7 * 24 * 60 * 60 * 1000).toISOString()
                    : null;

                  const { error: updateError } = await supabase
                    .from('rosters')
                    .update({
                      injury_status: playerUpdate.status,
                      injury_description: playerUpdate.injury_description || null,
                      expected_return_date: expectedReturnDate,
                      last_news_update: new Date().toISOString()
                    })
                    .eq('league', 'MLB')
                    .eq('team_name', news.team_name)
                    .ilike('player_name', `%${playerUpdate.player_name}%`);

                  if (!updateError) {
                    console.log(`Updated roster for ${playerUpdate.player_name}`);
                  }
                }
              }
            }
          } catch (error) {
            console.error(`Error analyzing news for ${news.team_name}:`, error);
          }
        }
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Updated ${allNews.length} MLB news articles`,
        newsCount: allNews.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in update-mlb-news:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
