import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.76.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { league, homeTeam, awayTeam } = await req.json();
    
    console.log(`Generating prediction for ${league}: ${homeTeam} vs ${awayTeam}`);
    
    // Initialize Supabase client
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Fetch team standings data
    const { data: homeTeamData, error: homeError } = await supabase
      .from('team_standings')
      .select('*')
      .eq('league', league)
      .eq('team_name', homeTeam)
      .single();

    const { data: awayTeamData, error: awayError } = await supabase
      .from('team_standings')
      .select('*')
      .eq('league', league)
      .eq('team_name', awayTeam)
      .single();

    if (homeError || awayError || !homeTeamData || !awayTeamData) {
      console.error('Error fetching team data:', homeError || awayError);
      throw new Error('Could not fetch team standings data');
    }

    console.log('Home team data:', homeTeamData);
    console.log('Away team data:', awayTeamData);

    // Calculate metrics
    const homeWinPct = parseFloat(homeTeamData.pct) || 0;
    const awayWinPct = parseFloat(awayTeamData.pct) || 0;
    
    const homePpg = parseFloat(homeTeamData.ppg) || 0;
    const awayPpg = parseFloat(awayTeamData.ppg) || 0;
    const homeOppPpg = parseFloat(homeTeamData.opp_ppg) || 0;
    const awayOppPpg = parseFloat(awayTeamData.opp_ppg) || 0;
    
    const homeDiff = parseFloat(homeTeamData.diff) || 0;
    const awayDiff = parseFloat(awayTeamData.diff) || 0;

    // Parse home/away records
    const parseRecord = (record: string) => {
      if (!record) return { wins: 0, total: 0, pct: 0 };
      const [wins, losses] = record.split('-').map(n => parseInt(n) || 0);
      const total = wins + losses;
      return { wins, total, pct: total > 0 ? wins / total : 0 };
    };

    const homeHomeRecord = parseRecord(homeTeamData.home_record);
    const awayAwayRecord = parseRecord(awayTeamData.away_record);

    // Parse last 10 games
    const parseLastTen = (last10: string) => {
      if (!last10) return { wins: 0, losses: 0, pct: 0 };
      const [wins, losses] = last10.split('-').map(n => parseInt(n) || 0);
      return { wins, losses, pct: (wins + losses) > 0 ? wins / (wins + losses) : 0 };
    };

    const homeRecentForm = parseLastTen(homeTeamData.last_10);
    const awayRecentForm = parseLastTen(awayTeamData.last_10);

    // Calculate prediction factors (weighted)
    const homeAdvantage = 4; // 4% bonus for home team
    const winPctWeight = 0.25;
    const homeAwayRecordWeight = 0.30;
    const recentFormWeight = 0.25;
    const differentialWeight = 0.20;

    let homeScore = homeAdvantage;
    let awayScore = 0;

    // Win percentage comparison
    homeScore += (homeWinPct - awayWinPct) * 100 * winPctWeight;
    awayScore += (awayWinPct - homeWinPct) * 100 * winPctWeight;

    // Home/Away record comparison
    homeScore += (homeHomeRecord.pct - awayAwayRecord.pct) * 100 * homeAwayRecordWeight;
    awayScore += (awayAwayRecord.pct - homeHomeRecord.pct) * 100 * homeAwayRecordWeight;

    // Recent form comparison
    homeScore += (homeRecentForm.pct - awayRecentForm.pct) * 100 * recentFormWeight;
    awayScore += (awayRecentForm.pct - homeRecentForm.pct) * 100 * recentFormWeight;

    // Point differential comparison
    homeScore += (homeDiff - awayDiff) * differentialWeight;
    awayScore += (awayDiff - homeDiff) * differentialWeight;

    // Normalize to percentages
    const totalScore = Math.abs(homeScore) + Math.abs(awayScore);
    const homeWinProb = totalScore > 0 ? Math.max(30, Math.min(70, 50 + homeScore)) : 50;
    const awayWinProb = 100 - homeWinProb;

    const winner = homeWinProb > awayWinProb ? homeTeam : awayTeam;
    const confidence = Math.round(Math.max(homeWinProb, awayWinProb));

    // Calculate individual factors for display
    const factors = {
      homeAdvantage: Math.round(homeHomeRecord.pct > awayAwayRecord.pct ? 
        (homeHomeRecord.pct - awayAwayRecord.pct) * 20 : 
        (homeHomeRecord.pct - awayAwayRecord.pct) * 20),
      recentForm: Math.round((homeRecentForm.pct - awayRecentForm.pct) * 20),
      injuries: 0, // Not available in current data
      headToHead: Math.round((homeWinPct - awayWinPct) * 20)
    };

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      throw new Error("LOVABLE_API_KEY not configured");
    }

    // Build AI prompt with real data
    const systemPrompt = `You are an expert sports analyst. Generate a clear 2-3 sentence explanation based on the provided statistics.`;
    
    const userPrompt = `Based on these statistics for ${league}:

${homeTeam} (Home):
- Win %: ${(homeWinPct * 100).toFixed(1)}%
- Home record: ${homeTeamData.home_record}
- Last 10: ${homeTeamData.last_10}
- PPG: ${homePpg.toFixed(1)} | Opp PPG: ${homeOppPpg.toFixed(1)}
- Differential: ${homeDiff > 0 ? '+' : ''}${homeDiff.toFixed(1)}

${awayTeam} (Away):
- Win %: ${(awayWinPct * 100).toFixed(1)}%
- Away record: ${awayTeamData.away_record}
- Last 10: ${awayTeamData.last_10}
- PPG: ${awayPpg.toFixed(1)} | Opp PPG: ${awayOppPpg.toFixed(1)}
- Differential: ${awayDiff > 0 ? '+' : ''}${awayDiff.toFixed(1)}

The data-driven prediction is: ${winner} wins with ${confidence}% confidence.

Write a 2-3 sentence explanation highlighting the key statistical advantages that support this prediction.`;

    // Call Lovable AI
    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: userPrompt }
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(
          JSON.stringify({ error: "Rate limit exceeded. Please try again later." }),
          { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (response.status === 402) {
        return new Response(
          JSON.stringify({ error: "Payment required. Please add credits to your workspace." }),
          { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      
      const errorText = await response.text();
      console.error("AI gateway error:", response.status, errorText);
      throw new Error("AI gateway error");
    }

    const data = await response.json();
    const aiExplanation = data.choices[0].message.content;
    
    console.log("AI Explanation:", aiExplanation);
    
    // Build prediction with calculated data
    const prediction = {
      winner,
      confidence,
      explanation: aiExplanation || `${winner} has a statistical advantage with a ${(homeWinPct * 100).toFixed(1)}% win rate and strong recent form.`,
      factors
    };

    console.log("Final prediction:", prediction);

    return new Response(JSON.stringify(prediction), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
    
  } catch (error) {
    console.error("Prediction error:", error);
    return new Response(
      JSON.stringify({ 
        error: error instanceof Error ? error.message : "Unknown error" 
      }),
      { 
        status: 500, 
        headers: { ...corsHeaders, "Content-Type": "application/json" } 
      }
    );
  }
});
