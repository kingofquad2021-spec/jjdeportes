import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.76.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Player {
  league: string;
  team_abbreviation: string;
  team_name: string;
  player_name: string;
  position: string | null;
  jersey_number: string | null;
  height: string | null;
  weight: string | null;
  age: number | null;
  player_image: string | null;
}

const MLS_TEAMS = [
  { id: '12500', name: 'Atlanta United FC', abbreviation: 'ATL' },
  { id: '12508', name: 'Austin FC', abbreviation: 'ATX' },
  { id: '12509', name: 'Charlotte FC', abbreviation: 'CLT' },
  { id: '12497', name: 'Chicago Fire FC', abbreviation: 'CHI' },
  { id: '12492', name: 'Colorado Rapids', abbreviation: 'COL' },
  { id: '12493', name: 'Columbus Crew', abbreviation: 'CLB' },
  { id: '12499', name: 'D.C. United', abbreviation: 'DC' },
  { id: '12494', name: 'FC Dallas', abbreviation: 'DAL' },
  { id: '12507', name: 'FC Cincinnati', abbreviation: 'CIN' },
  { id: '12495', name: 'Houston Dynamo FC', abbreviation: 'HOU' },
  { id: '12510', name: 'Inter Miami CF', abbreviation: 'MIA' },
  { id: '12496', name: 'LA Galaxy', abbreviation: 'LA' },
  { id: '12506', name: 'Los Angeles FC', abbreviation: 'LAFC' },
  { id: '12511', name: 'Minnesota United FC', abbreviation: 'MIN' },
  { id: '12498', name: 'Montreal Impact', abbreviation: 'MTL' },
  { id: '12512', name: 'Nashville SC', abbreviation: 'NSH' },
  { id: '12501', name: 'New England Revolution', abbreviation: 'NE' },
  { id: '12502', name: 'New York City FC', abbreviation: 'NYC' },
  { id: '12503', name: 'New York Red Bulls', abbreviation: 'NY' },
  { id: '12504', name: 'Orlando City SC', abbreviation: 'ORL' },
  { id: '12505', name: 'Philadelphia Union', abbreviation: 'PHI' },
  { id: '12513', name: 'Portland Timbers', abbreviation: 'POR' },
  { id: '12514', name: 'Real Salt Lake', abbreviation: 'RSL' },
  { id: '12515', name: 'San Jose Earthquakes', abbreviation: 'SJ' },
  { id: '12516', name: 'Seattle Sounders FC', abbreviation: 'SEA' },
  { id: '12517', name: 'Sporting Kansas City', abbreviation: 'SKC' },
  { id: '12518', name: 'St. Louis City SC', abbreviation: 'STL' },
  { id: '12519', name: 'Toronto FC', abbreviation: 'TOR' },
  { id: '12520', name: 'Vancouver Whitecaps FC', abbreviation: 'VAN' },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting MLS rosters update...');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const allPlayers: Player[] = [];

    for (const team of MLS_TEAMS) {
      try {
        const rosterUrl = `https://site.api.espn.com/apis/site/v2/sports/soccer/usa.1/teams/${team.id}/roster?season=2025`;
        console.log(`Fetching roster for ${team.name} (2025-2026 season)...`);
        
        const response = await fetch(rosterUrl);
        if (!response.ok) {
          console.error(`Failed to fetch roster for ${team.name}`);
          continue;
        }

        const data = await response.json();
        
        if (data.athletes) {
          // Athletes are grouped by position
          for (const positionGroup of data.athletes) {
            if (positionGroup.items) {
              for (const athlete of positionGroup.items) {
                allPlayers.push({
                  league: 'Soccer',
                  team_abbreviation: team.abbreviation,
                  team_name: team.name,
                  player_name: athlete.fullName || athlete.displayName || 'Unknown',
                  position: positionGroup.position || null,
                  jersey_number: athlete.jersey || null,
                  height: athlete.displayHeight || null,
                  weight: athlete.displayWeight || null,
                  age: athlete.age || null,
                  player_image: athlete.headshot?.href || null,
                });
              }
            }
          }
        }
      } catch (error) {
        console.error(`Error fetching roster for ${team.name}:`, error);
      }
    }

    console.log(`Parsed ${allPlayers.length} players from MLS rosters`);

    // Delete existing Soccer rosters
    const { error: deleteError } = await supabase
      .from('rosters')
      .delete()
      .eq('league', 'Soccer');

    if (deleteError) {
      throw deleteError;
    }

    // Insert new rosters
    const { error: insertError } = await supabase
      .from('rosters')
      .insert(allPlayers);

    if (insertError) {
      throw insertError;
    }

    console.log(`Successfully updated ${allPlayers.length} MLS players`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Successfully updated ${allPlayers.length} MLS players` 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error updating MLS rosters:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
