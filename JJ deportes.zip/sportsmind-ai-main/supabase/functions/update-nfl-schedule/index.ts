import { createClient } from "https://esm.sh/@supabase/supabase-js@2.76.1";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("Starting NFL schedule update...");
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const games: Array<{
      league: string;
      game_id: string;
      home_team: string;
      home_team_abbreviation: string;
      away_team: string;
      away_team_abbreviation: string;
      game_date: string;
      venue: string | null;
      status: string;
      home_score: number | null;
      away_score: number | null;
    }> = [];

    // Fetch schedule for next 14 days
    const today = new Date();
    for (let i = 0; i < 14; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      const dateStr = date.toISOString().split('T')[0].replace(/-/g, '');
      
      const espnUrl = `https://site.api.espn.com/apis/site/v2/sports/football/nfl/scoreboard?dates=${dateStr}`;
      console.log(`Fetching schedule for ${dateStr}...`);
      
      try {
        const response = await fetch(espnUrl);
        const data = await response.json();
        
        if (data.events) {
          for (const event of data.events) {
            const competition = event.competitions[0];
            const homeTeam = competition.competitors.find((c: any) => c.homeAway === 'home');
            const awayTeam = competition.competitors.find((c: any) => c.homeAway === 'away');

            games.push({
              league: 'NFL',
              game_id: event.id,
              home_team: homeTeam.team.displayName,
              home_team_abbreviation: homeTeam.team.abbreviation,
              away_team: awayTeam.team.displayName,
              away_team_abbreviation: awayTeam.team.abbreviation,
              game_date: event.date,
              venue: competition.venue?.fullName || null,
              status: competition.status.type.name,
              home_score: homeTeam.score?.value || null,
              away_score: awayTeam.score?.value || null,
            });
          }
        }
      } catch (error) {
        console.log(`Error fetching date ${dateStr}:`, error);
      }
    }

    console.log(`Parsed ${games.length} games`);

    // Delete existing NFL schedule
    await supabase.from('game_schedule').delete().eq('league', 'NFL');

    // Insert new schedule
    const { error } = await supabase.from('game_schedule').insert(games);

    if (error) throw error;

    console.log(`Successfully updated ${games.length} NFL games`);

    return new Response(
      JSON.stringify({ success: true, count: games.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error("Error updating NFL schedule:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});