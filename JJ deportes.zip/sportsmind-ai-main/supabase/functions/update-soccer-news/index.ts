import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting Soccer news update...');

    const SOCCER_TEAMS = [
      { id: 86, name: 'Real Madrid', abbreviation: 'RMA' },
      { id: 83, name: 'Barcelona', abbreviation: 'BAR' },
      { id: 85, name: 'Atletico Madrid', abbreviation: 'ATM' },
      { id: 88, name: 'Manchester United', abbreviation: 'MUN' },
      { id: 87, name: 'Manchester City', abbreviation: 'MCI' },
      { id: 89, name: 'Liverpool', abbreviation: 'LIV' },
      { id: 91, name: 'Chelsea', abbreviation: 'CHE' },
      { id: 90, name: 'Arsenal', abbreviation: 'ARS' },
      { id: 98, name: 'Bayern Munich', abbreviation: 'BAY' },
      { id: 99, name: 'Borussia Dortmund', abbreviation: 'DOR' },
      { id: 100, name: 'Paris Saint-Germain', abbreviation: 'PSG' },
      { id: 103, name: 'Juventus', abbreviation: 'JUV' },
      { id: 104, name: 'AC Milan', abbreviation: 'MIL' },
      { id: 105, name: 'Inter Milan', abbreviation: 'INT' }
    ];

    const allNews: any[] = [];

    for (const team of SOCCER_TEAMS) {
      console.log(`Fetching news for ${team.name}...`);
      
      try {
        const response = await fetch(`https://site.api.espn.com/apis/site/v2/sports/soccer/all/teams/${team.id}/news`);
        
        if (!response.ok) {
          console.error(`Failed to fetch news for ${team.name}: ${response.status}`);
          continue;
        }

        const data = await response.json();
        
        if (data.articles && Array.isArray(data.articles)) {
          for (const article of data.articles.slice(0, 10)) {
            const newsType = article.headline?.toLowerCase().includes('injury') || article.description?.toLowerCase().includes('injury') || article.description?.toLowerCase().includes('hurt')
              ? 'injury'
              : article.headline?.toLowerCase().includes('return') || article.description?.toLowerCase().includes('return') || article.description?.toLowerCase().includes('back')
              ? 'return'
              : 'general';

            allNews.push({
              league: 'Soccer',
              team_name: team.name,
              team_abbreviation: team.abbreviation,
              headline: article.headline || '',
              description: article.description || null,
              news_type: newsType,
              published_date: article.published ? new Date(article.published).toISOString() : new Date().toISOString(),
              source_url: article.links?.web?.href || null
            });
          }
        }
      } catch (error) {
        console.error(`Error fetching news for ${team.name}:`, error);
      }
    }

    const sevenDaysAgo = new Date();
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
    
    const { error: deleteError } = await supabase
      .from('team_news')
      .delete()
      .eq('league', 'Soccer')
      .lt('published_date', sevenDaysAgo.toISOString());

    if (deleteError) {
      console.error('Error deleting old news:', deleteError);
    }

    if (allNews.length > 0) {
      const { error: insertError } = await supabase
        .from('team_news')
        .upsert(allNews, { onConflict: 'headline,team_name' });

      if (insertError) {
        console.error('Error inserting news:', insertError);
        throw insertError;
      }

      console.log(`Successfully inserted ${allNews.length} news articles`);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Updated ${allNews.length} Soccer news articles`,
        newsCount: allNews.length
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in update-soccer-news:', error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
