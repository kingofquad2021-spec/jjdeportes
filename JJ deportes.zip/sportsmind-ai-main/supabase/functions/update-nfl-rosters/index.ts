import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.76.1';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface Player {
  league: string;
  team_abbreviation: string;
  team_name: string;
  player_name: string;
  position: string | null;
  jersey_number: string | null;
  height: string | null;
  weight: string | null;
  age: number | null;
  player_image: string | null;
}

const NFL_TEAMS = [
  { id: '22', name: 'Arizona Cardinals', abbreviation: 'ARI' },
  { id: '1', name: 'Atlanta Falcons', abbreviation: 'ATL' },
  { id: '33', name: 'Baltimore Ravens', abbreviation: 'BAL' },
  { id: '2', name: 'Buffalo Bills', abbreviation: 'BUF' },
  { id: '29', name: 'Carolina Panthers', abbreviation: 'CAR' },
  { id: '3', name: 'Chicago Bears', abbreviation: 'CHI' },
  { id: '4', name: 'Cincinnati Bengals', abbreviation: 'CIN' },
  { id: '5', name: 'Cleveland Browns', abbreviation: 'CLE' },
  { id: '6', name: 'Dallas Cowboys', abbreviation: 'DAL' },
  { id: '7', name: 'Denver Broncos', abbreviation: 'DEN' },
  { id: '8', name: 'Detroit Lions', abbreviation: 'DET' },
  { id: '9', name: 'Green Bay Packers', abbreviation: 'GB' },
  { id: '34', name: 'Houston Texans', abbreviation: 'HOU' },
  { id: '11', name: 'Indianapolis Colts', abbreviation: 'IND' },
  { id: '30', name: 'Jacksonville Jaguars', abbreviation: 'JAX' },
  { id: '12', name: 'Kansas City Chiefs', abbreviation: 'KC' },
  { id: '13', name: 'Las Vegas Raiders', abbreviation: 'LV' },
  { id: '24', name: 'Los Angeles Chargers', abbreviation: 'LAC' },
  { id: '14', name: 'Los Angeles Rams', abbreviation: 'LAR' },
  { id: '15', name: 'Miami Dolphins', abbreviation: 'MIA' },
  { id: '16', name: 'Minnesota Vikings', abbreviation: 'MIN' },
  { id: '17', name: 'New England Patriots', abbreviation: 'NE' },
  { id: '18', name: 'New Orleans Saints', abbreviation: 'NO' },
  { id: '19', name: 'New York Giants', abbreviation: 'NYG' },
  { id: '20', name: 'New York Jets', abbreviation: 'NYJ' },
  { id: '21', name: 'Philadelphia Eagles', abbreviation: 'PHI' },
  { id: '23', name: 'Pittsburgh Steelers', abbreviation: 'PIT' },
  { id: '25', name: 'San Francisco 49ers', abbreviation: 'SF' },
  { id: '26', name: 'Seattle Seahawks', abbreviation: 'SEA' },
  { id: '27', name: 'Tampa Bay Buccaneers', abbreviation: 'TB' },
  { id: '10', name: 'Tennessee Titans', abbreviation: 'TEN' },
  { id: '28', name: 'Washington Commanders', abbreviation: 'WSH' },
];

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('Starting NFL rosters update...');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const allPlayers: Player[] = [];

    for (const team of NFL_TEAMS) {
      try {
        const rosterUrl = `https://site.api.espn.com/apis/site/v2/sports/football/nfl/teams/${team.id}/roster?season=2025`;
        console.log(`Fetching roster for ${team.name} (2025-2026 season)...`);
        
        const response = await fetch(rosterUrl);
        if (!response.ok) {
          console.error(`Failed to fetch roster for ${team.name}`);
          continue;
        }

        const data = await response.json();
        
        if (data.athletes) {
          // Athletes are grouped by position
          for (const positionGroup of data.athletes) {
            if (positionGroup.items) {
              for (const athlete of positionGroup.items) {
                allPlayers.push({
                  league: 'NFL',
                  team_abbreviation: team.abbreviation,
                  team_name: team.name,
                  player_name: athlete.fullName || athlete.displayName || 'Unknown',
                  position: positionGroup.position || null,
                  jersey_number: athlete.jersey || null,
                  height: athlete.displayHeight || null,
                  weight: athlete.displayWeight || null,
                  age: athlete.age || null,
                  player_image: athlete.headshot?.href || null,
                });
              }
            }
          }
        }
      } catch (error) {
        console.error(`Error fetching roster for ${team.name}:`, error);
      }
    }

    console.log(`Parsed ${allPlayers.length} players from NFL rosters`);

    // Delete existing NFL rosters
    const { error: deleteError } = await supabase
      .from('rosters')
      .delete()
      .eq('league', 'NFL');

    if (deleteError) {
      throw deleteError;
    }

    // Insert new rosters
    const { error: insertError } = await supabase
      .from('rosters')
      .insert(allPlayers);

    if (insertError) {
      throw insertError;
    }

    console.log(`Successfully updated ${allPlayers.length} NFL players`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Successfully updated ${allPlayers.length} NFL players` 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Error updating NFL rosters:', error);
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});
