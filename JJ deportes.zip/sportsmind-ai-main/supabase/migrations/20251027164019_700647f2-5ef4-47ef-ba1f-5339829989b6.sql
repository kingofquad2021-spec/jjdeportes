-- Create table for team news
CREATE TABLE IF NOT EXISTS public.team_news (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  league TEXT NOT NULL,
  team_name TEXT NOT NULL,
  team_abbreviation TEXT,
  headline TEXT NOT NULL,
  description TEXT,
  news_type TEXT, -- injury, return, trade, etc.
  published_date TIMESTAMP WITH TIME ZONE NOT NULL,
  source_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_team_news_league ON public.team_news(league);
CREATE INDEX IF NOT EXISTS idx_team_news_team ON public.team_news(team_name);
CREATE INDEX IF NOT EXISTS idx_team_news_published ON public.team_news(published_date DESC);

-- Enable RLS
ALTER TABLE public.team_news ENABLE ROW LEVEL SECURITY;

-- Create policy to allow everyone to read news
CREATE POLICY "News are viewable by everyone"
ON public.team_news
FOR SELECT
USING (true);

-- Create trigger for updated_at
CREATE TRIGGER update_team_news_updated_at
BEFORE UPDATE ON public.team_news
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();