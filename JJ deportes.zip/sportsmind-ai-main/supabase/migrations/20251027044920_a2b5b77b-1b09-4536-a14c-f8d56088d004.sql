-- Create rosters table
CREATE TABLE IF NOT EXISTS public.rosters (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  league TEXT NOT NULL,
  team_abbreviation TEXT NOT NULL,
  team_name TEXT NOT NULL,
  player_name TEXT NOT NULL,
  position TEXT,
  jersey_number TEXT,
  height TEXT,
  weight TEXT,
  age INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.rosters ENABLE ROW LEVEL SECURITY;

-- Create policies for rosters (public read access)
CREATE POLICY "Anyone can view rosters"
ON public.rosters
FOR SELECT
USING (true);

CREATE POLICY "Anyone can update rosters"
ON public.rosters
FOR ALL
USING (true);

-- Create index for faster queries
CREATE INDEX idx_rosters_league ON public.rosters(league);
CREATE INDEX idx_rosters_team ON public.rosters(team_abbreviation);

-- Create trigger for updated_at
CREATE TRIGGER update_rosters_updated_at
  BEFORE UPDATE ON public.rosters
  FOR EACH ROW
  EXECUTE FUNCTION public.update_team_standings_updated_at();