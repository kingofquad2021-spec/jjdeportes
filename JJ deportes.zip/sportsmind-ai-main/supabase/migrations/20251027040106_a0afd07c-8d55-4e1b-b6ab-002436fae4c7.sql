-- Schedule cron jobs for all leagues

-- NFL standings update (every 15 minutes)
SELECT cron.schedule(
  'update-nfl-standings-every-15min',
  '*/15 * * * *',
  $$
  SELECT
    net.http_post(
        url:='https://qnqtuuwlktrnmqrhebzr.supabase.co/functions/v1/update-nfl-standings',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFucXR1dXdsa3Rybm1xcmhlYnpyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE0OTE0MTIsImV4cCI6MjA3NzA2NzQxMn0.UpIs7PMvRrjgp7Mz4odXWP0hqCgJWzs_8iCMh4lSGgU"}'::jsonb,
        body:='{"trigger": "cron"}'::jsonb
    ) as request_id;
  $$
);

-- MLB standings update (every 15 minutes)
SELECT cron.schedule(
  'update-mlb-standings-every-15min',
  '*/15 * * * *',
  $$
  SELECT
    net.http_post(
        url:='https://qnqtuuwlktrnmqrhebzr.supabase.co/functions/v1/update-mlb-standings',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFucXR1dXdsa3Rybm1xcmhlYnpyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE0OTE0MTIsImV4cCI6MjA3NzA2NzQxMn0.UpIs7PMvRrjgp7Mz4odXWP0hqCgJWzs_8iCMh4lSGgU"}'::jsonb,
        body:='{"trigger": "cron"}'::jsonb
    ) as request_id;
  $$
);

-- NHL standings update (every 15 minutes)
SELECT cron.schedule(
  'update-nhl-standings-every-15min',
  '*/15 * * * *',
  $$
  SELECT
    net.http_post(
        url:='https://qnqtuuwlktrnmqrhebzr.supabase.co/functions/v1/update-nhl-standings',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFucXR1dXdsa3Rybm1xcmhlYnpyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE0OTE0MTIsImV4cCI6MjA3NzA2NzQxMn0.UpIs7PMvRrjgp7Mz4odXWP0hqCgJWzs_8iCMh4lSGgU"}'::jsonb,
        body:='{"trigger": "cron"}'::jsonb
    ) as request_id;
  $$
);

-- Soccer standings update (every 15 minutes)
SELECT cron.schedule(
  'update-soccer-standings-every-15min',
  '*/15 * * * *',
  $$
  SELECT
    net.http_post(
        url:='https://qnqtuuwlktrnmqrhebzr.supabase.co/functions/v1/update-soccer-standings',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFucXR1dXdsa3Rybm1xcmhlYnpyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE0OTE0MTIsImV4cCI6MjA3NzA2NzQxMn0.UpIs7PMvRrjgp7Mz4odXWP0hqCgJWzs_8iCMh4lSGgU"}'::jsonb,
        body:='{"trigger": "cron"}'::jsonb
    ) as request_id;
  $$
);