-- Add injury tracking fields to rosters table
ALTER TABLE public.rosters 
ADD COLUMN IF NOT EXISTS injury_status text CHECK (injury_status IN ('active', 'injured', 'out', 'questionable', 'doubtful', 'day-to-day')),
ADD COLUMN IF NOT EXISTS injury_description text,
ADD COLUMN IF NOT EXISTS expected_return_date timestamp with time zone,
ADD COLUMN IF NOT EXISTS last_news_update timestamp with time zone;

-- Set default status for existing players
UPDATE public.rosters 
SET injury_status = 'active' 
WHERE injury_status IS NULL;