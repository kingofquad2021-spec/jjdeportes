-- Create table for team standings
CREATE TABLE public.team_standings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  league TEXT NOT NULL,
  conference TEXT NOT NULL,
  team_name TEXT NOT NULL,
  abbreviation TEXT NOT NULL,
  rank INTEGER NOT NULL,
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  pct NUMERIC(4,3) NOT NULL DEFAULT 0,
  gb TEXT,
  home_record TEXT,
  away_record TEXT,
  division_record TEXT,
  conference_record TEXT,
  ppg NUMERIC(5,1),
  opp_ppg NUMERIC(5,1),
  diff NUMERIC(5,1),
  streak TEXT,
  last_10 TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(league, conference, team_name)
);

-- Enable Row Level Security
ALTER TABLE public.team_standings ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Anyone can view standings"
ON public.team_standings
FOR SELECT
USING (true);

-- Create policy for public insert/update (for now, can be restricted later)
CREATE POLICY "Anyone can update standings"
ON public.team_standings
FOR ALL
USING (true);

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION public.update_team_standings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_team_standings_timestamp
BEFORE UPDATE ON public.team_standings
FOR EACH ROW
EXECUTE FUNCTION public.update_team_standings_updated_at();

-- Create index for faster queries
CREATE INDEX idx_team_standings_league_conference ON public.team_standings(league, conference);

-- Enable realtime
ALTER TABLE public.team_standings REPLICA IDENTITY FULL;
ALTER PUBLICATION supabase_realtime ADD TABLE public.team_standings;