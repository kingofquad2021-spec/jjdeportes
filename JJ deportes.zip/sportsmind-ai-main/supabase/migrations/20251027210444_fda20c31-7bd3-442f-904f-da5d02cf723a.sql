-- Create player_stats table for individual player performance
CREATE TABLE public.player_stats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  player_name TEXT NOT NULL,
  team_name TEXT NOT NULL,
  team_abbreviation TEXT NOT NULL,
  league TEXT NOT NULL,
  game_date TIMESTAMP WITH TIME ZONE NOT NULL,
  opponent TEXT NOT NULL,
  points INTEGER DEFAULT 0,
  rebounds INTEGER DEFAULT 0,
  assists INTEGER DEFAULT 0,
  steals INTEGER DEFAULT 0,
  blocks INTEGER DEFAULT 0,
  minutes_played INTEGER DEFAULT 0,
  fg_percentage NUMERIC(5,2),
  three_point_percentage NUMERIC(5,2),
  turnovers INTEGER DEFAULT 0,
  -- NFL specific
  passing_yards INTEGER,
  rushing_yards INTEGER,
  receiving_yards INTEGER,
  touchdowns INTEGER,
  -- Soccer specific
  goals INTEGER,
  shots INTEGER,
  -- NHL specific
  shots_on_goal INTEGER,
  plus_minus INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create index for faster queries
CREATE INDEX idx_player_stats_player ON public.player_stats(player_name, league);
CREATE INDEX idx_player_stats_team ON public.player_stats(team_abbreviation, league);
CREATE INDEX idx_player_stats_date ON public.player_stats(game_date DESC);

-- Enable RLS
ALTER TABLE public.player_stats ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Player stats are viewable by everyone" 
ON public.player_stats 
FOR SELECT 
USING (true);

-- Create team_stats table for aggregated team performance
CREATE TABLE public.team_stats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  team_name TEXT NOT NULL,
  team_abbreviation TEXT NOT NULL,
  league TEXT NOT NULL,
  season TEXT NOT NULL DEFAULT '2024-25',
  games_played INTEGER DEFAULT 0,
  avg_points NUMERIC(5,1),
  avg_points_allowed NUMERIC(5,1),
  offensive_rating NUMERIC(5,1),
  defensive_rating NUMERIC(5,1),
  home_wins INTEGER DEFAULT 0,
  home_losses INTEGER DEFAULT 0,
  away_wins INTEGER DEFAULT 0,
  away_losses INTEGER DEFAULT 0,
  avg_point_differential NUMERIC(5,1),
  current_streak TEXT,
  last_10_record TEXT,
  -- NBA/NHL specific
  avg_rebounds NUMERIC(5,1),
  avg_assists NUMERIC(5,1),
  -- NFL specific
  avg_yards NUMERIC(6,1),
  total_touchdowns INTEGER,
  -- Soccer specific
  avg_goals NUMERIC(4,2),
  avg_possession NUMERIC(4,1),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(team_abbreviation, league, season)
);

-- Create index for faster queries
CREATE INDEX idx_team_stats_team ON public.team_stats(team_abbreviation, league);

-- Enable RLS
ALTER TABLE public.team_stats ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Team stats are viewable by everyone" 
ON public.team_stats 
FOR SELECT 
USING (true);

-- Create player_futures table for long-term projections
CREATE TABLE public.player_futures (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  player_name TEXT NOT NULL,
  team_name TEXT NOT NULL,
  team_abbreviation TEXT NOT NULL,
  league TEXT NOT NULL,
  season TEXT NOT NULL DEFAULT '2024-25',
  category TEXT NOT NULL, -- 'mvp', 'points_leader', 'rebounds_leader', etc.
  projected_value NUMERIC(10,2),
  current_rank INTEGER,
  games_analyzed INTEGER DEFAULT 0,
  last_10_avg NUMERIC(10,2),
  season_avg NUMERIC(10,2),
  trend TEXT, -- 'up', 'down', 'stable'
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(player_name, league, season, category)
);

-- Create index for faster queries
CREATE INDEX idx_player_futures_player ON public.player_futures(player_name, league);
CREATE INDEX idx_player_futures_category ON public.player_futures(category, league);
CREATE INDEX idx_player_futures_rank ON public.player_futures(current_rank);

-- Enable RLS
ALTER TABLE public.player_futures ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access
CREATE POLICY "Player futures are viewable by everyone" 
ON public.player_futures 
FOR SELECT 
USING (true);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_player_stats_updated_at
BEFORE UPDATE ON public.player_stats
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_team_stats_updated_at
BEFORE UPDATE ON public.team_stats
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_player_futures_updated_at
BEFORE UPDATE ON public.player_futures
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();