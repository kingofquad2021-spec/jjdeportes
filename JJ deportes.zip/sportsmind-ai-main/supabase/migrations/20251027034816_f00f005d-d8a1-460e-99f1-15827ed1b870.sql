-- Enable pg_cron extension
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;

-- Enable pg_net extension  
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Grant necessary permissions
GRANT USAGE ON SCHEMA cron TO postgres;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA cron TO postgres;

-- Schedule the NBA standings update to run every 15 minutes
SELECT cron.schedule(
  'update-nba-standings-every-15min',
  '*/15 * * * *', -- Every 15 minutes
  $$
  SELECT
    net.http_post(
        url:='https://qnqtuuwlktrnmqrhebzr.supabase.co/functions/v1/update-nba-standings',
        headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFucXR1dXdsa3Rybm1xcmhlYnpyIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjE0OTE0MTIsImV4cCI6MjA3NzA2NzQxMn0.UpIs7PMvRrjgp7Mz4odXWP0hqCgJWzs_8iCMh4lSGgU"}'::jsonb,
        body:='{"trigger": "cron"}'::jsonb
    ) as request_id;
  $$
);