-- Create helper function for updating timestamps (if it doesn't exist)
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

-- Create game_schedule table for storing upcoming games
CREATE TABLE public.game_schedule (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  league TEXT NOT NULL,
  game_id TEXT NOT NULL UNIQUE,
  home_team TEXT NOT NULL,
  home_team_abbreviation TEXT NOT NULL,
  away_team TEXT NOT NULL,
  away_team_abbreviation TEXT NOT NULL,
  game_date TIMESTAMP WITH TIME ZONE NOT NULL,
  venue TEXT,
  status TEXT NOT NULL DEFAULT 'scheduled',
  home_score INTEGER,
  away_score INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.game_schedule ENABLE ROW LEVEL SECURITY;

-- Create policy for public read access (no auth required for viewing schedules)
CREATE POLICY "Game schedules are viewable by everyone" 
ON public.game_schedule 
FOR SELECT 
USING (true);

-- Create index for better query performance
CREATE INDEX idx_game_schedule_league ON public.game_schedule(league);
CREATE INDEX idx_game_schedule_date ON public.game_schedule(game_date);
CREATE INDEX idx_game_schedule_teams ON public.game_schedule(home_team_abbreviation, away_team_abbreviation);

-- Create trigger for automatic timestamp updates
CREATE TRIGGER update_game_schedule_updated_at
BEFORE UPDATE ON public.game_schedule
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();