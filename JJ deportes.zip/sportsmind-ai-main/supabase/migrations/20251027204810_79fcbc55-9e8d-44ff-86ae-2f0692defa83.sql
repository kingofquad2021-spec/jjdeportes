-- Add player_image column to rosters table
ALTER TABLE rosters ADD COLUMN IF NOT EXISTS player_image text;